#!/bin/bash
# Runs inside LocalStack once it is ready. Uses awslocal.
set -e
echo "════ BUKU LocalStack bootstrap ════"

for bucket in buku-media-dev buku-documents-dev buku-backups-dev; do
  awslocal s3 mb "s3://$bucket" 2>/dev/null || true
  awslocal s3api put-bucket-cors --bucket "$bucket" --cors-configuration '{
    "CORSRules": [{
      "AllowedOrigins": ["*"],
      "AllowedMethods": ["GET", "PUT", "POST"],
      "AllowedHeaders": ["*"],
      "MaxAgeSeconds": 3600
    }]
  }'
  echo "  ✅ S3 bucket: $bucket"
done

for identity in noreply@buku.app noreply@bukuapp.dev; do
  awslocal ses verify-email-identity --email-address "$identity"
  echo "  ✅ SES identity: $identity"
done

for topic in buku-notifications buku-sms buku-alerts; do
  awslocal sns create-topic --name "$topic" > /dev/null
  echo "  ✅ SNS topic: $topic"
done

DLQ_ARN=$(awslocal sqs create-queue --queue-name buku-dlq --query 'QueueUrl' --output text)
awslocal sqs create-queue --queue-name buku-jobs > /dev/null
echo "  ✅ SQS queues: buku-jobs, buku-dlq"

awslocal secretsmanager create-secret --name buku/dev/placeholder \
  --secret-string '{"note":"real secrets live in .env for dev"}' > /dev/null 2>&1 || true
echo "  ✅ Secrets Manager seeded"

echo "════ LocalStack ready ════"
