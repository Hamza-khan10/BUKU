#!/usr/bin/env bash
# Checks every component of the local stack and prints ✅/❌.
set -uo pipefail
ok()  { echo "  ✅ $1"; }
bad() { echo "  ❌ $1"; FAIL=1; }
FAIL=0

echo "════ BUKU local health check ════"

docker exec buku-postgres pg_isready -U buku_admin -d buku -q \
  && ok "PostgreSQL" || bad "PostgreSQL"

docker exec buku-redis redis-cli ping 2>/dev/null | grep -q PONG \
  && ok "Redis" || bad "Redis"

docker exec buku-kafka /opt/kafka/bin/kafka-topics.sh \
  --bootstrap-server localhost:9092 --list > /tmp/topics 2>/dev/null \
  && ok "Kafka ($(wc -l < /tmp/topics) topics)" || bad "Kafka"

curl -sf http://localhost:9200/_cluster/health > /dev/null \
  && ok "Elasticsearch" || bad "Elasticsearch"

curl -sf http://localhost:8123/ping > /dev/null \
  && ok "ClickHouse" || bad "ClickHouse"

curl -sf http://localhost:4566/_localstack/health > /dev/null \
  && ok "LocalStack" || bad "LocalStack"

for port in 3001 3002 3003 3004 3005 3006 3007; do
  name=$(curl -sf "http://localhost:$port/health" | grep -o '"service":"[^"]*"' | cut -d'"' -f4)
  [ -n "${name:-}" ] && ok "$name (:$port)" || bad "service on :$port"
done

curl -sf http://localhost:8001/status > /dev/null \
  && ok "Kong gateway" || bad "Kong gateway"

[ "$FAIL" = 0 ] && echo "════ ALL GREEN ════" || { echo "════ FAILURES — check: docker compose -f docker-compose.dev.yml logs <service> ════"; exit 1; }
