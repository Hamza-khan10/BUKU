#!/usr/bin/env bash
# Prints a valid Kafka KRaft CLUSTER_ID (22-char URL-safe base64 UUID).
# Paste into docker-compose.dev.yml → kafka → CLUSTER_ID if you want a new one.
python3 -c "import uuid,base64; print(base64.urlsafe_b64encode(uuid.uuid4().bytes).rstrip(b'=').decode())"
