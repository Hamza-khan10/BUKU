#!/usr/bin/env bash
# Generates the JWT RS256 keypair + PII encryption key and writes them to .env
# Run once before first `docker compose up`. Safe to re-run (asks before overwrite).
set -euo pipefail
cd "$(dirname "$0")/.."

if [ -f .env ] && grep -q '^JWT_PRIVATE_KEY=' .env; then
  read -rp ".env already contains JWT keys. Overwrite? [y/N] " ans
  [ "${ans:-N}" = "y" ] || { echo "Aborted."; exit 0; }
  sed -i '/^JWT_PRIVATE_KEY=/d;/^JWT_PUBLIC_KEY=/d;/^PII_ENCRYPTION_KEY=/d' .env
fi

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT

openssl genrsa -out "$tmp/private.pem" 2048 2>/dev/null
openssl rsa -in "$tmp/private.pem" -pubout -out "$tmp/public.pem" 2>/dev/null

{
  echo "JWT_PRIVATE_KEY=$(base64 -w0 < "$tmp/private.pem")"
  echo "JWT_PUBLIC_KEY=$(base64 -w0 < "$tmp/public.pem")"
  echo "PII_ENCRYPTION_KEY=$(openssl rand -base64 32)"
} >> .env

echo "✅ Wrote JWT_PRIVATE_KEY, JWT_PUBLIC_KEY, PII_ENCRYPTION_KEY to .env"
echo "   Keys are base64-encoded PEM. Never commit .env."
