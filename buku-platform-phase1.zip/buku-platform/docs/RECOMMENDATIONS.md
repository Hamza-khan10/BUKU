# BUKU Build — Architecture Review & Decisions (Phase 1)

Review of `BUKU_Fable5_Complete_Prompt` with the changes applied in this repo.

## 1. Verdict on the overall design
The architecture is sound and is kept: 7 services, Kafka event backbone,
Redis for locks/queues, Postgres as source of truth. For a solo developer the
honest risk is operational load, not design — addressed by the lean-launch
profile below rather than by rewriting.

## 2. Version upgrades applied (prompt was one generation behind)
| Component      | Prompt        | This repo            | Why |
|----------------|---------------|----------------------|-----|
| Node           | 20 LTS        | 22 LTS               | Active LTS, faster startup |
| Express        | 4.18          | 5.x                  | Stable; promise-aware error handling |
| Prisma         | 5             | 6                    | Current major, faster client |
| PostgreSQL     | 16 / PostGIS 3.4 | 17 / PostGIS 3.5  | Current stable |
| Redis          | 7.2           | 7.4                  | Current stable |
| Kafka          | 3.7           | 3.9 (KRaft)          | Last 3.x line; matches managed offerings. 4.0 exists but managed providers lag |
| Elasticsearch  | 8.13          | 8.17 (deliberately NOT 9) | DO managed OpenSearch is 8.x-API compatible |
| ClickHouse     | 24.3          | 25.3 LTS             | Current LTS |
| Kong           | 3.7           | 3.9                  | Current stable |
| LocalStack     | 3.4           | 4.x                  | Current major |
| Next.js (P3)   | 14            | 15 + React 19 + Tailwind 4 | Current stable |
| Expo (P4)      | SDK 51        | SDK 53               | Current stable |
| Dev runner     | ts-node-dev   | tsx                  | Faster, ESM-native |

## 3. Gaps found in the prompt and fixed here
1. **`favourites` table missing** — website/mobile both have a Favourites
   screen with no storage. Added (`user_id`,`business_id` composite PK).
2. **Paddle idempotency table missing** — gotcha #12 demanded it but the
   schema had no home for it. Added `processed_webhook_events`.
3. **Notification preferences had no storage** — added
   `notification_preferences` (one row per user, marketing consent timestamped
   for GDPR).
4. **Booking integrity hardened beyond the prompt** — added a Postgres
   `EXCLUDE USING gist` constraint preventing overlapping pending/confirmed
   appointments per staff member. The Redis lock prevents the race; this
   constraint guarantees integrity even if application code regresses.
   Schema is therefore 31 tables, not 28.

## 4. Lean-launch profile (recommended deployment path)
- **v1 deploy:** single DigitalOcean droplet, Docker Compose (this exact
  file minus dev-only UIs), Nginx + certbot in front. No Kubernetes.
- **Move to k3s** only after ~50 active businesses; the k8s manifests get
  written in Phase 5 either way so the path is ready.
- Elasticsearch + ClickHouse stay in the stack (already integrated), but if
  the first droplet is RAM-tight, both can be deferred: Postgres FTS +
  trigram indexes (already created by 02-triggers.sql) can serve search for
  the first ~1,000 businesses.

## 5. Logo replaceability (user requirement)
`/branding` is the single source of truth: `logo.svg`, `logo-light.svg`,
`tokens.css`. Web renders the mark only through one `Logo` component; no
component may inline the SVG or hardcode hex colors. See branding/README.md.

## 6. Security posture in Phase 1 (foundation-level)
- RS256 JWT (keypair via `scripts/generate-keys.sh`) — never HMAC.
- AES-256-GCM helper for PII, bcrypt(12) for passwords/tokens.
- Zod validation middleware, strict envelopes, security headers in every
  service AND at Kong; rate limiting + correlation IDs at the gateway.
- Soft-delete enforced globally via Prisma client extension.
- Outgoing webhook HMAC + timing-safe verification helpers ready.
Remaining security items (Paddle signature verification, OTP lockouts,
refresh rotation, CSP at Nginx) are implementation work in Phases 2 & 5 —
the primitives for all of them are in `@buku/common`.

## 7. Phase execution
One phase per working session, in order: the phases are dependency-ordered
and each ends in a verifiable state. Phase 1 = this repo, verified by
`scripts/health-check.sh` all green.
