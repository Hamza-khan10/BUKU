# BUKU Platform — Phase 1: Foundation

Universal appointment booking + virtual queue platform.
This repo currently contains **Phase 1 (Foundation)** complete and runnable:
monorepo, shared packages, full database schema, Kafka topology, all 7 service
shells with health endpoints, Kong gateway, and the full local Docker stack.

## Stack (latest stable)
Node 22 LTS · TypeScript 5.7 · Express 5 · Prisma 6 · PostgreSQL 17 + PostGIS 3.5
Redis 7.4 · Kafka 3.9 (KRaft) · Elasticsearch 8.17 · ClickHouse 25.3 LTS · Kong 3.9 · LocalStack 4

## First run (Ubuntu / WSL2)

```bash
# 0. Prerequisites: Docker Engine + Compose v2, Node 22, openssl, python3
sudo sysctl -w vm.max_map_count=262144     # Elasticsearch requirement (Linux)

# 1. Generate secrets into .env
cp .env.example .env
bash scripts/generate-keys.sh              # JWT RS256 keypair + PII key

# 2. Start everything (first build takes a few minutes)
docker compose -f docker-compose.dev.yml up --build

# 3. In another terminal — verify all components
bash scripts/health-check.sh
```

When green, you have:
- 7 services answering `GET /health` on ports 3001–3007 and through Kong on `http://localhost:3000`
- PostgreSQL with all 31 tables, triggers, and seeded demo data (20 businesses, 50 users, ~200 appointments)
- 41 Kafka topics (browse at http://localhost:8080)
- Elasticsearch `businesses` index (Kibana at http://localhost:5601)
- ClickHouse analytics tables, LocalStack S3/SES/SNS/SQS resources

## Repo map

```
packages/common      AppError, response envelope, JWT/RBAC/Zod middleware, crypto, logger
packages/kafka       TOPICS constants, idempotent producer w/ DLQ, consumer factory w/ error isolation
packages/database    Prisma schema (31 tables), seed, PostGIS/FTS/rating triggers, ClickHouse DDL
services/*           7 service shells (Express 5, health/ready, graceful shutdown, Dockerfiles)
infrastructure/kong  DB-less gateway config (routes, CORS, rate limits, correlation IDs)
infrastructure/localstack  S3/SES/SNS/SQS bootstrap
branding/            Replaceable logo + design tokens (single source of truth)
scripts/             generate-keys, generate-cluster-id, health-check
```

## Daily commands

```bash
npm run dev            # docker compose up
npm run dev:down       # stop
npm run dev:wipe       # stop + delete all volumes (fresh DB)
npm run db:studio      # Prisma Studio GUI
npm run cluster-id     # mint a new Kafka KRaft CLUSTER_ID
```

## What Phase 2 adds (next)
Real endpoint implementations: auth (OTP/JWT/OAuth), booking engine (atomic
Redis slot lock + availability algorithm), queue (Socket.IO realtime), the
notification consumers, search + ad injection, analytics ingestion — plus the
test suite (unit, integration, k6 load tests). The shells, schema, events, and
middleware they build on are all in place here.
