# BUKU Branding — single source of truth

Replace the logo everywhere by editing files in THIS folder only:

| File             | Used by                                            |
|------------------|----------------------------------------------------|
| `logo.svg`       | Web navbar, favicons, emails, docs (dark mark)     |
| `logo-light.svg` | Dark backgrounds (footer, dashboard sidebar)       |
| `tokens.css`     | All brand colors + fonts as CSS variables          |

Rules enforced across the codebase:
1. **No component hardcodes the logo SVG inline.** Web uses
   `apps/web/components/Logo.tsx`, which imports from `/branding`.
2. **No hex colors in components.** Only `var(--buku-*)` tokens.
3. Mobile copies `logo.svg` → `apps/mobile/assets/` at build time
   (script in apps/mobile/package.json) and mirrors tokens in
   `constants/colors.ts`.

To rebrand: drop in new SVGs with the same filenames + update tokens.css.
Nothing else needs to change.
