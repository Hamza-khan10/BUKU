CREATE DATABASE IF NOT EXISTS buku_analytics;

CREATE TABLE IF NOT EXISTS buku_analytics.events (
  event_id UUID,
  event_type String,
  business_id UUID,
  user_id Nullable(UUID),
  properties String,
  timestamp DateTime,
  date Date DEFAULT toDate(timestamp)
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(date)
ORDER BY (date, business_id, event_type);

CREATE TABLE IF NOT EXISTS buku_analytics.booking_analytics (
  booking_id UUID,
  business_id UUID,
  service_id UUID,
  staff_id Nullable(UUID),
  user_id UUID,
  status String,
  amount Nullable(Decimal(10, 2)),
  duration_minutes UInt16,
  day_of_week UInt8,
  hour_of_day UInt8,
  is_new_customer UInt8,
  created_at DateTime,
  date Date DEFAULT toDate(created_at)
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(date)
ORDER BY (date, business_id);

CREATE TABLE IF NOT EXISTS buku_analytics.queue_analytics (
  session_id UUID,
  business_id UUID,
  entry_count UInt32,
  served_count UInt32,
  no_show_count UInt32,
  avg_wait_seconds UInt32,
  avg_service_seconds UInt32,
  session_date Date
) ENGINE = MergeTree()
ORDER BY (session_date, business_id);

CREATE TABLE IF NOT EXISTS buku_analytics.search_analytics (
  query String,
  filters String,
  result_count UInt32,
  user_id Nullable(UUID),
  city String,
  category String,
  timestamp DateTime
) ENGINE = MergeTree()
ORDER BY (toDate(timestamp), city);
