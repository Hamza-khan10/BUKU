import { PrismaClient } from '@prisma/client';

/**
 * Singleton PrismaClient.
 * Soft-delete guard: every `user` read automatically excludes deleted accounts
 * unless the caller explicitly passes { includeDeleted: true } via query extension.
 */
const basePrisma = new PrismaClient({
  log: process.env.NODE_ENV === 'production' ? ['warn', 'error'] : ['warn', 'error'],
});

export const prisma = basePrisma.$extends({
  query: {
    user: {
      async $allOperations({ operation, args, query }) {
        if (['findFirst', 'findMany', 'findUnique', 'count'].includes(operation)) {
          const a = args as { where?: Record<string, unknown> };
          if (a.where && !('deletedAt' in a.where)) a.where = { ...a.where, deletedAt: null };
        }
        return query(args);
      },
    },
  },
});

export * from '@prisma/client';
