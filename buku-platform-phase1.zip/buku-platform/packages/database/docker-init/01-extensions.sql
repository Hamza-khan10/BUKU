-- Runs on first Postgres container start, before Prisma migrations.
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS btree_gist;

DO $$ BEGIN RAISE NOTICE '✅ BUKU extensions loaded: uuid-ossp, postgis, pg_trgm, pgcrypto, btree_gist'; END $$;
