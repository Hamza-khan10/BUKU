SQL files here run alphabetically on FIRST container start only.
02-triggers.sql is applied by `prisma migrate` instead — see prisma/migrations
note in docs. For local dev convenience, apply manually after first migrate:
  docker exec -i buku-postgres psql -U buku_admin -d buku < packages/database/docker-init/02-triggers.sql
