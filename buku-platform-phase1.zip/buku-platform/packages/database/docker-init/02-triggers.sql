-- ── Geography sync: businesses.location maintained from lat/lng ──
CREATE OR REPLACE FUNCTION sync_business_location() RETURNS trigger AS $$
BEGIN
  IF NEW.lat IS NOT NULL AND NEW.lng IS NOT NULL THEN
    NEW.location := ST_SetSRID(ST_MakePoint(NEW.lng::float8, NEW.lat::float8), 4326)::geography;
  ELSE
    NEW.location := NULL;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_business_location ON businesses;
CREATE TRIGGER trg_sync_business_location
  BEFORE INSERT OR UPDATE OF lat, lng ON businesses
  FOR EACH ROW EXECUTE FUNCTION sync_business_location();

CREATE INDEX IF NOT EXISTS idx_businesses_location ON businesses USING GIST (location);

-- ── Full-text search vector on businesses ──
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS search_vector tsvector;

CREATE OR REPLACE FUNCTION businesses_search_vector_update() RETURNS trigger AS $$
BEGIN
  NEW.search_vector :=
    setweight(to_tsvector('english', coalesce(NEW.name, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(NEW.description, '')), 'B') ||
    setweight(to_tsvector('english', coalesce(NEW.city, '')), 'C');
  RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_businesses_search_vector ON businesses;
CREATE TRIGGER trg_businesses_search_vector
  BEFORE INSERT OR UPDATE OF name, description, city ON businesses
  FOR EACH ROW EXECUTE FUNCTION businesses_search_vector_update();

CREATE INDEX IF NOT EXISTS idx_businesses_search ON businesses USING GIN (search_vector);
CREATE INDEX IF NOT EXISTS idx_businesses_name_trgm ON businesses USING GIN (name gin_trgm_ops);

-- ── Rating recalculation on review changes ──
CREATE OR REPLACE FUNCTION recalc_business_rating() RETURNS trigger AS $$
DECLARE biz uuid;
BEGIN
  biz := COALESCE(NEW.business_id, OLD.business_id);
  UPDATE businesses b SET
    avg_rating  = COALESCE((SELECT ROUND(AVG(overall_rating)::numeric, 2) FROM reviews r
                            WHERE r.business_id = biz AND r.is_visible), 0),
    review_count = (SELECT COUNT(*) FROM reviews r WHERE r.business_id = biz AND r.is_visible)
  WHERE b.id = biz;
  RETURN NULL;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_recalc_rating ON reviews;
CREATE TRIGGER trg_recalc_rating
  AFTER INSERT OR UPDATE OR DELETE ON reviews
  FOR EACH ROW EXECUTE FUNCTION recalc_business_rating();

-- ── Overlap guard: no two confirmed/pending appointments for same staff overlap ──
-- (Defense-in-depth behind the Redis lock; the lock prevents the race,
--  this constraint guarantees integrity even if app code regresses.)
ALTER TABLE appointments DROP CONSTRAINT IF EXISTS no_staff_overlap;
ALTER TABLE appointments ADD CONSTRAINT no_staff_overlap
  EXCLUDE USING gist (
    staff_id WITH =,
    tstzrange(start_at, end_at) WITH &&
  ) WHERE (staff_id IS NOT NULL AND status IN ('pending', 'confirmed'));

DO $$ BEGIN RAISE NOTICE '✅ BUKU triggers + constraints installed'; END $$;
