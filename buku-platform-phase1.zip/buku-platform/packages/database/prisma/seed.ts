import { PrismaClient, UserRole } from '@prisma/client';
import crypto from 'node:crypto';

const prisma = new PrismaClient();

const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
function confirmationCode(): string {
  let c = '';
  for (let i = 0; i < 6; i++) c += CODE_ALPHABET[crypto.randomInt(CODE_ALPHABET.length)];
  return `BK-${c}`;
}

const CATEGORIES = [
  { name: 'Dental', slug: 'dental', icon: '🦷' },
  { name: 'Hair & Barber', slug: 'hair-barber', icon: '✂️' },
  { name: 'Healthcare', slug: 'healthcare', icon: '🏥' },
  { name: 'Spa & Wellness', slug: 'spa-wellness', icon: '💆' },
  { name: 'Fitness', slug: 'fitness', icon: '💪' },
  { name: 'Auto Service', slug: 'auto-service', icon: '🚗' },
  { name: 'Pet Services', slug: 'pet-services', icon: '🐾' },
  { name: 'Government', slug: 'government', icon: '🏛️' },
];

const CITY = { city: 'Lahore', country: 'Pakistan', lat: 31.5204, lng: 74.3587 };

async function main() {
  console.log('🌱 Seeding BUKU development data...');

  // Categories
  const cats = [];
  for (let i = 0; i < CATEGORIES.length; i++) {
    const c = CATEGORIES[i]!;
    cats.push(await prisma.category.upsert({
      where: { slug: c.slug },
      update: {},
      create: { ...c, sortOrder: i },
    }));
  }

  // Super admin + 49 users
  await prisma.user.upsert({
    where: { email: 'admin@buku.app' },
    update: {},
    create: {
      email: 'admin@buku.app', name: 'BUKU Admin', role: UserRole.super_admin,
      emailVerifiedAt: new Date(), timezone: 'Asia/Karachi',
    },
  });

  const users = [];
  for (let i = 1; i <= 49; i++) {
    users.push(await prisma.user.upsert({
      where: { email: `user${i}@example.com` },
      update: {},
      create: {
        email: `user${i}@example.com`,
        phone: `+92300${String(1000000 + i)}`,
        name: `Test User ${i}`,
        role: i <= 20 ? UserRole.business_owner : UserRole.user,
        emailVerifiedAt: new Date(),
        timezone: 'Asia/Karachi',
      },
    }));
  }

  // 20 businesses, each: 3 services, 5 staff, weekly availability
  const SERVICES = [
    { name: 'Standard Service', durationMinutes: 30, price: 1500 },
    { name: 'Premium Service', durationMinutes: 60, bufferMinutes: 10, price: 3500 },
    { name: 'Quick Consultation', durationMinutes: 15, price: 800 },
  ];

  const businesses = [];
  for (let i = 0; i < 20; i++) {
    const owner = users[i]!;
    const cat = cats[i % cats.length]!;
    const slug = `demo-business-${i + 1}`;
    const biz = await prisma.business.upsert({
      where: { slug },
      update: {},
      create: {
        ownerId: owner.id,
        categoryId: cat.id,
        name: `${cat.name} Studio ${i + 1}`,
        slug,
        description: `A verified ${cat.name.toLowerCase()} business on BUKU. Book online or join the live queue.`,
        phone: `+92421${String(1000000 + i)}`,
        email: `biz${i + 1}@example.com`,
        address: `${i + 1} Main Boulevard`,
        ...CITY,
        lat: CITY.lat + (Math.random() - 0.5) * 0.1,
        lng: CITY.lng + (Math.random() - 0.5) * 0.1,
        status: 'verified',
        verified: true,
        verifiedAt: new Date(),
        settings: {
          autoConfirm: true, cancellationHours: 2, minAdvanceHours: 1,
          maxAdvanceDays: 90, timezone: 'Asia/Karachi', currency: 'PKR', queueEnabled: i % 3 === 0,
        },
        services: { create: SERVICES.map((s, j) => ({ ...s, currency: 'PKR', sortOrder: j })) },
        hours: {
          create: [1, 2, 3, 4, 5, 6].map(d => ({ dayOfWeek: d, openTime: '09:00', closeTime: '21:00' })),
        },
      },
      include: { services: true },
    });
    businesses.push(biz);

    // Staff with availability Mon–Sat 09:00–17:00
    for (let s = 0; s < 5; s++) {
      const staff = await prisma.staff.create({
        data: {
          businessId: biz.id,
          displayName: `Staff ${s + 1}`,
          role: s === 0 ? 'owner' : 'staff',
          specializations: [biz.services[s % biz.services.length]!.name],
          inviteAccepted: true,
          availabilityRules: {
            create: [1, 2, 3, 4, 5, 6].map(d => ({
              businessId: biz.id, dayOfWeek: d, startTime: '09:00', endTime: '17:00',
            })),
          },
        },
      });
      await prisma.staffService.createMany({
        data: biz.services.map(svc => ({ staffId: staff.id, serviceId: svc.id })),
        skipDuplicates: true,
      });
    }
  }

  // 200 appointments spread over ±15 days
  const customers = users.slice(20);
  let created = 0;
  for (let i = 0; i < 200; i++) {
    const biz = businesses[i % businesses.length]!;
    const svc = biz.services[i % biz.services.length]!;
    const cust = customers[i % customers.length]!;
    const staffList = await prisma.staff.findMany({ where: { businessId: biz.id }, take: 5 });
    const staff = staffList[i % staffList.length]!;
    const dayOffset = (i % 30) - 15;
    const start = new Date();
    start.setDate(start.getDate() + dayOffset);
    start.setHours(9 + (i % 8), (i % 2) * 30, 0, 0);
    const end = new Date(start.getTime() + svc.durationMinutes * 60_000);
    const past = dayOffset < 0;
    try {
      await prisma.appointment.create({
        data: {
          businessId: biz.id, serviceId: svc.id, staffId: staff.id, userId: cust.id,
          status: past ? (i % 7 === 0 ? 'no_show' : 'completed') : (i % 5 === 0 ? 'pending' : 'confirmed'),
          startAt: start, endAt: end,
          price: svc.price, currency: 'PKR',
          confirmationCode: confirmationCode(),
        },
      });
      created++;
    } catch { /* skip overlap-constraint collisions in seed */ }
  }

  // Reviews on 30 completed appointments
  const completed = await prisma.appointment.findMany({ where: { status: 'completed' }, take: 30 });
  for (const a of completed) {
    await prisma.review.upsert({
      where: { appointmentId: a.id },
      update: {},
      create: {
        appointmentId: a.id, userId: a.userId, businessId: a.businessId,
        overallRating: 3 + Math.floor(Math.random() * 3),
        staffRating: 4, waitTimeRating: 4, cleanlinessRating: 5, valueRating: 4,
        comment: 'Great experience, booked through BUKU and walked straight in.',
      },
    });
  }

  // 10 queue sessions (today) for queue-enabled businesses
  const queueBiz = businesses.filter((_, i) => i % 3 === 0).slice(0, 10);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  for (const biz of queueBiz) {
    await prisma.queueSession.upsert({
      where: { businessId_sessionDate: { businessId: biz.id, sessionDate: today } },
      update: {},
      create: { businessId: biz.id, sessionDate: today, status: 'open', openedAt: new Date(), currentNumber: 5, lastCalledNumber: 2 },
    });
  }

  console.log(`✅ Seed complete: ${cats.length} categories, 50 users, ${businesses.length} businesses, ${created} appointments, 30 reviews, ${queueBiz.length} queue sessions`);
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
