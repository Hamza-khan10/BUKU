/** Single source of truth for every Kafka topic name. Never use raw strings. */
export const TOPICS = {
  // Bookings
  BOOKINGS_CREATED: 'bookings.created',
  BOOKINGS_CONFIRMED: 'bookings.confirmed',
  BOOKINGS_CANCELLED: 'bookings.cancelled',
  BOOKINGS_RESCHEDULED: 'bookings.rescheduled',
  BOOKINGS_COMPLETED: 'bookings.completed',
  BOOKINGS_REMINDER: 'bookings.reminder',
  BOOKINGS_NO_SHOW: 'bookings.no_show',
  // Queue
  QUEUE_SESSION_OPENED: 'queue.session.opened',
  QUEUE_SESSION_CLOSED: 'queue.session.closed',
  QUEUE_ENTRY_JOINED: 'queue.entry.joined',
  QUEUE_ENTRY_CALLED: 'queue.entry.called',
  QUEUE_ENTRY_SERVED: 'queue.entry.served',
  QUEUE_ENTRY_COMPLETED: 'queue.entry.completed',
  QUEUE_ENTRY_LEFT: 'queue.entry.left',
  QUEUE_ENTRY_NO_SHOW: 'queue.entry.no_show',
  QUEUE_POSITION_UPDATED: 'queue.position.updated',
  // Notifications
  NOTIFICATIONS_SEND: 'notifications.send',
  NOTIFICATIONS_DELIVERED: 'notifications.delivered',
  // Users & businesses
  USERS_REGISTERED: 'users.registered',
  USERS_VERIFIED: 'users.verified',
  USERS_DELETED: 'users.deleted',
  BUSINESSES_CREATED: 'businesses.created',
  BUSINESSES_VERIFIED: 'businesses.verified',
  BUSINESSES_UPDATED: 'businesses.updated',
  BUSINESSES_SUSPENDED: 'businesses.suspended',
  // Payments
  PAYMENTS_INITIATED: 'payments.initiated',
  PAYMENTS_COMPLETED: 'payments.completed',
  PAYMENTS_FAILED: 'payments.failed',
  PAYMENTS_REFUNDED: 'payments.refunded',
  // Analytics
  ANALYTICS_EVENTS: 'analytics.events',
  ANALYTICS_SEARCH: 'analytics.search',
  ANALYTICS_AD_IMPRESSIONS: 'analytics.ad.impressions',
  // AI receptionist
  AI_CALL_STARTED: 'ai.call.started',
  AI_CALL_COMPLETED: 'ai.call.completed',
  AI_CALL_FAILED: 'ai.call.failed',
  // Webhooks
  WEBHOOKS_DISPATCH: 'webhooks.dispatch',
  WEBHOOKS_DELIVERED: 'webhooks.delivered',
  WEBHOOKS_FAILED: 'webhooks.failed',
  // Dead-letter
  DLQ_FAILED_EVENTS: 'dlq.failed-events',
  DLQ_NOTIFICATIONS: 'dlq.notifications',
  DLQ_WEBHOOKS: 'dlq.webhooks',
} as const;
export type Topic = (typeof TOPICS)[keyof typeof TOPICS];
