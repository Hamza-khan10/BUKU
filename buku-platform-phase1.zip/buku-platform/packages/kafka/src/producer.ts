import { Kafka, Partitioners, type Producer } from 'kafkajs';
import { TOPICS, type Topic } from './topics.js';

let producer: Producer | null = null;

function kafkaClient(clientId: string) {
  return new Kafka({
    clientId,
    brokers: (process.env.KAFKA_BROKERS ?? 'localhost:9092').split(','),
    retry: { initialRetryTime: 300, retries: 5, maxRetryTime: 30_000 },
  });
}

export async function createProducer(clientId = process.env.KAFKA_CLIENT_ID ?? 'buku'): Promise<Producer> {
  if (producer) return producer;
  producer = kafkaClient(clientId).producer({
    idempotent: true,
    maxInFlightRequests: 5,
    createPartitioner: Partitioners.DefaultPartitioner,
  });
  await producer.connect();
  return producer;
}

export interface BukuEvent<T = unknown> {
  id: string;
  type: Topic;
  occurredAt: string;
  data: T;
}

/** Produce with acks=all; on terminal failure publish to DLQ so events are never silently lost. */
export async function produceEvent<T>(topic: Topic, key: string, data: T, headers?: Record<string, string>) {
  const p = await createProducer();
  const event: BukuEvent<T> = { id: crypto.randomUUID(), type: topic, occurredAt: new Date().toISOString(), data };
  const message = { key, value: JSON.stringify(event), headers };
  try {
    await p.send({ topic, messages: [message], acks: -1 });
    return event.id;
  } catch (err) {
    await p.send({
      topic: TOPICS.DLQ_FAILED_EVENTS,
      messages: [{ key, value: JSON.stringify({ originalTopic: topic, event, error: String(err) }) }],
      acks: -1,
    }).catch(() => { /* DLQ unreachable: surface original error */ });
    throw err;
  }
}

export async function disconnectProducer() {
  await producer?.disconnect();
  producer = null;
}
