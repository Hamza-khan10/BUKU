import { Kafka, type Consumer, type EachMessagePayload } from 'kafkajs';
import { TOPICS, type Topic } from './topics.js';
import type { BukuEvent } from './producer.js';

export type EventHandler = (event: BukuEvent, raw: EachMessagePayload) => Promise<void>;

/**
 * Consumer factory with per-message error isolation:
 * a failing message is routed to the DLQ and the consumer keeps going.
 * Offsets are committed manually after successful processing.
 */
export async function createConsumer(
  groupId: string,
  topics: Topic[],
  handler: EventHandler,
): Promise<Consumer> {
  const kafka = new Kafka({
    clientId: `${process.env.KAFKA_CLIENT_ID ?? 'buku'}-${groupId}`,
    brokers: (process.env.KAFKA_BROKERS ?? 'localhost:9092').split(','),
    retry: { initialRetryTime: 300, retries: 5 },
  });
  const consumer = kafka.consumer({
    groupId: `${process.env.KAFKA_GROUP_ID_PREFIX ?? 'buku'}-${groupId}`,
    sessionTimeout: 30_000,
    heartbeatInterval: 3_000,
  });
  const producer = kafka.producer();
  await Promise.all([consumer.connect(), producer.connect()]);
  await Promise.all(topics.map(topic => consumer.subscribe({ topic, fromBeginning: false })));

  await consumer.run({
    autoCommit: false,
    eachMessage: async (payload) => {
      const { topic, partition, message } = payload;
      try {
        const event = JSON.parse(message.value?.toString() ?? '{}') as BukuEvent;
        await handler(event, payload);
      } catch (err) {
        await producer.send({
          topic: TOPICS.DLQ_FAILED_EVENTS,
          messages: [{
            key: message.key,
            value: JSON.stringify({
              consumerGroup: groupId, sourceTopic: topic,
              raw: message.value?.toString(), error: String(err),
            }),
          }],
        }).catch(() => { /* keep consuming even if DLQ write fails */ });
      } finally {
        await consumer.commitOffsets([{ topic, partition, offset: (Number(message.offset) + 1).toString() }]);
      }
    },
  });
  return consumer;
}
