import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { ZodError, type ZodSchema } from 'zod';
import { AppError, ErrorCodes, HTTP_STATUS } from './errors.js';
import { sendError } from './response.js';
import { logger } from './logger.js';

export type UserRole = 'user' | 'staff' | 'business_owner' | 'super_admin';

export interface JwtPayload {
  sub: string;
  role: UserRole;
  jti: string;
  iat: number;
  exp: number;
}

declare module 'express-serve-static-core' {
  interface Request {
    user?: JwtPayload;
    requestId?: string;
  }
}

/** RS256 verification. JWT_PUBLIC_KEY is base64-encoded PEM in env. */
export function authenticateToken(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return next(AppError.unauthorized());
  const token = header.slice(7);
  const publicKey = Buffer.from(process.env.JWT_PUBLIC_KEY ?? '', 'base64').toString('utf8');
  try {
    req.user = jwt.verify(token, publicKey, { algorithms: ['RS256'] }) as JwtPayload;
    next();
  } catch (err) {
    if (err instanceof jwt.TokenExpiredError) {
      return next(new AppError('Token expired', ErrorCodes.TOKEN_EXPIRED, HTTP_STATUS.UNAUTHORIZED));
    }
    return next(new AppError('Invalid token', ErrorCodes.TOKEN_INVALID, HTTP_STATUS.UNAUTHORIZED));
  }
}

export function requireRole(...roles: UserRole[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(AppError.unauthorized());
    if (!roles.includes(req.user.role)) return next(AppError.forbidden());
    next();
  };
}

/** Validates req.body / req.query / req.params against a Zod schema. */
export function validateRequest(schema: { body?: ZodSchema; query?: ZodSchema; params?: ZodSchema }) {
  return (req: Request, _res: Response, next: NextFunction) => {
    try {
      if (schema.body) req.body = schema.body.parse(req.body);
      if (schema.query) Object.assign(req.query, schema.query.parse(req.query));
      if (schema.params) Object.assign(req.params, schema.params.parse(req.params));
      next();
    } catch (err) {
      if (err instanceof ZodError) {
        return next(new AppError('Validation failed', ErrorCodes.VALIDATION_ERROR, HTTP_STATUS.BAD_REQUEST,
          err.issues.map(i => ({ path: i.path.join('.'), message: i.message }))));
      }
      next(err);
    }
  };
}

/** Standard security headers — applied by every service in addition to Kong/Nginx. */
export function securityHeaders(_req: Request, res: Response, next: NextFunction) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.removeHeader('X-Powered-By');
  next();
}

/** Request ID propagation + structured request logging. */
export function requestLogger(req: Request, res: Response, next: NextFunction) {
  req.requestId = (req.headers['x-request-id'] as string) ?? crypto.randomUUID();
  res.setHeader('X-Request-ID', req.requestId);
  const start = performance.now();
  res.on('finish', () => {
    logger.info('http', {
      requestId: req.requestId,
      method: req.method,
      path: req.path,
      status: res.statusCode,
      durationMs: Math.round(performance.now() - start),
    });
  });
  next();
}

/** Global error handler — register LAST. */
export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction) {
  if (!(err instanceof AppError) || err.httpStatus >= 500) {
    logger.error('unhandled', { requestId: req.requestId, err });
  }
  sendError(res, err);
}

/** 404 fallthrough — register after all routes. */
export function notFoundHandler(_req: Request, res: Response) {
  sendError(res, AppError.notFound('Route'));
}
