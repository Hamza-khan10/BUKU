import type { Request } from 'express';

export interface Pagination { page: number; limit: number; skip: number }

export function pagination(req: Request, maxLimit = 100): Pagination {
  const page = Math.max(1, Number(req.query.page ?? 1) || 1);
  const limit = Math.min(maxLimit, Math.max(1, Number(req.query.limit ?? 20) || 20));
  return { page, limit, skip: (page - 1) * limit };
}
