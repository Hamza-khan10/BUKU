import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';

const BCRYPT_ROUNDS = Number(process.env.BCRYPT_ROUNDS ?? 12);

export const hashToken = (token: string) => bcrypt.hash(token, BCRYPT_ROUNDS);
export const verifyTokenHash = (token: string, hash: string) => bcrypt.compare(token, hash);

/** BK- + 6 uppercase alphanumerics (no ambiguous chars). Caller retries on unique collision. */
export function generateConfirmationCode(): string {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let code = '';
  const bytes = crypto.randomBytes(6);
  for (let i = 0; i < 6; i++) code += alphabet[(bytes[i] as number) % alphabet.length];
  return `BK-${code}`;
}

export const generateOtp = () => String(crypto.randomInt(100000, 1000000));

export function generateHmacSignature(payload: string, secret: string): string {
  return 'sha256=' + crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

export function verifyHmacSignature(payload: string, secret: string, signature: string): boolean {
  const expected = generateHmacSignature(payload, secret);
  if (expected.length !== signature.length) return false;
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
}

/** AES-256-GCM for PII at the application layer. PII_ENCRYPTION_KEY: 32 bytes base64. */
export function encrypt(plain: string): string {
  const key = Buffer.from(process.env.PII_ENCRYPTION_KEY ?? '', 'base64');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  return [iv.toString('base64'), cipher.getAuthTag().toString('base64'), enc.toString('base64')].join('.');
}

export function decrypt(ciphertext: string): string {
  const key = Buffer.from(process.env.PII_ENCRYPTION_KEY ?? '', 'base64');
  const [ivB64, tagB64, dataB64] = ciphertext.split('.');
  if (!ivB64 || !tagB64 || !dataB64) throw new Error('Malformed ciphertext');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]).toString('utf8');
}
