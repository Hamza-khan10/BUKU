/** Canonical error codes used across every BUKU service. */
export const ErrorCodes = {
  USER_EXISTS: 'USER_EXISTS',
  USER_NOT_FOUND: 'USER_NOT_FOUND',
  INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
  OTP_EXPIRED: 'OTP_EXPIRED',
  OTP_INVALID: 'OTP_INVALID',
  OTP_LOCKED: 'OTP_LOCKED',
  OTP_RATE_LIMITED: 'OTP_RATE_LIMITED',
  TOKEN_EXPIRED: 'TOKEN_EXPIRED',
  TOKEN_INVALID: 'TOKEN_INVALID',
  TOKEN_REVOKED: 'TOKEN_REVOKED',
  FORBIDDEN: 'FORBIDDEN',
  UNAUTHORIZED: 'UNAUTHORIZED',
  SLOT_UNAVAILABLE: 'SLOT_UNAVAILABLE',
  SLOT_IN_PAST: 'SLOT_IN_PAST',
  SLOT_TOO_FAR_AHEAD: 'SLOT_TOO_FAR_AHEAD',
  SLOT_TOO_SOON: 'SLOT_TOO_SOON',
  INVALID_TRANSITION: 'INVALID_TRANSITION',
  APPOINTMENT_NOT_FOUND: 'APPOINTMENT_NOT_FOUND',
  CANCELLATION_WINDOW_PASSED: 'CANCELLATION_WINDOW_PASSED',
  QUEUE_CLOSED: 'QUEUE_CLOSED',
  QUEUE_FULL: 'QUEUE_FULL',
  QUEUE_ALREADY_JOINED: 'QUEUE_ALREADY_JOINED',
  QUEUE_ENTRY_NOT_FOUND: 'QUEUE_ENTRY_NOT_FOUND',
  BUSINESS_NOT_FOUND: 'BUSINESS_NOT_FOUND',
  BUSINESS_NOT_VERIFIED: 'BUSINESS_NOT_VERIFIED',
  PLAN_LIMIT_REACHED: 'PLAN_LIMIT_REACHED',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  NOT_FOUND: 'NOT_FOUND',
  CONFLICT: 'CONFLICT',
  RATE_LIMITED: 'RATE_LIMITED',
  INTERNAL_ERROR: 'INTERNAL_ERROR',
} as const;
export type ErrorCode = (typeof ErrorCodes)[keyof typeof ErrorCodes];

export const HTTP_STATUS = {
  OK: 200, CREATED: 201, NO_CONTENT: 204,
  BAD_REQUEST: 400, UNAUTHORIZED: 401, FORBIDDEN: 403, NOT_FOUND: 404,
  CONFLICT: 409, UNPROCESSABLE: 422, TOO_MANY_REQUESTS: 429,
  INTERNAL_SERVER_ERROR: 500, SERVICE_UNAVAILABLE: 503,
} as const;

/** Every service throws AppError; the global error handler maps it to the response envelope. */
export class AppError extends Error {
  constructor(
    message: string,
    public readonly code: ErrorCode,
    public readonly httpStatus: number = HTTP_STATUS.BAD_REQUEST,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = 'AppError';
    Error.captureStackTrace(this, this.constructor);
  }
  static notFound(what = 'Resource') {
    return new AppError(`${what} not found`, ErrorCodes.NOT_FOUND, HTTP_STATUS.NOT_FOUND);
  }
  static unauthorized(message = 'Authentication required') {
    return new AppError(message, ErrorCodes.UNAUTHORIZED, HTTP_STATUS.UNAUTHORIZED);
  }
  static forbidden(message = 'Insufficient permissions') {
    return new AppError(message, ErrorCodes.FORBIDDEN, HTTP_STATUS.FORBIDDEN);
  }
  static conflict(message: string, code: ErrorCode = ErrorCodes.CONFLICT) {
    return new AppError(message, code, HTTP_STATUS.CONFLICT);
  }
}
