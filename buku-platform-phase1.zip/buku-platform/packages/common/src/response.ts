import type { Response } from 'express';
import { AppError, ErrorCodes, HTTP_STATUS } from './errors.js';

export interface ApiMeta {
  page?: number; limit?: number; total?: number; totalPages?: number;
  requestId?: string;
  [k: string]: unknown;
}

export function successResponse<T>(data: T, meta?: ApiMeta) {
  return { success: true as const, data, ...(meta ? { meta } : {}) };
}

export function errorResponse(err: AppError) {
  return {
    success: false as const,
    error: { code: err.code, message: err.message, ...(err.details ? { details: err.details } : {}) },
  };
}

export function sendSuccess<T>(res: Response, data: T, status = HTTP_STATUS.OK, meta?: ApiMeta) {
  return res.status(status).json(successResponse(data, meta));
}

export function sendError(res: Response, err: unknown) {
  const appErr = err instanceof AppError
    ? err
    : new AppError('Internal server error', ErrorCodes.INTERNAL_ERROR, HTTP_STATUS.INTERNAL_SERVER_ERROR);
  return res.status(appErr.httpStatus).json(errorResponse(appErr));
}
