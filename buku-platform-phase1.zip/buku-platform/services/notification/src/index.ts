import express from 'express';
import {
  logger, requestLogger, securityHeaders,
  errorHandler, notFoundHandler, sendSuccess,
} from '@buku/common';

const SERVICE = 'notification-service';
const PORT = Number(process.env.PORT ?? 3004);

export const app = express();

app.use(express.json({ limit: '100kb' }));
app.use(securityHeaders);
app.use(requestLogger);

app.get('/health', (_req, res) => {
  sendSuccess(res, { status: 'ok', service: SERVICE, timestamp: new Date().toISOString() });
});

app.get('/ready', (_req, res) => {
  // Phase 2 adds dependency checks (DB ping, Redis ping, Kafka connectivity).
  sendSuccess(res, { status: 'ready', service: SERVICE });
});

// ── Phase 2: real routes mount here ──

app.use(notFoundHandler);
app.use(errorHandler);

const server = app.listen(PORT, () => {
  logger.info(`🚀 ${SERVICE} listening on :${PORT}`);
});

for (const sig of ['SIGTERM', 'SIGINT'] as const) {
  process.on(sig, () => {
    logger.info(`${sig} received — shutting down ${SERVICE}`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), 10_000).unref();
  });
}
