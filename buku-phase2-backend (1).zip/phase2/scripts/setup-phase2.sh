#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# BUKU Phase 2 — Complete Setup Script
# Run from: ~/buku-platform
# Usage:   bash scripts/setup-phase2.sh
# ═══════════════════════════════════════════════════════════════
set -e
PROJ=$(pwd)
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  BUKU Phase 2 — Backend Setup"
echo "  Working in: $PROJ"
echo "═══════════════════════════════════════════════════════════"
echo ""

# ── 1. Update packages/common/package.json ────────────────────
cat > packages/common/package.json << 'PKG'
{
  "name": "@buku/common",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch"
  },
  "dependencies": {
    "bcryptjs": "^2.4.3",
    "express": "^4.18.3",
    "jsonwebtoken": "^9.0.2",
    "morgan": "^1.10.0",
    "winston": "^3.13.0",
    "zod": "^3.23.8"
  },
  "devDependencies": {
    "@types/bcryptjs": "^2.4.6",
    "@types/express": "^4.17.21",
    "@types/jsonwebtoken": "^9.0.6",
    "@types/morgan": "^1.9.9",
    "@types/node": "^22.0.0",
    "typescript": "^5.4.5"
  }
}
PKG

# ── 2. Update packages/kafka/package.json ─────────────────────
cat > packages/kafka/package.json << 'PKG'
{
  "name": "@buku/kafka",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch"
  },
  "dependencies": {
    "kafkajs": "^2.2.4"
  },
  "devDependencies": {
    "@types/node": "^22.0.0",
    "typescript": "^5.4.5"
  }
}
PKG

# ── 3. Update services package.json files ─────────────────────
for SERVICE in auth booking queue notification search ads analytics; do
  cat > services/$SERVICE/package.json << SPKG
{
  "name": "@buku/$SERVICE-service",
  "version": "1.0.0",
  "main": "dist/index.js",
  "scripts": {
    "build": "tsc",
    "dev": "tsx watch src/index.ts",
    "start": "node dist/index.js",
    "test": "jest --runInBand"
  },
  "dependencies": {
    "@aws-sdk/client-s3": "^3.600.0",
    "@aws-sdk/client-ses": "^3.600.0",
    "@aws-sdk/client-sns": "^3.600.0",
    "@buku/common": "*",
    "@buku/database": "*",
    "@buku/kafka": "*",
    "@prisma/client": "^6.0.0",
    "bcryptjs": "^2.4.3",
    "bullmq": "^5.12.9",
    "cors": "^2.8.5",
    "dotenv": "^16.4.5",
    "express": "^4.18.3",
    "google-auth-library": "^9.13.0",
    "helmet": "^7.1.0",
    "ioredis": "^5.3.2",
    "jsonwebtoken": "^9.0.2",
    "kafkajs": "^2.2.4",
    "morgan": "^1.10.0",
    "multer": "^1.4.5-lts.1",
    "socket.io": "^4.7.5",
    "twilio": "^5.2.3",
    "winston": "^3.13.0",
    "zod": "^3.23.8"
  },
  "devDependencies": {
    "@types/bcryptjs": "^2.4.6",
    "@types/cors": "^2.8.17",
    "@types/express": "^4.17.21",
    "@types/jsonwebtoken": "^9.0.6",
    "@types/morgan": "^1.9.9",
    "@types/multer": "^1.4.11",
    "@types/node": "^22.0.0",
    "jest": "^29.7.0",
    "ts-jest": "^29.1.4",
    "tsx": "^4.15.7",
    "typescript": "^5.4.5"
  }
}
SPKG
done

echo "✓ package.json files updated"

# ── 4. Install dependencies ───────────────────────────────────
echo ""
echo "Installing npm dependencies (this will take 2-3 minutes)..."
npm install 2>/dev/null || echo "Root npm install done"

# ── 5. Verify Prisma client ───────────────────────────────────
echo ""
echo "Generating Prisma client..."
cd packages/database && \
  npx prisma generate --schema prisma/schema.prisma 2>/dev/null || true
cd $PROJ

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  Setup complete! Next steps:"
echo ""
echo "  1. Copy Phase 2 source files into your services:"
echo "     (See instructions below)"
echo ""
echo "  2. Rebuild Docker images:"
echo "     docker compose -f docker-compose.dev.yml build --no-cache"
echo ""
echo "  3. Restart all services:"
echo "     docker compose -f docker-compose.dev.yml up -d"
echo ""
echo "  4. Verify all endpoints:"
echo "     curl http://localhost:3001/health"
echo "     curl http://localhost:3000/v1/auth/register (via Kong)"
echo "═══════════════════════════════════════════════════════════"
