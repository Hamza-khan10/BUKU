#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# BUKU — Phase 2 Complete Install Script
# Run from: ~/buku-platform
# Usage:    bash scripts/install-phase2.sh /path/to/phase2/outputs
# ═══════════════════════════════════════════════════════════════
set -e
PROJ=$(pwd)
PHASE2_SRC=${1:-/tmp/buku-phase2}

echo ""
echo "═══════════════════════════════════════"
echo "  BUKU Phase 2 Install"
echo "  Source: $PHASE2_SRC"
echo "  Target: $PROJ"
echo "═══════════════════════════════════════"
echo ""

# Verify we're in the right directory
if [ ! -f "docker-compose.dev.yml" ]; then
  echo "ERROR: Run this from ~/buku-platform (docker-compose.dev.yml not found)"
  exit 1
fi

# Copy all Phase 2 source files
echo "Copying Phase 2 files..."

cp -rv "$PHASE2_SRC/packages/." packages/
cp -rv "$PHASE2_SRC/services/." services/
cp -rv "$PHASE2_SRC/infrastructure/." infrastructure/
cp -rv "$PHASE2_SRC/scripts/." scripts/ 2>/dev/null || true

echo "✓ Files copied"

# Generate JWT key pair for RS256
echo ""
echo "Generating JWT RS256 key pair..."
mkdir -p keys
if [ ! -f keys/private.pem ]; then
  openssl genrsa -out keys/private.pem 2048
  openssl rsa -in keys/private.pem -pubout -out keys/public.pem
  echo "✓ JWT key pair generated"
  # Base64 encode for docker-compose env vars
  PRIVATE_B64=$(base64 -w0 keys/private.pem)
  PUBLIC_B64=$(base64 -w0 keys/public.pem)
  echo ""
  echo "Add these to your .env file or docker-compose.dev.yml:"
  echo "JWT_PRIVATE_KEY=$PRIVATE_B64"
  echo "JWT_PUBLIC_KEY=$PUBLIC_B64"
  echo ""
  # Write to .env.keys for reference
  cat > .env.keys << ENV
JWT_PRIVATE_KEY=$PRIVATE_B64
JWT_PUBLIC_KEY=$PUBLIC_B64
ENV
  echo "✓ Keys saved to .env.keys"
else
  echo "✓ JWT keys already exist"
fi

# Update .env.dev with required vars
cat > .env.dev << ENVFILE
NODE_ENV=development
BCRYPT_ROUNDS=10
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d
FRONTEND_URL=http://localhost:3000
# AWS (LocalStack)
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=test
AWS_SECRET_ACCESS_KEY=test
AWS_ENDPOINT_URL=http://localstack:4566
AWS_SES_FROM_EMAIL=noreply@buku.app
# Twilio (set your actual credentials)
TWILIO_ACCOUNT_SID=mock_account_sid
TWILIO_AUTH_TOKEN=mock_auth_token
TWILIO_FROM_NUMBER=+15551234567
# Firebase (set your actual credentials)
FIREBASE_PROJECT_ID=buku-dev
# PII Encryption (32 bytes = 64 hex chars)
PII_ENCRYPTION_KEY=$(openssl rand -hex 32)
# Queue settings
QUEUE_GRACE_PERIOD_SECONDS=300
BOOKING_SLOT_LOCK_TTL_SECONDS=30
# ClickHouse
CLICKHOUSE_URL=http://clickhouse:8123
CLICKHOUSE_USER=buku_analytics
CLICKHOUSE_PASSWORD=buku_analytics_dev
CLICKHOUSE_DB=buku_analytics
ENVFILE
echo "✓ .env.dev created"

# Rebuild Docker images
echo ""
echo "Rebuilding Docker images (this may take 3-5 minutes)..."
docker compose -f docker-compose.dev.yml build --no-cache \
  auth-service booking-service queue-service notification-service \
  search-service ads-service analytics-service

echo ""
echo "Restarting services..."
docker compose -f docker-compose.dev.yml up -d

echo ""
echo "Waiting 30 seconds for services to start..."
sleep 30

echo ""
echo "═══════════════════════════════════════"
echo "  Health Checks"
echo "═══════════════════════════════════════"
for PORT in 3001 3002 3003 3004 3005 3006 3007; do
  RESP=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:$PORT/health 2>/dev/null)
  if [ "$RESP" = "200" ]; then
    echo "  ✅  :$PORT — OK"
  else
    echo "  ❌  :$PORT — HTTP $RESP"
  fi
done

echo ""
echo "═══════════════════════════════════════"
echo "  Phase 2 Install Complete!"
echo "  Kong gateway:   http://localhost:3000"
echo "  Auth (direct):  http://localhost:3001"
echo "  Kafka UI:       http://localhost:8080"
echo "═══════════════════════════════════════"
