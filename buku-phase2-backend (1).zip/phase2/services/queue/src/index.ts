import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import helmet from 'helmet';
import jwt from 'jsonwebtoken';
import { requestId, requestLogger, errorHandler, notFoundHandler, logger } from '@buku/common';
import { queueRouter } from './routes/queue.routes';

const app = express();
const httpServer = createServer(app);
const PORT = parseInt(process.env.PORT ?? '3003', 10);
const WS_PORT = parseInt(process.env.WS_PORT ?? '3013', 10);

// ── Socket.IO server on separate port ──────────
const io = new SocketIOServer(WS_PORT, {
  cors: {
    origin: (process.env.FRONTEND_URL ?? 'http://localhost:3000').split(','),
    methods: ['GET', 'POST'],
    credentials: true,
  },
  transports: ['websocket', 'polling'],
  pingTimeout: 60000,
  pingInterval: 25000,
});

// Export io so routes can use it
export { io };

// ── WebSocket JWT Authentication ───────────────
io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth.token as string | undefined
      ?? socket.handshake.headers.authorization?.replace('Bearer ', '');

    if (!token) return next(new Error('Authentication required'));

    const publicKey = process.env.JWT_PUBLIC_KEY ?? '';
    const key = publicKey.includes('BEGIN') ? publicKey : Buffer.from(publicKey, 'base64').toString('utf8');
    const payload = jwt.verify(token, key, { algorithms: ['RS256'] }) as { sub: string; role: string };

    socket.data.userId = payload.sub;
    socket.data.role = payload.role;
    return next();
  } catch {
    return next(new Error('Invalid token'));
  }
});

// ── WebSocket event handling ────────────────────
io.on('connection', (socket) => {
  const { userId, role } = socket.data as { userId: string; role: string };
  logger.info({ message: 'WebSocket connected', userId, socketId: socket.id });

  // User joins their personal room for position updates
  socket.join(`user:${userId}`);

  // Business staff joins their business room for dashboard updates
  socket.on('join-business', async (businessId: string) => {
    if (role === 'business_owner' || role === 'staff' || role === 'super_admin') {
      socket.join(`biz:${businessId}`);
      logger.info({ message: 'Staff joined business room', userId, businessId });
    }
  });

  socket.on('leave-business', (businessId: string) => {
    socket.leave(`biz:${businessId}`);
  });

  socket.on('disconnect', (reason) => {
    logger.info({ message: 'WebSocket disconnected', userId, reason });
  });
});

// ── HTTP middleware ────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: (process.env.FRONTEND_URL ?? 'http://localhost:3000').split(','),
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID'],
}));
app.use(requestId());
app.use(requestLogger());
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

app.get('/health', (_req, res) => {
  res.json({ success: true, data: { status: 'ok', service: 'queue-service', timestamp: new Date().toISOString() } });
});
app.get('/ready', async (_req, res) => {
  try {
    const { prisma } = await import('@buku/database');
    await prisma.$queryRaw`SELECT 1`;
    res.json({ success: true, data: { status: 'ready' } });
  } catch {
    res.status(503).json({ success: false, error: { code: 'NOT_READY', message: 'Database not ready' } });
  }
});

app.use('/v1/queue', queueRouter);
app.use(notFoundHandler());
app.use(errorHandler());

httpServer.listen(PORT, () => {
  logger.info({ message: `Queue HTTP service listening on port ${PORT}` });
  logger.info({ message: `Queue WebSocket server listening on port ${WS_PORT}` });
});

const shutdown = async (signal: string) => {
  logger.info({ message: `${signal} received` });
  await io.close();
  httpServer.close(async () => {
    const { disconnectDatabase } = await import('@buku/database');
    const { disconnectKafka } = await import('@buku/kafka');
    await Promise.all([disconnectDatabase(), disconnectKafka()]);
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 30000);
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
