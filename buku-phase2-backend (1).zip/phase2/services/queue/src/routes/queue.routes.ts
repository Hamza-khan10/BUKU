import { Router } from 'express';
import { z } from 'zod';
import { authenticateToken, validateRequest, asyncHandler, requireBusinessOwner } from '@buku/common';
import * as QueueService from '../services/queue.service';

export const queueRouter = Router();
queueRouter.use(authenticateToken());

const JoinQueueSchema = z.object({
  businessId: z.string().uuid(),
  notes: z.string().max(500).optional(),
  priorityLane: z.boolean().default(false),
});

const OpenSessionSchema = z.object({
  maxSize: z.number().int().min(1).max(500).optional(),
  gracePeriodSeconds: z.number().int().min(30).max(1800).optional(),
});

// GET /v1/queue/sessions/status?businessId=...
queueRouter.get('/sessions/status',
  asyncHandler(async (req, res) => {
    const businessId = req.query.businessId as string;
    if (!businessId) {
      const { AppError, ErrorCode } = await import('@buku/common');
      throw AppError.badRequest('businessId is required', ErrorCode.VALIDATION_ERROR);
    }
    const status = await QueueService.getQueueStatus(businessId);
    res.json({ success: true, data: status });
  }),
);

// POST /v1/queue/sessions/open
queueRouter.post('/sessions/open',
  requireBusinessOwner(),
  validateRequest(OpenSessionSchema),
  asyncHandler(async (req, res) => {
    const { prisma } = await import('@buku/database');
    const biz = await prisma.business.findFirst({ where: { ownerId: req.user!.sub }, select: { id: true } });
    if (!biz) {
      const { AppError, ErrorCode } = await import('@buku/common');
      throw AppError.notFound('Business not found', ErrorCode.BUSINESS_NOT_FOUND);
    }
    const session = await QueueService.openQueueSession(biz.id, req.body);
    res.status(201).json({ success: true, data: { session } });
  }),
);

// POST /v1/queue/sessions/close
queueRouter.post('/sessions/close',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const { sessionId } = req.body as { sessionId: string };
    const { prisma } = await import('@buku/database');
    const biz = await prisma.business.findFirst({ where: { ownerId: req.user!.sub }, select: { id: true } });
    const session = await QueueService.closeQueueSession(sessionId, biz?.id ?? '');
    res.json({ success: true, data: { session } });
  }),
);

// POST /v1/queue/sessions/pause
queueRouter.post('/sessions/pause',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const { sessionId } = req.body as { sessionId: string };
    const { prisma } = await import('@buku/database');
    const biz = await prisma.business.findFirst({ where: { ownerId: req.user!.sub }, select: { id: true } });
    const session = await QueueService.pauseQueue(sessionId, biz?.id ?? '');
    res.json({ success: true, data: { session } });
  }),
);

// POST /v1/queue/sessions/resume
queueRouter.post('/sessions/resume',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const { sessionId } = req.body as { sessionId: string };
    const { prisma } = await import('@buku/database');
    const biz = await prisma.business.findFirst({ where: { ownerId: req.user!.sub }, select: { id: true } });
    const session = await QueueService.resumeQueue(sessionId, biz?.id ?? '');
    res.json({ success: true, data: { session } });
  }),
);

// GET /v1/queue/sessions/:id
queueRouter.get('/sessions/:id',
  asyncHandler(async (req, res) => {
    const state = await QueueService.getQueueState(req.params.id!);
    res.json({ success: true, data: state });
  }),
);

// POST /v1/queue/join
queueRouter.post('/join',
  validateRequest(JoinQueueSchema),
  asyncHandler(async (req, res) => {
    const result = await QueueService.joinQueue({ ...req.body, userId: req.user!.sub });
    res.status(201).json({ success: true, data: result });
  }),
);

// GET /v1/queue/entries/:id
queueRouter.get('/entries/:id',
  asyncHandler(async (req, res) => {
    const result = await QueueService.getEntryStatus(req.params.id!, req.user!.sub);
    res.json({ success: true, data: result });
  }),
);

// POST /v1/queue/entries/:id/leave
queueRouter.post('/entries/:id/leave',
  asyncHandler(async (req, res) => {
    const entry = await QueueService.leaveQueue(req.params.id!, req.user!.sub);
    res.json({ success: true, data: { entry, message: 'You have left the queue' } });
  }),
);

// POST /v1/queue/call-next (business staff)
queueRouter.post('/call-next',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const { sessionId } = req.body as { sessionId: string };
    const { prisma } = await import('@buku/database');
    const biz = await prisma.business.findFirst({ where: { ownerId: req.user!.sub }, select: { id: true } });
    const result = await QueueService.callNext(sessionId, biz?.id ?? '');
    res.json({ success: true, data: result });
  }),
);

// POST /v1/queue/entries/:id/serve
queueRouter.post('/entries/:id/serve',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const { sessionId } = req.body as { sessionId: string };
    const entry = await QueueService.markServing(req.params.id!, sessionId);
    res.json({ success: true, data: { entry } });
  }),
);

// POST /v1/queue/entries/:id/complete
queueRouter.post('/entries/:id/complete',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const { sessionId } = req.body as { sessionId: string };
    const entry = await QueueService.completeEntry(req.params.id!, sessionId);
    res.json({ success: true, data: { entry } });
  }),
);

// POST /v1/queue/entries/:id/no-show
queueRouter.post('/entries/:id/no-show',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const { sessionId } = req.body as { sessionId: string };
    const entry = await QueueService.markNoShow(req.params.id!, sessionId);
    res.json({ success: true, data: { entry } });
  }),
);
