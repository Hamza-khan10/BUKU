import crypto from 'crypto';
import { Redis } from 'ioredis';
import { prisma } from '@buku/database';
import { AppError, ErrorCode, logger } from '@buku/common';
import { produceEvent, TOPICS } from '@buku/kafka';

let redisClient: Redis | null = null;
function getRedis(): Redis {
  if (!redisClient) {
    redisClient = new Redis(process.env.REDIS_URL ?? 'redis://redis:6379', { maxRetriesPerRequest: 3 });
    redisClient.on('error', err => logger.error({ message: 'Redis error queue-service', error: String(err) }));
  }
  return redisClient;
}

// ─── Redis key helpers ────────────────────────
const keys = {
  sessionState: (id: string) => `queue:session:${id}:state`,
  waiters: (id: string) => `queue:session:${id}:waiters`,
  counter: (id: string) => `queue:session:${id}:counter`,
  entryPosition: (id: string) => `queue:entry:${id}:position`,
};

// ─────────────────────────────────────────────────────────────
// OPEN QUEUE SESSION
// ─────────────────────────────────────────────────────────────
export async function openQueueSession(businessId: string, options?: {
  maxSize?: number; gracePeriodSeconds?: number;
}) {
  const today = new Date().toISOString().split('T')[0]!;

  // Check for existing open session today
  const existing = await prisma.queueSession.findFirst({
    where: { businessId, sessionDate: new Date(today), status: { in: ['open', 'paused'] } },
  });
  if (existing) {
    throw AppError.conflict('Queue is already open today', ErrorCode.QUEUE_ALREADY_OPEN);
  }

  const session = await prisma.queueSession.create({
    data: {
      businessId,
      sessionDate: new Date(today),
      status: 'open',
      maxQueueSize: options?.maxSize ?? 200,
      gracePeriodSeconds: options?.gracePeriodSeconds ?? parseInt(process.env.QUEUE_GRACE_PERIOD_SECONDS ?? '300', 10),
      openedAt: new Date(),
    },
  });

  // Initialize Redis state
  const redis = getRedis();
  await redis.hset(keys.sessionState(session.id), {
    status: 'open',
    currentNumber: 0,
    lastCalled: 0,
    totalServed: 0,
    avgServiceSeconds: 300,
    openedAt: new Date().toISOString(),
    businessId,
  });
  await redis.set(keys.counter(session.id), 0);

  produceEvent(TOPICS.QUEUE_SESSION_OPENED, session.id, {
    sessionId: session.id, businessId,
  }).catch(() => {});

  logger.info({ message: 'Queue session opened', sessionId: session.id, businessId });
  return session;
}

// ─────────────────────────────────────────────────────────────
// CLOSE QUEUE SESSION
// ─────────────────────────────────────────────────────────────
export async function closeQueueSession(sessionId: string, businessId: string) {
  const session = await prisma.queueSession.findFirst({ where: { id: sessionId, businessId } });
  if (!session) throw AppError.notFound('Queue session not found', ErrorCode.QUEUE_ENTRY_NOT_FOUND);

  const updated = await prisma.queueSession.update({
    where: { id: sessionId },
    data: { status: 'closed', closedAt: new Date() },
  });

  const redis = getRedis();
  await redis.hset(keys.sessionState(sessionId), { status: 'closed' });

  // Notify all waiters that queue is closed via WebSocket
  const { io } = await import('../index');
  io.to(`biz:${businessId}`).emit('queue:closed', { sessionId, businessId });

  // Notify all waiting users
  const waiters = await redis.zrange(keys.waiters(sessionId), 0, -1);
  for (const entryId of waiters) {
    const entry = await prisma.queueEntry.findFirst({ where: { id: entryId } });
    if (entry?.userId) {
      io.to(`user:${entry.userId}`).emit('queue:closed', { sessionId, businessId, message: 'Queue has closed for today' });
    }
  }

  produceEvent(TOPICS.QUEUE_SESSION_CLOSED, sessionId, { sessionId, businessId }).catch(() => {});
  return updated;
}

// ─────────────────────────────────────────────────────────────
// PAUSE / RESUME QUEUE
// ─────────────────────────────────────────────────────────────
export async function pauseQueue(sessionId: string, businessId: string) {
  const session = await getOpenSession(sessionId, businessId);
  const updated = await prisma.queueSession.update({ where: { id: sessionId }, data: { status: 'paused' } });
  const redis = getRedis();
  await redis.hset(keys.sessionState(sessionId), { status: 'paused' });
  const { io } = await import('../index');
  io.to(`biz:${businessId}`).emit('queue:dashboard_update', await getQueueState(sessionId));
  return updated;
}

export async function resumeQueue(sessionId: string, businessId: string) {
  const session = await prisma.queueSession.findFirst({ where: { id: sessionId, businessId, status: 'paused' } });
  if (!session) throw AppError.notFound('Paused queue session not found', ErrorCode.QUEUE_ENTRY_NOT_FOUND);
  const updated = await prisma.queueSession.update({ where: { id: sessionId }, data: { status: 'open' } });
  const redis = getRedis();
  await redis.hset(keys.sessionState(sessionId), { status: 'open' });
  const { io } = await import('../index');
  io.to(`biz:${businessId}`).emit('queue:dashboard_update', await getQueueState(sessionId));
  return updated;
}

// ─────────────────────────────────────────────────────────────
// JOIN QUEUE
// ─────────────────────────────────────────────────────────────
export async function joinQueue(body: {
  businessId: string;
  userId?: string;
  notes?: string;
  priorityLane?: boolean;
}) {
  const { businessId, userId, notes, priorityLane } = body;
  const redis = getRedis();
  const today = new Date().toISOString().split('T')[0]!;

  const session = await prisma.queueSession.findFirst({
    where: { businessId, sessionDate: new Date(today), status: 'open' },
  });
  if (!session) throw AppError.badRequest('No queue open at this business right now', ErrorCode.QUEUE_NOT_OPEN);

  // Check if user already in queue
  if (userId) {
    const alreadyIn = await prisma.queueEntry.findFirst({
      where: { sessionId: session.id, userId, status: { in: ['waiting', 'called', 'serving'] } },
    });
    if (alreadyIn) throw AppError.conflict('You are already in this queue', ErrorCode.ALREADY_IN_QUEUE);
  }

  // Check max queue size
  const currentSize = await redis.zcard(keys.waiters(session.id));
  if (currentSize >= session.maxQueueSize) {
    throw AppError.conflict('Queue is full', ErrorCode.QUEUE_FULL);
  }

  // Generate ticket number atomically via INCR
  const ticketNumber = await redis.incr(keys.counter(session.id));
  const ticketPrefix = 'A';

  // Calculate estimated wait
  const stateData = await redis.hgetall(keys.sessionState(session.id));
  const avgServiceSeconds = parseInt(stateData.avgServiceSeconds ?? '300', 10);
  const positionInQueue = currentSize; // 0-indexed
  const estimatedWaitSeconds = positionInQueue * avgServiceSeconds;

  const entry = await prisma.queueEntry.create({
    data: {
      sessionId: session.id,
      userId: userId ?? null,
      ticketNumber,
      ticketPrefix,
      status: 'waiting',
      estimatedWaitSeconds,
      priorityLane: priorityLane ?? false,
      notes: notes?.trim() ?? null,
      joinedAt: new Date(),
    },
  });

  // Add to Redis sorted set (score = ticket number for ordering)
  await redis.zadd(keys.waiters(session.id), ticketNumber, entry.id);

  // Cache position
  await redis.setex(keys.entryPosition(entry.id), 30, String(positionInQueue + 1));

  // Broadcast to business dashboard
  const { io } = await import('../index');
  io.to(`biz:${businessId}`).emit('queue:new_entry', {
    entryId: entry.id,
    ticketNumber,
    ticketPrefix,
    estimatedWaitSeconds,
    totalWaiting: currentSize + 1,
  });

  // Notify the user who joined
  if (userId) {
    io.to(`user:${userId}`).emit('queue:position_updated', {
      entryId: entry.id,
      position: positionInQueue + 1,
      estimatedWaitSeconds,
      ticketNumber: `${ticketPrefix}${String(ticketNumber).padStart(3, '0')}`,
    });
  }

  produceEvent(TOPICS.QUEUE_ENTRY_JOINED, entry.id, {
    sessionId: session.id,
    businessId,
    entryId: entry.id,
    userId: userId ?? null,
    ticketNumber,
    ticketPrefix,
    estimatedWaitSeconds,
  }).catch(() => {});

  logger.info({ message: 'Customer joined queue', entryId: entry.id, businessId, ticketNumber });

  return {
    entry: { ...entry, ticketDisplay: `${ticketPrefix}${String(ticketNumber).padStart(3, '0')}` },
    position: positionInQueue + 1,
    estimatedWaitSeconds,
  };
}

// ─────────────────────────────────────────────────────────────
// CALL NEXT CUSTOMER
// ─────────────────────────────────────────────────────────────
export async function callNext(sessionId: string, businessId: string) {
  const redis = getRedis();
  await getOpenSession(sessionId, businessId);

  // Get first waiter from sorted set (lowest ticket number)
  const [entryId] = await redis.zrange(keys.waiters(sessionId), 0, 0);
  if (!entryId) {
    return { message: 'No more customers waiting', entry: null };
  }

  const entry = await prisma.queueEntry.update({
    where: { id: entryId },
    data: { status: 'called', calledAt: new Date() },
  });

  await redis.hset(keys.sessionState(sessionId), { lastCalled: entry.ticketNumber });

  // Remove from waiters set
  await redis.zrem(keys.waiters(sessionId), entryId);

  // Broadcast urgent notification to the called customer
  const { io } = await import('../index');
  if (entry.userId) {
    io.to(`user:${entry.userId}`).emit('queue:called', {
      entryId: entry.id,
      ticketNumber: entry.ticketNumber,
      ticketDisplay: `${entry.ticketPrefix}${String(entry.ticketNumber).padStart(3, '0')}`,
      message: 'You are next! Please come to the front desk.',
    });
  }

  // Recalculate positions for all remaining waiters and broadcast
  await broadcastPositionUpdates(sessionId, businessId);

  // Update dashboard
  io.to(`biz:${businessId}`).emit('queue:dashboard_update', await getQueueState(sessionId));

  // Notify via Kafka (triggers SMS from notification-service)
  produceEvent(TOPICS.QUEUE_ENTRY_CALLED, entry.id, {
    sessionId,
    businessId,
    entryId: entry.id,
    userId: entry.userId ?? null,
    ticketNumber: entry.ticketNumber,
    ticketPrefix: entry.ticketPrefix,
  }).catch(() => {});

  return { entry };
}

// ─────────────────────────────────────────────────────────────
// MARK SERVING / COMPLETE / NO-SHOW
// ─────────────────────────────────────────────────────────────
export async function markServing(entryId: string, sessionId: string) {
  const entry = await prisma.queueEntry.update({
    where: { id: entryId, sessionId, status: 'called' },
    data: { status: 'serving', servedAt: new Date() },
  });
  produceEvent(TOPICS.QUEUE_ENTRY_SERVED, entryId, { entryId, sessionId }).catch(() => {});
  return entry;
}

export async function completeEntry(entryId: string, sessionId: string) {
  const entry = await prisma.queueEntry.findFirst({ where: { id: entryId, sessionId } });
  if (!entry) throw AppError.notFound('Queue entry not found', ErrorCode.QUEUE_ENTRY_NOT_FOUND);

  const leftAt = new Date();
  const actualServiceSeconds = entry.servedAt
    ? Math.floor((leftAt.getTime() - entry.servedAt.getTime()) / 1000)
    : 0;

  const updated = await prisma.queueEntry.update({
    where: { id: entryId },
    data: { status: 'completed', leftAt, actualServiceSeconds },
  });

  // Update session stats — rolling average of service time
  await prisma.queueSession.update({
    where: { id: sessionId },
    data: { totalServed: { increment: 1 } },
  });

  // Update Redis rolling average
  const redis = getRedis();
  const stateData = await redis.hgetall(keys.sessionState(sessionId));
  const currentAvg = parseInt(stateData.avgServiceSeconds ?? '300', 10);
  const totalServed = parseInt(stateData.totalServed ?? '1', 10);
  const newAvg = Math.floor((currentAvg * totalServed + actualServiceSeconds) / (totalServed + 1));
  await redis.hset(keys.sessionState(sessionId), {
    totalServed: totalServed + 1,
    avgServiceSeconds: newAvg,
  });

  const session = await prisma.queueSession.findFirst({ where: { id: sessionId }, select: { businessId: true } });
  if (session) {
    await broadcastPositionUpdates(sessionId, session.businessId);
    const { io } = await import('../index');
    io.to(`biz:${session.businessId}`).emit('queue:dashboard_update', await getQueueState(sessionId));
  }

  produceEvent(TOPICS.QUEUE_ENTRY_COMPLETED, entryId, {
    entryId, sessionId, actualServiceSeconds,
    businessId: session?.businessId,
  }).catch(() => {});

  return updated;
}

export async function markNoShow(entryId: string, sessionId: string) {
  const updated = await prisma.queueEntry.update({
    where: { id: entryId, sessionId },
    data: { status: 'no_show', leftAt: new Date() },
  });

  const session = await prisma.queueSession.findFirst({ where: { id: sessionId }, select: { businessId: true } });
  if (session) {
    await broadcastPositionUpdates(sessionId, session.businessId);
  }

  produceEvent(TOPICS.QUEUE_ENTRY_NO_SHOW, entryId, { entryId, sessionId }).catch(() => {});
  return updated;
}

export async function leaveQueue(entryId: string, userId: string) {
  const entry = await prisma.queueEntry.findFirst({
    where: { id: entryId, userId, status: { in: ['waiting', 'called'] } },
  });
  if (!entry) throw AppError.notFound('Queue entry not found or already processed', ErrorCode.QUEUE_ENTRY_NOT_FOUND);

  const updated = await prisma.queueEntry.update({
    where: { id: entryId },
    data: { status: 'left', leftAt: new Date() },
  });

  const redis = getRedis();
  await redis.zrem(keys.waiters(entry.sessionId), entryId);
  await redis.del(keys.entryPosition(entryId));

  const session = await prisma.queueSession.findFirst({ where: { id: entry.sessionId }, select: { businessId: true } });
  if (session) {
    await broadcastPositionUpdates(entry.sessionId, session.businessId);
  }

  produceEvent(TOPICS.QUEUE_ENTRY_LEFT, entryId, { entryId, sessionId: entry.sessionId, userId }).catch(() => {});
  return updated;
}

// ─────────────────────────────────────────────────────────────
// BROADCAST POSITION UPDATES TO ALL WAITERS
// Called after every state change that affects positions
// ─────────────────────────────────────────────────────────────
async function broadcastPositionUpdates(sessionId: string, businessId: string) {
  const redis = getRedis();
  const { io } = await import('../index');
  const stateData = await redis.hgetall(keys.sessionState(sessionId));
  const avgServiceSeconds = parseInt(stateData.avgServiceSeconds ?? '300', 10);

  // Get all remaining waiters in order
  const waiters = await redis.zrange(keys.waiters(sessionId), 0, -1, 'WITHSCORES');

  for (let i = 0; i < waiters.length; i += 2) {
    const entryId = waiters[i]!;
    const position = i / 2 + 1;
    const estimatedWaitSeconds = (position - 1) * avgServiceSeconds;

    // Update position cache
    await redis.setex(keys.entryPosition(entryId), 30, String(position));

    // Get userId for this entry
    const entry = await prisma.queueEntry.findFirst({
      where: { id: entryId },
      select: { userId: true, ticketNumber: true, ticketPrefix: true },
    });

    if (entry?.userId) {
      io.to(`user:${entry.userId}`).emit('queue:position_updated', {
        entryId,
        position,
        estimatedWaitSeconds,
        ticketNumber: entry.ticketNumber,
        ticketDisplay: `${entry.ticketPrefix}${String(entry.ticketNumber).padStart(3, '0')}`,
      });
    }
  }
}

// ─── Helper functions ─────────────────────────
async function getOpenSession(sessionId: string, businessId: string) {
  const session = await prisma.queueSession.findFirst({
    where: { id: sessionId, businessId, status: { in: ['open', 'paused'] } },
  });
  if (!session) throw AppError.notFound('Queue session not found or not open', ErrorCode.QUEUE_NOT_OPEN);
  return session;
}

export async function getQueueState(sessionId: string) {
  const redis = getRedis();
  const [sessionState, totalWaiting, session] = await Promise.all([
    redis.hgetall(keys.sessionState(sessionId)),
    redis.zcard(keys.waiters(sessionId)),
    prisma.queueSession.findFirst({ where: { id: sessionId } }),
  ]);
  return { ...sessionState, totalWaiting, session };
}

export async function getQueueStatus(businessId: string) {
  const redis = getRedis();
  const today = new Date().toISOString().split('T')[0]!;
  const session = await prisma.queueSession.findFirst({
    where: { businessId, sessionDate: new Date(today) },
  });
  if (!session) return { isOpen: false, session: null };

  const stateData = await redis.hgetall(keys.sessionState(session.id));
  const totalWaiting = await redis.zcard(keys.waiters(session.id));

  return { isOpen: session.status === 'open', session, stateData, totalWaiting };
}

export async function getEntryStatus(entryId: string, userId: string) {
  const entry = await prisma.queueEntry.findFirst({
    where: { id: entryId, userId },
    include: { session: { include: { business: { select: { id: true, name: true } } } } },
  });
  if (!entry) throw AppError.notFound('Queue entry not found', ErrorCode.QUEUE_ENTRY_NOT_FOUND);

  const redis = getRedis();
  const cachedPosition = await redis.get(keys.entryPosition(entryId));
  const position = cachedPosition ? parseInt(cachedPosition, 10) : null;

  return { entry, position };
}
