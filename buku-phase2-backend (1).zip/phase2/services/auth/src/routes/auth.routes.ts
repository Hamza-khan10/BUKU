import { Router } from 'express';
import {
  authenticateToken, validateRequest, asyncHandler,
  requireRole, logger,
} from '@buku/common';
import { z } from 'zod';
import * as AuthService from '../services/auth.service';

export const authRouter = Router();

// ─── Validation schemas ───────────────────────────────────────────
const phoneRegex = /^\+[1-9]\d{6,14}$/;
const emailSchema = z.string().email().toLowerCase().trim();
const phoneSchema = z.string().regex(phoneRegex, 'Invalid phone number (+country code required)');
const passwordSchema = z.string()
  .min(8, 'Password must be at least 8 characters')
  .regex(/[A-Z]/, 'Must contain uppercase')
  .regex(/[0-9]/, 'Must contain number');

const RegisterSchema = z.object({
  name: z.string().min(2).max(200).trim(),
  email: emailSchema.optional(),
  phone: phoneSchema.optional(),
  password: passwordSchema.optional(),
  role: z.enum(['user', 'business_owner']).default('user'),
}).refine(d => d.email || d.phone, { message: 'email or phone required' });

const VerifyOtpSchema = z.object({
  destination: z.string(), // email or phone
  otp: z.string().length(6).regex(/^\d{6}$/),
});

const ResendOtpSchema = z.object({
  destination: z.string(),
});

const LoginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1),
});

const RefreshSchema = z.object({
  refreshToken: z.string().min(10),
});

const LogoutSchema = z.object({
  refreshToken: z.string().min(10),
});

const ForgotPasswordSchema = z.object({
  email: emailSchema,
});

const ResetPasswordSchema = z.object({
  token: z.string().min(10),
  password: passwordSchema,
});

const ChangePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: passwordSchema,
});

const UpdateProfileSchema = z.object({
  name: z.string().min(2).max(200).trim().optional(),
  timezone: z.string().max(60).optional(),
  locale: z.enum(['en', 'ur', 'ar']).optional(),
});

const PushTokenSchema = z.object({
  token: z.string().min(10),
  platform: z.enum(['ios', 'android', 'web']),
});

const GoogleOAuthSchema = z.object({
  idToken: z.string().min(10),
  role: z.enum(['user', 'business_owner']).default('user'),
});

const AppleOAuthSchema = z.object({
  identityToken: z.string().min(10),
  authorizationCode: z.string().optional(),
  name: z.string().optional(),
  role: z.enum(['user', 'business_owner']).default('user'),
});

// ─── PUBLIC ROUTES ───────────────────────────────────────────────
// POST /v1/auth/register
authRouter.post('/register',
  validateRequest(RegisterSchema),
  asyncHandler(async (req, res) => {
    const result = await AuthService.register(req.body);
    res.status(201).json({ success: true, data: result });
  }),
);

// POST /v1/auth/verify-otp
authRouter.post('/verify-otp',
  validateRequest(VerifyOtpSchema),
  asyncHandler(async (req, res) => {
    const { destination, otp } = req.body as z.infer<typeof VerifyOtpSchema>;
    const ip = req.ip ?? '0.0.0.0';
    const result = await AuthService.verifyOtp(destination, otp, ip);
    res.json({ success: true, data: result });
  }),
);

// POST /v1/auth/resend-otp
authRouter.post('/resend-otp',
  validateRequest(ResendOtpSchema),
  asyncHandler(async (req, res) => {
    const { destination } = req.body as z.infer<typeof ResendOtpSchema>;
    const ip = req.ip ?? '0.0.0.0';
    await AuthService.resendOtp(destination, ip);
    res.json({ success: true, data: { message: 'OTP sent' } });
  }),
);

// POST /v1/auth/login
authRouter.post('/login',
  validateRequest(LoginSchema),
  asyncHandler(async (req, res) => {
    const { email, password } = req.body as z.infer<typeof LoginSchema>;
    const ip = req.ip ?? '0.0.0.0';
    const deviceInfo = { userAgent: req.headers['user-agent'] ?? '' };
    const result = await AuthService.login(email, password, ip, deviceInfo);
    res.json({ success: true, data: result });
  }),
);

// POST /v1/auth/refresh
authRouter.post('/refresh',
  validateRequest(RefreshSchema),
  asyncHandler(async (req, res) => {
    const { refreshToken } = req.body as z.infer<typeof RefreshSchema>;
    const ip = req.ip ?? '0.0.0.0';
    const deviceInfo = { userAgent: req.headers['user-agent'] ?? '' };
    const result = await AuthService.refreshTokens(refreshToken, ip, deviceInfo);
    res.json({ success: true, data: result });
  }),
);

// POST /v1/auth/logout
authRouter.post('/logout',
  validateRequest(LogoutSchema),
  asyncHandler(async (req, res) => {
    const { refreshToken } = req.body as z.infer<typeof LogoutSchema>;
    await AuthService.logout(refreshToken);
    res.json({ success: true, data: { message: 'Logged out successfully' } });
  }),
);

// POST /v1/auth/forgot-password
authRouter.post('/forgot-password',
  validateRequest(ForgotPasswordSchema),
  asyncHandler(async (req, res) => {
    const { email } = req.body as z.infer<typeof ForgotPasswordSchema>;
    await AuthService.forgotPassword(email);
    // Always return success to prevent email enumeration
    res.json({ success: true, data: { message: 'If this email exists, a reset link has been sent' } });
  }),
);

// POST /v1/auth/reset-password
authRouter.post('/reset-password',
  validateRequest(ResetPasswordSchema),
  asyncHandler(async (req, res) => {
    const { token, password } = req.body as z.infer<typeof ResetPasswordSchema>;
    await AuthService.resetPassword(token, password);
    res.json({ success: true, data: { message: 'Password reset successfully' } });
  }),
);

// OAuth
authRouter.post('/oauth/google',
  validateRequest(GoogleOAuthSchema),
  asyncHandler(async (req, res) => {
    const { idToken, role } = req.body as z.infer<typeof GoogleOAuthSchema>;
    const ip = req.ip ?? '0.0.0.0';
    const deviceInfo = { userAgent: req.headers['user-agent'] ?? '' };
    const result = await AuthService.googleOAuth(idToken, role, ip, deviceInfo);
    res.json({ success: true, data: result });
  }),
);

authRouter.post('/oauth/apple',
  validateRequest(AppleOAuthSchema),
  asyncHandler(async (req, res) => {
    const { identityToken, name, role } = req.body as z.infer<typeof AppleOAuthSchema>;
    const ip = req.ip ?? '0.0.0.0';
    const deviceInfo = { userAgent: req.headers['user-agent'] ?? '' };
    const result = await AuthService.appleOAuth(identityToken, name, role, ip, deviceInfo);
    res.json({ success: true, data: result });
  }),
);

// ─── PROTECTED ROUTES ────────────────────────────────────────────
authRouter.use(authenticateToken());

// POST /v1/auth/logout-all
authRouter.post('/logout-all',
  asyncHandler(async (req, res) => {
    await AuthService.logoutAll(req.user!.sub);
    res.json({ success: true, data: { message: 'All sessions terminated' } });
  }),
);

// POST /v1/auth/change-password
authRouter.post('/change-password',
  validateRequest(ChangePasswordSchema),
  asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body as z.infer<typeof ChangePasswordSchema>;
    await AuthService.changePassword(req.user!.sub, currentPassword, newPassword);
    res.json({ success: true, data: { message: 'Password changed successfully' } });
  }),
);

// GET /v1/auth/me
authRouter.get('/me',
  asyncHandler(async (req, res) => {
    const user = await AuthService.getMe(req.user!.sub);
    res.json({ success: true, data: { user } });
  }),
);

// PATCH /v1/auth/me
authRouter.patch('/me',
  validateRequest(UpdateProfileSchema),
  asyncHandler(async (req, res) => {
    const user = await AuthService.updateProfile(req.user!.sub, req.body);
    res.json({ success: true, data: { user } });
  }),
);

// POST /v1/auth/me/avatar
authRouter.post('/me/avatar',
  asyncHandler(async (req, res) => {
    // File handled by multer middleware — set up in production with S3
    const { avatarUrl } = await AuthService.uploadAvatar(req.user!.sub, req);
    res.json({ success: true, data: { avatarUrl } });
  }),
);

// DELETE /v1/auth/me — GDPR soft-delete
authRouter.delete('/me',
  asyncHandler(async (req, res) => {
    await AuthService.deleteAccount(req.user!.sub);
    res.json({ success: true, data: { message: 'Account deleted. Data will be permanently removed in 30 days.' } });
  }),
);

// POST /v1/auth/push-token
authRouter.post('/push-token',
  validateRequest(PushTokenSchema),
  asyncHandler(async (req, res) => {
    const { token, platform } = req.body as z.infer<typeof PushTokenSchema>;
    await AuthService.registerPushToken(req.user!.sub, token, platform);
    res.json({ success: true, data: { message: 'Push token registered' } });
  }),
);

// DELETE /v1/auth/push-token/:token
authRouter.delete('/push-token/:token',
  asyncHandler(async (req, res) => {
    await AuthService.removePushToken(req.user!.sub, req.params.token!);
    res.json({ success: true, data: { message: 'Push token removed' } });
  }),
);

// GET /v1/auth/me/export — GDPR data export
authRouter.get('/me/export',
  asyncHandler(async (req, res) => {
    const data = await AuthService.exportUserData(req.user!.sub);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename="buku-data-export.json"');
    res.json({ success: true, data });
  }),
);
