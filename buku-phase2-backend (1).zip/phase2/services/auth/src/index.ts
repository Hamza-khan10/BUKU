import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { requestId, requestLogger, errorHandler, notFoundHandler, logger } from '@buku/common';
import { authRouter } from './routes/auth.routes';

const app = express();
const PORT = parseInt(process.env.PORT ?? '3001', 10);

// ── Security middleware ───────────────────────
app.use(helmet({
  contentSecurityPolicy: false, // handled by Nginx
  crossOriginEmbedderPolicy: false,
}));

app.use(cors({
  origin: (process.env.FRONTEND_URL ?? 'http://localhost:3000').split(','),
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID'],
  maxAge: 86400,
}));

// ── Core middleware ───────────────────────────
app.use(requestId());
app.use(requestLogger());
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

// ── Health endpoints ──────────────────────────
app.get('/health', (_req, res) => {
  res.json({ success: true, data: { status: 'ok', service: 'auth-service', timestamp: new Date().toISOString() } });
});

app.get('/ready', async (_req, res) => {
  try {
    const { prisma } = await import('@buku/database');
    await prisma.$queryRaw`SELECT 1`;
    res.json({ success: true, data: { status: 'ready' } });
  } catch (err) {
    res.status(503).json({ success: false, error: { code: 'NOT_READY', message: 'Database not ready' } });
  }
});

// ── Routes ────────────────────────────────────
app.use('/v1/auth', authRouter);

// ── Error handling ────────────────────────────
app.use(notFoundHandler());
app.use(errorHandler());

// ── Graceful shutdown ─────────────────────────
const server = app.listen(PORT, () => {
  logger.info({ message: `Auth service listening on port ${PORT}`, port: PORT });
});

const shutdown = async (signal: string) => {
  logger.info({ message: `${signal} received, shutting down gracefully` });
  server.close(async () => {
    const { disconnectDatabase } = await import('@buku/database');
    const { disconnectKafka } = await import('@buku/kafka');
    await Promise.all([disconnectDatabase(), disconnectKafka()]);
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 30000);
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (reason) => {
  logger.error({ message: 'Unhandled rejection', reason: String(reason) });
});
