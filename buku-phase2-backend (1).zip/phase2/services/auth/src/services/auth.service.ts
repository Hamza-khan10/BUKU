import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Redis } from 'ioredis';
import { prisma } from '@buku/database';
import { AppError, ErrorCode, generateOtp, generateSecureToken, hashToken, verifyToken, logger } from '@buku/common';
import { produceEvent, TOPICS } from '@buku/kafka';
import type { Request } from 'express';

// ─── Redis client (lazily initialized) ───────────
let redisClient: Redis | null = null;
function getRedis(): Redis {
  if (!redisClient) {
    redisClient = new Redis(process.env.REDIS_URL ?? 'redis://redis:6379', {
      maxRetriesPerRequest: 3,
      lazyConnect: false,
    });
    redisClient.on('error', (err) => logger.error({ message: 'Redis error in auth-service', error: String(err) }));
  }
  return redisClient;
}

// ─── JWT helpers ─────────────────────────────────
function getPrivateKey(): string {
  const key = process.env.JWT_PRIVATE_KEY ?? '';
  if (!key) throw new Error('JWT_PRIVATE_KEY not configured');
  return key.includes('BEGIN') ? key : Buffer.from(key, 'base64').toString('utf8');
}

function getPublicKey(): string {
  const key = process.env.JWT_PUBLIC_KEY ?? '';
  if (!key) throw new Error('JWT_PUBLIC_KEY not configured');
  return key.includes('BEGIN') ? key : Buffer.from(key, 'base64').toString('utf8');
}

function issueAccessToken(userId: string, role: string): string {
  const jti = crypto.randomUUID();
  return jwt.sign({ sub: userId, role, jti }, getPrivateKey(), {
    algorithm: 'RS256',
    expiresIn: process.env.JWT_ACCESS_EXPIRES_IN ?? '15m',
  });
}

async function issueRefreshToken(userId: string, ip: string, deviceInfo: object): Promise<string> {
  const token = generateSecureToken();
  const tokenHash = await hashToken(token, 10);
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

  await prisma.refreshToken.create({
    data: { userId, tokenHash, ipAddress: ip, deviceInfo, expiresAt },
  });

  // Also store token hash in Redis whitelist (fast lookup)
  const redis = getRedis();
  await redis.setex(`refresh:${tokenHash}`, 7 * 24 * 60 * 60, userId);

  return token;
}

async function revokeRefreshToken(token: string): Promise<void> {
  // Find by matching against stored hashes — efficient via DB index
  const stored = await prisma.refreshToken.findFirst({
    where: { revokedAt: null, expiresAt: { gt: new Date() } },
  });
  // We can't efficiently reverse-hash, so we look up by userId then match
  // Better: store token in Redis with its hash during login so we can look up by token directly
  const redis = getRedis();
  // The token is base64(random 32 bytes) — use first 8 chars as fast lookup key
  const lookupKey = `refresh_lookup:${token.substring(0, 16)}`;
  const storedHash = await redis.get(lookupKey);
  if (storedHash) {
    await prisma.refreshToken.updateMany({
      where: { tokenHash: storedHash },
      data: { revokedAt: new Date() },
    });
    await redis.del(lookupKey, `refresh:${storedHash}`);
  }
}

async function issueTokenPair(
  userId: string,
  role: string,
  ip: string,
  deviceInfo: object,
): Promise<{ accessToken: string; refreshToken: string }> {
  const [accessToken, refreshToken] = await Promise.all([
    Promise.resolve(issueAccessToken(userId, role)),
    issueRefreshToken(userId, ip, deviceInfo),
  ]);

  // Store lookup mapping: token_prefix → hash (for efficient revocation)
  const redis = getRedis();
  const tokenHash = await hashToken(refreshToken, 10);
  await redis.setex(`refresh_lookup:${refreshToken.substring(0, 16)}`, 7 * 24 * 60 * 60, tokenHash);

  return { accessToken, refreshToken };
}

// ─── OTP helpers ─────────────────────────────────
const OTP_TTL = 600; // 10 minutes
const OTP_MAX_ATTEMPTS = 3;
const OTP_LOCKOUT_TTL = 900; // 15 minutes
const OTP_RATE_LIMIT_TTL = 3600; // 1 hour
const OTP_RATE_LIMIT_MAX = 3;
const BCRYPT_ROUNDS = parseInt(process.env.BCRYPT_ROUNDS ?? '10', 10);

async function sendOtp(destination: string, otp: string): Promise<void> {
  const isEmail = destination.includes('@');
  if (isEmail) {
    // Send via SES (LocalStack in dev)
    try {
      const { SESClient, SendEmailCommand } = await import('@aws-sdk/client-ses');
      const ses = new SESClient({
        region: process.env.AWS_REGION ?? 'us-east-1',
        endpoint: process.env.AWS_ENDPOINT_URL,
        credentials: {
          accessKeyId: process.env.AWS_ACCESS_KEY_ID ?? '',
          secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ?? '',
        },
      });
      await ses.send(new SendEmailCommand({
        Source: process.env.AWS_SES_FROM_EMAIL ?? 'noreply@buku.app',
        Destination: { ToAddresses: [destination] },
        Message: {
          Subject: { Data: 'Your BUKU verification code' },
          Body: {
            Text: { Data: `Your BUKU verification code is: ${otp}\n\nThis code expires in 10 minutes.\n\nIf you did not request this, please ignore this email.` },
            Html: { Data: `<h2>Your BUKU verification code</h2><p>Your code is: <strong style="font-size:24px;letter-spacing:4px;">${otp}</strong></p><p>This code expires in 10 minutes.</p>` },
          },
        },
      }));
    } catch (err) {
      logger.warn({ message: 'SES send failed (dev mode OK)', error: String(err) });
    }
  } else {
    // Send via Twilio
    try {
      const accountSid = process.env.TWILIO_ACCOUNT_SID;
      const authToken = process.env.TWILIO_AUTH_TOKEN;
      const from = process.env.TWILIO_FROM_NUMBER;
      if (accountSid && authToken && from && !accountSid.includes('mock')) {
        const twilio = (await import('twilio')).default;
        const client = twilio(accountSid, authToken);
        await client.messages.create({
          body: `Your BUKU verification code: ${otp}. Expires in 10 minutes.`,
          from,
          to: destination,
        });
      } else {
        logger.info({ message: `[DEV] OTP for ${destination}: ${otp}` });
      }
    } catch (err) {
      logger.warn({ message: 'Twilio send failed (dev mode OK)', error: String(err) });
      logger.info({ message: `[DEV] OTP for ${destination}: ${otp}` });
    }
  }
}

// ─── SERVICE FUNCTIONS ────────────────────────────
export async function register(body: {
  name: string; email?: string; phone?: string;
  password?: string; role: string;
}) {
  const { name, email, phone, password, role } = body;
  const redis = getRedis();

  // Check existing user
  const existing = await prisma.user.findFirst({
    where: { OR: [email ? { email } : {}, phone ? { phone } : {}].filter(o => Object.keys(o).length > 0) },
  });
  if (existing) {
    throw AppError.conflict('Account already exists with this email or phone', ErrorCode.USER_EXISTS);
  }

  // Rate limit OTP sends
  const destination = email ?? phone!;
  const rateKey = `otp_rate:${destination}`;
  const sends = await redis.incr(rateKey);
  if (sends === 1) await redis.expire(rateKey, OTP_RATE_LIMIT_TTL);
  if (sends > OTP_RATE_LIMIT_MAX) {
    throw AppError.tooManyRequests('Too many OTP requests. Try again in 1 hour.');
  }

  // Create user
  const hashedPassword = password ? await bcrypt.hash(password, BCRYPT_ROUNDS) : null;
  const user = await prisma.user.create({
    data: {
      name: name.trim(),
      email: email ?? null,
      phone: phone ?? null,
      role: role as 'user' | 'business_owner',
      status: 'active',
    },
    select: { id: true, name: true, email: true, phone: true, role: true },
  });

  // Generate and store OTP
  const otp = generateOtp();
  const otpHash = await bcrypt.hash(otp, BCRYPT_ROUNDS);
  await redis.setex(`otp:${destination}`, OTP_TTL, JSON.stringify({ hash: otpHash, userId: user.id, attempts: 0 }));

  // Send OTP
  await sendOtp(destination, otp);

  // Publish event (fire and forget)
  produceEvent(TOPICS.USERS_REGISTERED, user.id, {
    userId: user.id, name: user.name, email: user.email, phone: user.phone, role: user.role,
  }).catch(() => {});

  return { message: 'OTP sent. Please verify your account.', userId: user.id };
}

export async function verifyOtp(
  destination: string,
  otp: string,
  ip: string,
): Promise<{ accessToken: string; refreshToken: string; user: object }> {
  const redis = getRedis();

  // Check lockout
  const lockKey = `otp_lock:${ip}:${destination}`;
  const locked = await redis.get(lockKey);
  if (locked) {
    throw AppError.tooManyRequests('Too many failed attempts. Try again in 15 minutes.');
  }

  const stored = await redis.get(`otp:${destination}`);
  if (!stored) {
    throw AppError.badRequest('OTP expired or not found. Please request a new one.', ErrorCode.OTP_EXPIRED);
  }

  const { hash, userId, attempts } = JSON.parse(stored) as { hash: string; userId: string; attempts: number };

  if (attempts >= OTP_MAX_ATTEMPTS) {
    await redis.del(`otp:${destination}`);
    await redis.setex(lockKey, OTP_LOCKOUT_TTL, '1');
    throw AppError.badRequest('Too many failed attempts. Request a new OTP.', ErrorCode.OTP_MAX_ATTEMPTS);
  }

  const valid = await bcrypt.compare(otp, hash);
  if (!valid) {
    // Increment attempts
    const newAttempts = attempts + 1;
    if (newAttempts >= OTP_MAX_ATTEMPTS) {
      await redis.del(`otp:${destination}`);
      await redis.setex(lockKey, OTP_LOCKOUT_TTL, '1');
      throw AppError.badRequest('Invalid OTP. Account locked for 15 minutes.', ErrorCode.OTP_INVALID);
    }
    await redis.setex(`otp:${destination}`, OTP_TTL, JSON.stringify({ hash, userId, attempts: newAttempts }));
    throw AppError.badRequest(`Invalid OTP. ${OTP_MAX_ATTEMPTS - newAttempts} attempts remaining.`, ErrorCode.OTP_INVALID);
  }

  // OTP valid — delete it
  await redis.del(`otp:${destination}`);

  // Mark user as verified
  const isEmail = destination.includes('@');
  const user = await prisma.user.update({
    where: { id: userId },
    data: {
      emailVerifiedAt: isEmail ? new Date() : undefined,
      phoneVerifiedAt: !isEmail ? new Date() : undefined,
    },
    select: { id: true, name: true, email: true, phone: true, role: true, status: true, createdAt: true },
  });

  const tokens = await issueTokenPair(userId, user.role, ip, { via: 'otp' });

  produceEvent(TOPICS.USERS_VERIFIED, userId, { userId, destination }).catch(() => {});

  return { ...tokens, user };
}

export async function resendOtp(destination: string, ip: string): Promise<void> {
  const redis = getRedis();

  // Rate limit
  const rateKey = `otp_rate:${destination}`;
  const sends = await redis.incr(rateKey);
  if (sends === 1) await redis.expire(rateKey, OTP_RATE_LIMIT_TTL);
  if (sends > OTP_RATE_LIMIT_MAX) {
    throw AppError.tooManyRequests('Too many OTP requests. Try again in 1 hour.');
  }

  // Must have existing user
  const user = await prisma.user.findFirst({
    where: { OR: [{ email: destination }, { phone: destination }] },
  });
  if (!user) {
    // Return success anyway to prevent enumeration
    return;
  }

  const otp = generateOtp();
  const otpHash = await bcrypt.hash(otp, BCRYPT_ROUNDS);
  await redis.setex(`otp:${destination}`, OTP_TTL, JSON.stringify({ hash: otpHash, userId: user.id, attempts: 0 }));
  await sendOtp(destination, otp);
}

export async function login(
  email: string,
  password: string,
  ip: string,
  deviceInfo: object,
): Promise<{ accessToken: string; refreshToken: string; user: object }> {
  const user = await prisma.user.findFirst({
    where: { email, status: 'active' },
    select: { id: true, name: true, email: true, phone: true, role: true, status: true },
  });

  // Timing-safe: always check password even if user not found
  const dummyHash = '$2b$10$invalidhashfortimingprotection00000000000000000000';
  const passwordValid = await bcrypt.compare(password, user ? dummyHash : dummyHash);

  if (!user || !passwordValid) {
    throw AppError.unauthorized('Invalid email or password', ErrorCode.INVALID_CREDENTIALS);
  }

  const tokens = await issueTokenPair(user.id, user.role, ip, deviceInfo);
  return { ...tokens, user };
}

export async function refreshTokens(
  refreshToken: string,
  ip: string,
  deviceInfo: object,
): Promise<{ accessToken: string; refreshToken: string }> {
  const redis = getRedis();

  // Look up the token hash via prefix lookup
  const lookupKey = `refresh_lookup:${refreshToken.substring(0, 16)}`;
  const storedHash = await redis.get(lookupKey);
  if (!storedHash) {
    throw AppError.unauthorized('Invalid or expired refresh token', ErrorCode.REFRESH_TOKEN_INVALID);
  }

  // Verify against DB
  const dbToken = await prisma.refreshToken.findFirst({
    where: { tokenHash: storedHash, revokedAt: null, expiresAt: { gt: new Date() } },
    include: { user: { select: { id: true, role: true, status: true } } },
  });

  if (!dbToken || !dbToken.user || dbToken.user.status !== 'active') {
    throw AppError.unauthorized('Invalid or expired refresh token', ErrorCode.REFRESH_TOKEN_INVALID);
  }

  // Verify token hash matches
  const valid = await verifyToken(refreshToken, storedHash);
  if (!valid) {
    throw AppError.unauthorized('Invalid refresh token', ErrorCode.REFRESH_TOKEN_INVALID);
  }

  // Revoke old token (rotation)
  await Promise.all([
    prisma.refreshToken.update({ where: { id: dbToken.id }, data: { revokedAt: new Date() } }),
    redis.del(lookupKey, `refresh:${storedHash}`),
  ]);

  // Issue new token pair
  const tokens = await issueTokenPair(dbToken.user.id, dbToken.user.role, ip, deviceInfo);
  return tokens;
}

export async function logout(refreshToken: string): Promise<void> {
  await revokeRefreshToken(refreshToken);
}

export async function logoutAll(userId: string): Promise<void> {
  const redis = getRedis();
  const tokens = await prisma.refreshToken.findMany({
    where: { userId, revokedAt: null },
    select: { tokenHash: true },
  });

  await prisma.refreshToken.updateMany({
    where: { userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });

  // Remove from Redis
  if (tokens.length > 0) {
    const keys = tokens.flatMap(t => [`refresh:${t.tokenHash}`]);
    if (keys.length > 0) await redis.del(...keys);
  }
}

export async function forgotPassword(email: string): Promise<void> {
  const user = await prisma.user.findFirst({ where: { email, status: 'active' } });
  if (!user) return; // Silent — don't enumerate

  const token = generateSecureToken();
  const tokenHash = await hashToken(token, 10);
  const redis = getRedis();
  await redis.setex(`pwd_reset:${tokenHash}`, 3600, user.id); // 1hr TTL

  // Send email
  try {
    const { SESClient, SendEmailCommand } = await import('@aws-sdk/client-ses');
    const ses = new SESClient({
      region: process.env.AWS_REGION ?? 'us-east-1',
      endpoint: process.env.AWS_ENDPOINT_URL,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID ?? '',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ?? '',
      },
    });
    const resetUrl = `${process.env.FRONTEND_URL}/auth/reset-password?token=${token}`;
    await ses.send(new SendEmailCommand({
      Source: process.env.AWS_SES_FROM_EMAIL ?? 'noreply@buku.app',
      Destination: { ToAddresses: [email] },
      Message: {
        Subject: { Data: 'Reset your BUKU password' },
        Body: {
          Html: { Data: `<h2>Reset your password</h2><p><a href="${resetUrl}">Click here to reset your password</a></p><p>This link expires in 1 hour.</p>` },
          Text: { Data: `Reset your BUKU password: ${resetUrl}\n\nExpires in 1 hour.` },
        },
      },
    }));
  } catch (err) {
    logger.warn({ message: 'Password reset email failed', error: String(err) });
    logger.info({ message: '[DEV] Password reset token', token }); // Log in dev
  }
}

export async function resetPassword(token: string, newPassword: string): Promise<void> {
  const redis = getRedis();
  const tokenHash = await hashToken(token, 10);
  const userId = await redis.get(`pwd_reset:${tokenHash}`);
  if (!userId) {
    throw AppError.badRequest('Invalid or expired reset token', ErrorCode.TOKEN_EXPIRED);
  }

  const hashedPassword = await bcrypt.hash(newPassword, BCRYPT_ROUNDS);

  // Update password and invalidate all sessions
  await Promise.all([
    prisma.user.update({ where: { id: userId }, data: {} }), // password field when added
    logoutAll(userId),
    redis.del(`pwd_reset:${tokenHash}`),
  ]);

  logger.info({ message: 'Password reset successful', userId });
}

export async function changePassword(userId: string, currentPassword: string, newPassword: string): Promise<void> {
  // For future: verify current password from DB, update to new
  logger.info({ message: 'Password change requested', userId });
  await bcrypt.hash(newPassword, BCRYPT_ROUNDS);
  // Invalidate all other sessions
  await logoutAll(userId);
}

export async function googleOAuth(
  idToken: string,
  role: string,
  ip: string,
  deviceInfo: object,
): Promise<{ accessToken: string; refreshToken: string; user: object; isNewUser: boolean }> {
  try {
    const { OAuth2Client } = await import('google-auth-library');
    const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
    const ticket = await client.verifyIdToken({
      idToken,
      audience: process.env.GOOGLE_CLIENT_ID,
    });
    const payload = ticket.getPayload();
    if (!payload?.email) throw new Error('No email in Google token');

    let user = await prisma.user.findFirst({ where: { email: payload.email } });
    const isNewUser = !user;

    if (!user) {
      user = await prisma.user.create({
        data: {
          email: payload.email,
          name: payload.name ?? payload.email.split('@')[0]!,
          role: role as 'user' | 'business_owner',
          status: 'active',
          emailVerifiedAt: new Date(),
          avatarUrl: payload.picture ?? null,
        },
      });
      produceEvent(TOPICS.USERS_REGISTERED, user.id, { userId: user.id, name: user.name, email: user.email, role: user.role, via: 'google' }).catch(() => {});
    }

    const tokens = await issueTokenPair(user.id, user.role, ip, deviceInfo);
    return { ...tokens, user: { id: user.id, name: user.name, email: user.email, role: user.role }, isNewUser };
  } catch (err) {
    logger.error({ message: 'Google OAuth failed', error: String(err) });
    throw AppError.unauthorized('Invalid Google token', ErrorCode.TOKEN_INVALID);
  }
}

export async function appleOAuth(
  identityToken: string,
  name: string | undefined,
  role: string,
  ip: string,
  deviceInfo: object,
): Promise<{ accessToken: string; refreshToken: string; user: object; isNewUser: boolean }> {
  try {
    // Verify Apple identity token (simplified — use apple-auth lib in production)
    const parts = identityToken.split('.');
    if (parts.length !== 3) throw new Error('Invalid Apple token');
    const payload = JSON.parse(Buffer.from(parts[1]!, 'base64url').toString()) as { email?: string; sub: string };
    if (!payload.sub) throw new Error('No sub in Apple token');

    const email = payload.email ?? `${payload.sub}@privaterelay.appleid.com`;
    let user = await prisma.user.findFirst({ where: { email } });
    const isNewUser = !user;

    if (!user) {
      user = await prisma.user.create({
        data: {
          email,
          name: name ?? email.split('@')[0]!,
          role: role as 'user' | 'business_owner',
          status: 'active',
          emailVerifiedAt: new Date(),
        },
      });
      produceEvent(TOPICS.USERS_REGISTERED, user.id, { userId: user.id, name: user.name, email: user.email, role: user.role, via: 'apple' }).catch(() => {});
    }

    const tokens = await issueTokenPair(user.id, user.role, ip, deviceInfo);
    return { ...tokens, user: { id: user.id, name: user.name, email: user.email, role: user.role }, isNewUser };
  } catch (err) {
    logger.error({ message: 'Apple OAuth failed', error: String(err) });
    throw AppError.unauthorized('Invalid Apple token', ErrorCode.TOKEN_INVALID);
  }
}

export async function getMe(userId: string) {
  const user = await prisma.user.findFirst({
    where: { id: userId },
    select: {
      id: true, name: true, email: true, phone: true, role: true, status: true,
      avatarUrl: true, timezone: true, locale: true,
      emailVerifiedAt: true, phoneVerifiedAt: true, createdAt: true,
    },
  });
  if (!user) throw AppError.notFound('User not found', ErrorCode.USER_NOT_FOUND);
  return user;
}

export async function updateProfile(userId: string, data: { name?: string; timezone?: string; locale?: string }) {
  const user = await prisma.user.update({
    where: { id: userId },
    data: {
      ...(data.name ? { name: data.name.trim() } : {}),
      ...(data.timezone ? { timezone: data.timezone } : {}),
      ...(data.locale ? { locale: data.locale } : {}),
    },
    select: { id: true, name: true, email: true, phone: true, role: true, timezone: true, locale: true },
  });
  return user;
}

export async function uploadAvatar(userId: string, _req: Request): Promise<{ avatarUrl: string }> {
  // In dev: return placeholder. In production: use multer + S3
  const avatarUrl = `https://api.dicebear.com/7.x/initials/svg?seed=${userId}`;
  await prisma.user.update({ where: { id: userId }, data: { avatarUrl } });
  return { avatarUrl };
}

export async function deleteAccount(userId: string): Promise<void> {
  await prisma.user.update({
    where: { id: userId },
    data: { deletedAt: new Date(), status: 'deleted' },
  });
  await logoutAll(userId);
  produceEvent(TOPICS.USERS_DELETED, userId, { userId }).catch(() => {});
}

export async function registerPushToken(userId: string, token: string, platform: string): Promise<void> {
  await prisma.pushToken.upsert({
    where: { token },
    update: { userId, platform: platform as 'ios' | 'android' | 'web', isActive: true },
    create: { userId, token, platform: platform as 'ios' | 'android' | 'web', isActive: true },
  });
}

export async function removePushToken(userId: string, token: string): Promise<void> {
  await prisma.pushToken.updateMany({
    where: { userId, token },
    data: { isActive: false },
  });
}

export async function exportUserData(userId: string) {
  const [user, appointments, reviews, notifications] = await Promise.all([
    prisma.user.findFirst({ where: { id: userId } }),
    prisma.appointment.findMany({ where: { userId }, take: 1000 }),
    prisma.review.findMany({ where: { userId }, take: 500 }),
    prisma.notification.findMany({ where: { userId }, take: 500, orderBy: { createdAt: 'desc' } }),
  ]);
  return { exportedAt: new Date().toISOString(), user, appointments, reviews, notifications };
}
