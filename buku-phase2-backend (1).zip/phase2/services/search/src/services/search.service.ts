import { Client as ESClient } from '@elastic/elasticsearch';
import { prisma } from '@buku/database';
import { AppError, ErrorCode, logger, getPagination, paginationMeta } from '@buku/common';
import type { Request } from 'express';

let esClient: ESClient | null = null;
function getES(): ESClient {
  if (!esClient) {
    esClient = new ESClient({ node: process.env.ELASTICSEARCH_URL ?? 'http://elasticsearch:9200' });
  }
  return esClient;
}

// ── Check if ES index needs rebuild ──────────────────────────
export async function ensureESIndex() {
  const es = getES();
  const indexName = 'businesses';
  try {
    const exists = await es.indices.exists({ index: indexName });
    if (!exists) {
      await createESIndex();
      await rebuildESIndex();
      return;
    }
    // Check count ratio
    const [esCount, pgCount] = await Promise.all([
      es.count({ index: indexName }).then(r => r.count),
      prisma.business.count({ where: { status: { not: 'deleted' } } }),
    ]);
    if (pgCount > 0 && esCount < pgCount * 0.1) {
      logger.warn({ message: 'ES index has less than 10% of PG businesses — rebuilding', esCount, pgCount });
      await rebuildESIndex();
    }
  } catch (err) {
    logger.error({ message: 'ES index check failed', error: String(err) });
  }
}

async function createESIndex() {
  const es = getES();
  await es.indices.create({
    index: 'businesses',
    mappings: {
      properties: {
        name: { type: 'text', analyzer: 'english', fields: { keyword: { type: 'keyword' }, suggest: { type: 'completion' } } },
        description: { type: 'text', analyzer: 'english' },
        category: { type: 'keyword' },
        tags: { type: 'keyword' },
        location: { type: 'geo_point' },
        avg_rating: { type: 'float' },
        review_count: { type: 'integer' },
        verified: { type: 'boolean' },
        status: { type: 'keyword' },
        city: { type: 'keyword' },
        country: { type: 'keyword' },
        staff_count: { type: 'integer' },
        services: {
          type: 'nested',
          properties: {
            id: { type: 'keyword' },
            name: { type: 'text' },
            duration_minutes: { type: 'integer' },
            price: { type: 'float' },
          },
        },
      },
    },
    settings: { number_of_shards: 1, number_of_replicas: 1 },
  });
  logger.info({ message: 'ES businesses index created' });
}

async function rebuildESIndex() {
  const es = getES();
  const businesses = await prisma.business.findMany({
    where: { status: { not: 'deleted' } },
    include: {
      services: { where: { isActive: true }, select: { id: true, name: true, durationMinutes: true, price: true } },
      category: { select: { name: true, slug: true } },
      reviews: { select: { rating: true } },
    },
    take: 10000,
  });

  const body = businesses.flatMap(biz => {
    const avgRating = biz.reviews.length > 0
      ? biz.reviews.reduce((s, r) => s + r.rating, 0) / biz.reviews.length
      : 0;
    return [
      { index: { _index: 'businesses', _id: biz.id } },
      {
        id: biz.id,
        name: biz.name,
        description: biz.description ?? '',
        category: biz.category?.slug ?? biz.categoryId,
        tags: (biz.tags as string[]) ?? [],
        location: biz.latitude && biz.longitude ? { lat: Number(biz.latitude), lon: Number(biz.longitude) } : null,
        avg_rating: parseFloat(avgRating.toFixed(2)),
        review_count: biz.reviews.length,
        verified: biz.status === 'verified',
        status: biz.status,
        city: biz.city,
        country: biz.country,
        address: biz.address,
        phone: biz.phone,
        staff_count: 0,
        services: biz.services.map(s => ({
          id: s.id,
          name: s.name,
          duration_minutes: s.durationMinutes,
          price: Number(s.price ?? 0),
        })),
      },
    ];
  });

  if (body.length > 0) {
    const result = await es.bulk({ body, refresh: true });
    logger.info({ message: 'ES index rebuilt', indexed: businesses.length, errors: result.errors });
  }
}

// ── Upsert single business ─────────────────────────────────
export async function upsertBusinessInES(businessId: string) {
  const es = getES();
  const biz = await prisma.business.findFirst({
    where: { id: businessId },
    include: {
      services: { where: { isActive: true }, select: { id: true, name: true, durationMinutes: true, price: true } },
      category: { select: { name: true, slug: true } },
      reviews: { select: { rating: true } },
    },
  });
  if (!biz) return;

  const avgRating = biz.reviews.length > 0
    ? biz.reviews.reduce((s, r) => s + r.rating, 0) / biz.reviews.length
    : 0;

  await es.index({
    index: 'businesses',
    id: biz.id,
    document: {
      id: biz.id,
      name: biz.name,
      description: biz.description ?? '',
      category: biz.category?.slug ?? biz.categoryId,
      tags: (biz.tags as string[]) ?? [],
      location: biz.latitude && biz.longitude ? { lat: Number(biz.latitude), lon: Number(biz.longitude) } : null,
      avg_rating: parseFloat(avgRating.toFixed(2)),
      review_count: biz.reviews.length,
      verified: biz.status === 'verified',
      status: biz.status,
      city: biz.city,
      country: biz.country,
      address: biz.address,
      services: biz.services.map(s => ({
        id: s.id, name: s.name,
        duration_minutes: s.durationMinutes, price: Number(s.price ?? 0),
      })),
    },
    refresh: true,
  });
}

// ── Main search ────────────────────────────────────────────
export async function search(req: Request) {
  const es = getES();
  const { page, limit, skip } = getPagination(req, 20, 100);
  const { q, lat, lng, radius_km, category, min_rating, verified_only, open_now, sort = 'relevance' } = req.query;

  const must: object[] = [];
  const filter: object[] = [{ term: { status: 'verified' } }];

  if (q) {
    must.push({
      multi_match: {
        query: q,
        fields: ['name^3', 'description', 'category^2', 'tags^2', 'services.name'],
        type: 'best_fields',
        fuzziness: 'AUTO',
      },
    });
  }

  if (category) filter.push({ term: { category } });
  if (verified_only === 'true') filter.push({ term: { verified: true } });
  if (min_rating) filter.push({ range: { avg_rating: { gte: parseFloat(String(min_rating)) } } });

  const sortClause: object[] = [];
  if (lat && lng && (sort === 'distance' || !q)) {
    filter.push({
      geo_distance: {
        distance: `${radius_km ?? 10}km`,
        location: { lat: parseFloat(String(lat)), lon: parseFloat(String(lng)) },
      },
    });
    sortClause.push({ _geo_distance: { location: { lat: parseFloat(String(lat)), lon: parseFloat(String(lng)) }, order: 'asc', unit: 'km' } });
  }

  if (sort === 'rating') sortClause.push({ avg_rating: { order: 'desc' } });
  else if (sort === 'newest') sortClause.push({ _id: { order: 'desc' } });
  else if (q) sortClause.push({ _score: { order: 'desc' } });

  const esResult = await es.search({
    index: 'businesses',
    from: skip,
    size: limit,
    query: { bool: { must: must.length > 0 ? must : [{ match_all: {} }], filter } },
    sort: sortClause.length > 0 ? sortClause : undefined,
  });

  const hits = esResult.hits.hits.map((h: Record<string, unknown>) => ({
    id: (h._source as Record<string, unknown>)?.id ?? h._id,
    ...(h._source as Record<string, unknown>),
    _score: h._score,
    isPromoted: false,
  }));

  const total = typeof esResult.hits.total === 'number' ? esResult.hits.total : (esResult.hits.total as { value: number })?.value ?? 0;

  // ── AD INJECTION ALGORITHM ────────────────────────────
  const enriched = await injectAds(hits, String(category ?? ''), String(req.query.city ?? ''));

  return {
    results: enriched,
    meta: paginationMeta(total, page, limit),
  };
}

// ── Ad injection ───────────────────────────────────────────
async function injectAds(organicResults: object[], category: string, city: string) {
  try {
    const activeAds = await prisma.businessAd.findMany({
      where: {
        status: 'active',
        startDate: { lte: new Date() },
        endDate: { gte: new Date() },
        remainingBudget: { gt: 0 },
      },
      include: { business: { select: { id: true, name: true, city: true, avgRating: true } } },
      take: 10,
    });

    if (activeAds.length === 0) return organicResults;

    const cityBanners = activeAds.filter(a => a.adType === 'city_banner' && a.business.city === city);
    const spotlights = activeAds.filter(a => a.adType === 'spotlight');
    const featuredListings = activeAds.filter(a => a.adType === 'featured_listing');

    const results = [...organicResults];

    // Inject: city banner at position 0
    if (cityBanners[0]) {
      const ad = cityBanners[0];
      results.splice(0, 0, { ...ad.business, adId: ad.id, adType: 'city_banner', isPromoted: true });
      // Track impression
      trackImpression(ad.id, 'city_banner').catch(() => {});
    }

    // Inject: spotlights at positions 1-2
    spotlights.slice(0, 2).forEach((ad, i) => {
      results.splice(cityBanners.length + i, 0, { ...ad.business, adId: ad.id, adType: 'spotlight', isPromoted: true });
      trackImpression(ad.id, 'spotlight').catch(() => {});
    });

    // Inject: featured listings at positions 8-10
    featuredListings.slice(0, 3).forEach((ad, i) => {
      const insertAt = Math.min(8 + i, results.length);
      results.splice(insertAt, 0, { ...ad.business, adId: ad.id, adType: 'featured_listing', isPromoted: true });
      trackImpression(ad.id, 'featured_listing').catch(() => {});
    });

    return results;
  } catch (err) {
    logger.warn({ message: 'Ad injection failed — returning organic results', error: String(err) });
    return organicResults;
  }
}

async function trackImpression(adId: string, adType: string) {
  const { Redis } = await import('ioredis');
  const redis = new Redis(process.env.REDIS_URL ?? 'redis://redis:6379');
  await redis.rpush('ads:impressions:pending', JSON.stringify({ adId, adType, timestamp: new Date().toISOString() }));
  await redis.incr(`ads:impression:${adId}:count`);
  await redis.quit();
}

// ── Autocomplete ──────────────────────────────
export async function autocomplete(q: string) {
  if (!q || q.length < 2) return { suggestions: [] };
  const es = getES();
  const result = await es.search({
    index: 'businesses',
    suggest: {
      name_suggest: {
        prefix: q,
        completion: { field: 'name.suggest', size: 10, skip_duplicates: true },
      },
    },
  });
  const suggestions = ((result.suggest?.name_suggest as Array<{ options: Array<{ text: string; _id: string }> }>) ?? [])
    .flatMap(s => s.options.map(o => ({ text: o.text, id: o._id })));
  return { suggestions };
}

// ── Categories ─────────────────────────────────
export async function getCategories() {
  const categories = await prisma.category.findMany({
    where: { isActive: true, parentId: null },
    include: { children: { where: { isActive: true }, orderBy: { sortOrder: 'asc' } } },
    orderBy: { sortOrder: 'asc' },
  });
  return categories;
}

export async function getFeatured() {
  const es = getES();
  const result = await es.search({
    index: 'businesses',
    size: 10,
    query: { bool: { filter: [{ term: { status: 'verified' } }, { term: { verified: true } }] } },
    sort: [{ avg_rating: { order: 'desc' } }, { review_count: { order: 'desc' } }],
  });
  return result.hits.hits.map(h => h._source);
}

// Initialize ES index on service start
ensureESIndex().catch(err => logger.error({ message: 'ES index init failed', error: String(err) }));
