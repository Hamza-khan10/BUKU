import { Router } from 'express';
import { z } from 'zod';
import { authenticateToken, validateRequest, asyncHandler, requireBusinessOwner } from '@buku/common';
import * as BookingService from '../services/booking.service';

export const appointmentRouter = Router();

const CreateAppointmentSchema = z.object({
  businessId: z.string().uuid(),
  serviceId: z.string().uuid(),
  staffId: z.string().uuid().optional(),
  resourceId: z.string().uuid().optional(),
  startAt: z.string().datetime({ message: 'startAt must be ISO 8601 datetime' }),
  notes: z.string().max(1000).optional(),
});

const RescheduleSchema = z.object({
  startAt: z.string().datetime(),
});

const CancelSchema = z.object({
  reason: z.string().max(500).optional(),
});

// All appointment routes require auth
appointmentRouter.use(authenticateToken());

// POST /v1/appointments
appointmentRouter.post('/',
  validateRequest(CreateAppointmentSchema),
  asyncHandler(async (req, res) => {
    const appointment = await BookingService.createAppointment(req.user!.sub, req.body);
    res.status(201).json({ success: true, data: { appointment } });
  }),
);

// GET /v1/appointments
appointmentRouter.get('/',
  asyncHandler(async (req, res) => {
    const result = await BookingService.listUserAppointments(req.user!.sub, req);
    res.json({ success: true, data: result.appointments, meta: result.meta });
  }),
);

// GET /v1/appointments/:id
appointmentRouter.get('/:id',
  asyncHandler(async (req, res) => {
    const appointment = await BookingService.getAppointment(req.params.id!, req.user!.sub, req.user!.role);
    res.json({ success: true, data: { appointment } });
  }),
);

// POST /v1/appointments/:id/cancel
appointmentRouter.post('/:id/cancel',
  validateRequest(CancelSchema),
  asyncHandler(async (req, res) => {
    const appointment = await BookingService.cancelAppointment(
      req.params.id!, req.user!.sub, req.user!.role, req.body.reason,
    );
    res.json({ success: true, data: { appointment } });
  }),
);

// POST /v1/appointments/:id/reschedule
appointmentRouter.post('/:id/reschedule',
  validateRequest(RescheduleSchema),
  asyncHandler(async (req, res) => {
    const appointment = await BookingService.rescheduleAppointment(
      req.params.id!, req.user!.sub, req.user!.role, req.body.startAt,
    );
    res.json({ success: true, data: { appointment } });
  }),
);

// Business owner routes
// POST /v1/appointments/:id/confirm
appointmentRouter.post('/:id/confirm',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const biz = await import('@buku/database').then(m => m.prisma.business.findFirst({ where: { ownerId: req.user!.sub }, select: { id: true } }));
    const appointment = await BookingService.confirmAppointment(req.params.id!, biz?.id ?? '');
    res.json({ success: true, data: { appointment } });
  }),
);

// POST /v1/appointments/:id/complete
appointmentRouter.post('/:id/complete',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const biz = await import('@buku/database').then(m => m.prisma.business.findFirst({ where: { ownerId: req.user!.sub }, select: { id: true } }));
    const appointment = await BookingService.completeAppointment(req.params.id!, biz?.id ?? '');
    res.json({ success: true, data: { appointment } });
  }),
);

// POST /v1/appointments/:id/no-show
appointmentRouter.post('/:id/no-show',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const biz = await import('@buku/database').then(m => m.prisma.business.findFirst({ where: { ownerId: req.user!.sub }, select: { id: true } }));
    const appointment = await BookingService.markNoShow(req.params.id!, biz?.id ?? '');
    res.json({ success: true, data: { appointment } });
  }),
);
