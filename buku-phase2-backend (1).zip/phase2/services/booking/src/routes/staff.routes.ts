import { Router } from 'express';
import { z } from 'zod';
import { authenticateToken, validateRequest, asyncHandler, requireBusinessOwner } from '@buku/common';
import { prisma } from '@buku/database';

export const staffRouter = Router();

// GET /v1/businesses/:id/staff — in businessRouter context
// POST /v1/staff/accept-invite
staffRouter.post('/accept-invite',
  validateRequest(z.object({ token: z.string().min(10) })),
  asyncHandler(async (req, res) => {
    const { token } = req.body;
    const { hashToken, verifyToken } = await import('@buku/common');
    const tokenHash = await hashToken(token, 10);
    const staffMember = await prisma.staff.findFirst({
      where: { inviteTokenHash: tokenHash, inviteAccepted: false },
    });
    if (!staffMember) {
      const { AppError, ErrorCode } = await import('@buku/common');
      throw AppError.badRequest('Invalid or expired invite token', ErrorCode.TOKEN_INVALID);
    }
    if (staffMember.inviteExpiresAt && staffMember.inviteExpiresAt < new Date()) {
      const { AppError, ErrorCode } = await import('@buku/common');
      throw AppError.badRequest('Invite token has expired', ErrorCode.TOKEN_EXPIRED);
    }
    await prisma.staff.update({
      where: { id: staffMember.id },
      data: { inviteAccepted: true, inviteTokenHash: null },
    });
    res.json({ success: true, data: { message: 'Invite accepted successfully' } });
  }),
);
