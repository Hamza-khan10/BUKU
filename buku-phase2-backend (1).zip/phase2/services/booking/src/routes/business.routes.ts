import { Router } from 'express';
import { z } from 'zod';
import { authenticateToken, validateRequest, asyncHandler, requireBusinessOwner } from '@buku/common';
import * as BookingService from '../services/booking.service';
import { prisma } from '@buku/database';

export const businessRouter = Router();
businessRouter.use(authenticateToken());

const AvailabilityQuerySchema = z.object({
  serviceId: z.string().uuid(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be YYYY-MM-DD'),
  staffId: z.string().uuid().optional(),
});

// GET /v1/businesses/:id/availability
businessRouter.get('/:id/availability',
  validateRequest(AvailabilityQuerySchema, 'query'),
  asyncHandler(async (req, res) => {
    const { serviceId, date, staffId } = req.query as z.infer<typeof AvailabilityQuerySchema>;
    const result = await BookingService.getAvailability(req.params.id!, serviceId, date, staffId);
    res.json({ success: true, data: result });
  }),
);

// GET /v1/businesses/:id/appointments
businessRouter.get('/:id/appointments',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    const result = await BookingService.listBusinessAppointments(req.params.id!, req);
    res.json({ success: true, data: result.appointments, meta: result.meta });
  }),
);

// GET /v1/businesses/:id/services
businessRouter.get('/:id/services',
  asyncHandler(async (req, res) => {
    const services = await prisma.service.findMany({
      where: { businessId: req.params.id!, isActive: true },
      orderBy: [{ groupName: 'asc' }, { sortOrder: 'asc' }],
    });
    res.json({ success: true, data: { services } });
  }),
);

const ServiceSchema = z.object({
  name: z.string().min(1).max(200),
  description: z.string().max(2000).optional(),
  durationMinutes: z.number().int().min(5).max(480),
  bufferMinutes: z.number().int().min(0).max(60).default(0),
  price: z.number().min(0).optional(),
  currency: z.string().length(3).default('USD'),
  depositRequired: z.boolean().default(false),
  depositAmount: z.number().min(0).optional(),
  groupName: z.string().max(100).optional(),
  sortOrder: z.number().int().default(0),
});

// POST /v1/businesses/:id/services
businessRouter.post('/:id/services',
  requireBusinessOwner(),
  validateRequest(ServiceSchema),
  asyncHandler(async (req, res) => {
    const service = await prisma.service.create({
      data: { businessId: req.params.id!, ...req.body },
    });
    res.status(201).json({ success: true, data: { service } });
  }),
);

// PATCH /v1/businesses/:id/services/:sid
businessRouter.patch('/:id/services/:sid',
  requireBusinessOwner(),
  validateRequest(ServiceSchema.partial()),
  asyncHandler(async (req, res) => {
    const service = await prisma.service.update({
      where: { id: req.params.sid!, businessId: req.params.id! },
      data: req.body,
    });
    res.json({ success: true, data: { service } });
  }),
);

// DELETE /v1/businesses/:id/services/:sid
businessRouter.delete('/:id/services/:sid',
  requireBusinessOwner(),
  asyncHandler(async (req, res) => {
    await prisma.service.update({
      where: { id: req.params.sid!, businessId: req.params.id! },
      data: { isActive: false },
    });
    res.json({ success: true, data: { message: 'Service deactivated' } });
  }),
);

// GET /v1/businesses/:id/availability-rules
businessRouter.get('/:id/availability-rules',
  asyncHandler(async (req, res) => {
    const rules = await prisma.availabilityRule.findMany({
      where: { businessId: req.params.id!, isActive: true },
      orderBy: { dayOfWeek: 'asc' },
    });
    res.json({ success: true, data: { rules } });
  }),
);

const AvailabilityRuleSchema = z.object({
  dayOfWeek: z.number().int().min(0).max(6),
  startTime: z.string().regex(/^\d{2}:\d{2}$/),
  endTime: z.string().regex(/^\d{2}:\d{2}$/),
  staffId: z.string().uuid().optional(),
  resourceId: z.string().uuid().optional(),
});

// POST /v1/businesses/:id/availability-rules
businessRouter.post('/:id/availability-rules',
  requireBusinessOwner(),
  validateRequest(AvailabilityRuleSchema),
  asyncHandler(async (req, res) => {
    const rule = await prisma.availabilityRule.create({
      data: { businessId: req.params.id!, ...req.body, isActive: true },
    });
    res.status(201).json({ success: true, data: { rule } });
  }),
);

const ExceptionSchema = z.object({
  exceptionDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  type: z.enum(['holiday', 'modified', 'extra_hours']),
  startTime: z.string().regex(/^\d{2}:\d{2}$/).optional(),
  endTime: z.string().regex(/^\d{2}:\d{2}$/).optional(),
  reason: z.string().max(200).optional(),
  staffId: z.string().uuid().optional(),
});

// POST /v1/businesses/:id/availability-exceptions
businessRouter.post('/:id/availability-exceptions',
  requireBusinessOwner(),
  validateRequest(ExceptionSchema),
  asyncHandler(async (req, res) => {
    const exception = await prisma.availabilityException.create({
      data: { businessId: req.params.id!, ...req.body },
    });
    res.status(201).json({ success: true, data: { exception } });
  }),
);
