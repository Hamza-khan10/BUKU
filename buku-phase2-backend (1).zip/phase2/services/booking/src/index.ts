import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { requestId, requestLogger, errorHandler, notFoundHandler, logger } from '@buku/common';
import { appointmentRouter } from './routes/appointment.routes';
import { businessRouter } from './routes/business.routes';

const app = express();
const PORT = parseInt(process.env.PORT ?? '3002', 10);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: (process.env.FRONTEND_URL ?? 'http://localhost:3000').split(','),
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID'],
}));
app.use(requestId());
app.use(requestLogger());
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

app.get('/health', (_req, res) => {
  res.json({ success: true, data: { status: 'ok', service: 'booking-service', timestamp: new Date().toISOString() } });
});
app.get('/ready', async (_req, res) => {
  try {
    const { prisma } = await import('@buku/database');
    await prisma.$queryRaw`SELECT 1`;
    res.json({ success: true, data: { status: 'ready' } });
  } catch {
    res.status(503).json({ success: false, error: { code: 'NOT_READY', message: 'Database not ready' } });
  }
});

app.use('/v1/appointments', appointmentRouter);
app.use('/v1/businesses', businessRouter);
app.use('/v1/staff', (await import('./routes/staff.routes')).staffRouter);

app.use(notFoundHandler());
app.use(errorHandler());

const server = app.listen(PORT, () => {
  logger.info({ message: `Booking service listening on port ${PORT}` });
  // Start Kafka consumers
  import('./services/booking.consumers').catch(err => logger.error({ message: 'Kafka consumer init failed', error: String(err) }));
});

const shutdown = async (signal: string) => {
  logger.info({ message: `${signal} received` });
  server.close(async () => {
    const { disconnectDatabase } = await import('@buku/database');
    const { disconnectKafka } = await import('@buku/kafka');
    await Promise.all([disconnectDatabase(), disconnectKafka()]);
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 30000);
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
