import crypto from 'crypto';
import { Redis } from 'ioredis';
import { prisma } from '@buku/database';
import { AppError, ErrorCode, generateConfirmationCode, logger, getPagination, paginationMeta } from '@buku/common';
import { produceEvent, TOPICS } from '@buku/kafka';
import type { Request } from 'express';

// ─── Redis singleton ──────────────────────────
let redisClient: Redis | null = null;
function getRedis(): Redis {
  if (!redisClient) {
    redisClient = new Redis(process.env.REDIS_URL ?? 'redis://redis:6379', { maxRetriesPerRequest: 3 });
    redisClient.on('error', err => logger.error({ message: 'Redis error booking-service', error: String(err) }));
  }
  return redisClient;
}

const SLOT_LOCK_TTL = parseInt(process.env.BOOKING_SLOT_LOCK_TTL_SECONDS ?? '30', 10);
const SLOT_CACHE_TTL = 30; // seconds

// ─────────────────────────────────────────────────────────────────
// ATOMIC SLOT LOCKING — the most critical function in the system
// ─────────────────────────────────────────────────────────────────
async function acquireSlotLock(bizId: string, staffId: string | undefined, startAt: Date): Promise<{ acquired: boolean; lockId: string; lockKey: string }> {
  const redis = getRedis();
  const lockKey = `slot:${bizId}:${staffId ?? 'any'}:${startAt.toISOString()}`;
  const lockId = crypto.randomUUID();

  // SETNX — atomic: only first caller gets the lock
  const acquired = await redis.set(lockKey, lockId, 'EX', SLOT_LOCK_TTL, 'NX');
  return { acquired: acquired === 'OK', lockId, lockKey };
}

async function releaseSlotLock(lockKey: string, lockId: string): Promise<void> {
  const redis = getRedis();
  // Lua script for atomic check-and-delete (only release if we own it)
  const script = `
    if redis.call("get", KEYS[1]) == ARGV[1] then
      return redis.call("del", KEYS[1])
    else
      return 0
    end
  `;
  await redis.eval(script, 1, lockKey, lockId);
}

// ─── Slot availability cache ──────────────────
async function invalidateSlotCache(bizId: string, staffId?: string, date?: Date): Promise<void> {
  const redis = getRedis();
  const pattern = staffId
    ? `slots:${bizId}:${staffId}:${date ? date.toISOString().split('T')[0] : '*'}`
    : `slots:${bizId}:*`;
  const keys = await redis.keys(pattern);
  if (keys.length > 0) await redis.del(...keys);
}

// ─── Confirmation code with collision retry ───
async function generateUniqueCode(): Promise<string> {
  for (let i = 0; i < 5; i++) {
    const code = generateConfirmationCode();
    const existing = await prisma.appointment.findFirst({ where: { confirmationCode: code } });
    if (!existing) return code;
  }
  throw AppError.internal('Failed to generate unique confirmation code');
}

// ─── Check for overlapping appointments ──────
async function hasOverlappingAppointment(
  businessId: string,
  staffId: string | null | undefined,
  resourceId: string | null | undefined,
  startAt: Date,
  endAt: Date,
  excludeId?: string,
): Promise<boolean> {
  const where: Record<string, unknown> = {
    businessId,
    status: { in: ['pending', 'confirmed'] },
    id: excludeId ? { not: excludeId } : undefined,
    OR: [
      { startAt: { lt: endAt }, endAt: { gt: startAt } },
    ],
  };
  if (staffId) where.staffId = staffId;
  if (resourceId) where.resourceId = resourceId;

  const count = await prisma.appointment.count({ where: where as Parameters<typeof prisma.appointment.count>[0]['where'] });
  return count > 0;
}

// ─────────────────────────────────────────────────────────────────
// CREATE APPOINTMENT
// ─────────────────────────────────────────────────────────────────
export async function createAppointment(userId: string, body: {
  businessId: string;
  serviceId: string;
  staffId?: string;
  resourceId?: string;
  startAt: string;
  notes?: string;
}) {
  const { businessId, serviceId, staffId, resourceId, notes } = body;
  const startAt = new Date(body.startAt);

  // Load business + service in parallel
  const [business, service] = await Promise.all([
    prisma.business.findFirst({ where: { id: businessId, status: 'verified' } }),
    prisma.service.findFirst({ where: { id: serviceId, businessId, isActive: true } }),
  ]);

  if (!business) throw AppError.notFound('Business not found', ErrorCode.BUSINESS_NOT_FOUND);
  if (!service) throw AppError.notFound('Service not found', ErrorCode.SERVICE_NOT_FOUND);

  const settings = (business.settings as Record<string, unknown>) ?? {};
  const minAdvanceHours = Number(settings.minAdvanceHours ?? 1);
  const maxAdvanceDays = Number(settings.maxAdvanceDays ?? 30);

  // Validate booking window
  const now = new Date();
  const earliestAllowed = new Date(now.getTime() + minAdvanceHours * 60 * 60 * 1000);
  const latestAllowed = new Date(now.getTime() + maxAdvanceDays * 24 * 60 * 60 * 1000);

  if (startAt < earliestAllowed) {
    throw AppError.badRequest(`Must book at least ${minAdvanceHours} hour(s) in advance`, ErrorCode.BOOKING_TOO_EARLY);
  }
  if (startAt > latestAllowed) {
    throw AppError.badRequest(`Cannot book more than ${maxAdvanceDays} days in advance`, ErrorCode.BOOKING_TOO_LATE);
  }

  const endAt = new Date(startAt.getTime() + (service.durationMinutes + service.bufferMinutes) * 60 * 1000);

  // ── ATOMIC SLOT LOCK ──────────────────────────────────────────
  const { acquired, lockId, lockKey } = await acquireSlotLock(businessId, staffId, startAt);
  if (!acquired) {
    throw AppError.conflict('This time slot is no longer available', ErrorCode.SLOT_UNAVAILABLE);
  }

  try {
    // Validate slot against DB while holding the lock
    const overlapping = await hasOverlappingAppointment(businessId, staffId, resourceId, startAt, endAt);
    if (overlapping) {
      throw AppError.conflict('This time slot is no longer available', ErrorCode.SLOT_UNAVAILABLE);
    }

    // Create appointment
    const confirmationCode = await generateUniqueCode();
    const autoConfirm = Boolean(settings.autoConfirm ?? true);

    const appointment = await prisma.appointment.create({
      data: {
        businessId,
        serviceId,
        userId,
        staffId: staffId ?? null,
        resourceId: resourceId ?? null,
        startAt,
        endAt,
        status: autoConfirm ? 'confirmed' : 'pending',
        confirmationCode,
        price: service.price ?? 0,
        currency: service.currency ?? 'USD',
        paymentStatus: 'unpaid',
        notes: notes?.trim() ?? null,
        version: 1,
      },
      include: {
        business: { select: { id: true, name: true, city: true, phone: true } },
        service: { select: { id: true, name: true, durationMinutes: true } },
        staff: { select: { id: true, displayName: true } },
      },
    });

    // Invalidate slot cache
    await invalidateSlotCache(businessId, staffId, startAt);

    // Publish to Kafka (fire and forget — don't block the response)
    produceEvent(TOPICS.BOOKINGS_CREATED, appointment.id, {
      appointmentId: appointment.id,
      businessId,
      userId,
      serviceId,
      staffId: staffId ?? null,
      startAt: startAt.toISOString(),
      endAt: endAt.toISOString(),
      status: appointment.status,
      confirmationCode,
      price: Number(service.price ?? 0),
      currency: service.currency ?? 'USD',
    }).catch(() => {});

    // Schedule reminders via BullMQ (if notification service has queue)
    // This is handled by notification-service consuming bookings.created

    return appointment;
  } finally {
    // ALWAYS release the lock — even if an error was thrown
    await releaseSlotLock(lockKey, lockId);
  }
}

// ─────────────────────────────────────────────────────────────────
// GET APPOINTMENT
// ─────────────────────────────────────────────────────────────────
export async function getAppointment(appointmentId: string, userId: string, userRole: string) {
  const appointment = await prisma.appointment.findFirst({
    where: { id: appointmentId },
    include: {
      business: { select: { id: true, name: true, address: true, phone: true, city: true } },
      service: { select: { id: true, name: true, durationMinutes: true, price: true, currency: true } },
      staff: { select: { id: true, displayName: true, photoUrl: true } },
      user: { select: { id: true, name: true, email: true, phone: true } },
    },
  });

  if (!appointment) throw AppError.notFound('Appointment not found', ErrorCode.APPOINTMENT_NOT_FOUND);

  // Authorization: user can see their own, business owner can see their business's
  if (userRole === 'user' && appointment.userId !== userId) throw AppError.forbidden();
  if (userRole === 'business_owner' && appointment.businessId !== (await getOwnedBusinessId(userId))) throw AppError.forbidden();

  return appointment;
}

async function getOwnedBusinessId(userId: string): Promise<string | null> {
  const biz = await prisma.business.findFirst({ where: { ownerId: userId }, select: { id: true } });
  return biz?.id ?? null;
}

// ─────────────────────────────────────────────────────────────────
// LIST USER APPOINTMENTS
// ─────────────────────────────────────────────────────────────────
export async function listUserAppointments(userId: string, req: Request) {
  const { page, limit, skip } = getPagination(req);
  const status = req.query.status as string | undefined;
  const tab = req.query.tab as string | undefined;

  const now = new Date();
  let where: Parameters<typeof prisma.appointment.findMany>[0]['where'] = { userId };

  if (tab === 'upcoming') where = { ...where, startAt: { gte: now }, status: { in: ['pending', 'confirmed'] } };
  else if (tab === 'past') where = { ...where, startAt: { lt: now } };
  else if (tab === 'cancelled') where = { ...where, status: 'cancelled' };
  else if (status) where = { ...where, status: status as 'pending' };

  const [appointments, total] = await Promise.all([
    prisma.appointment.findMany({
      where,
      skip,
      take: limit,
      orderBy: { startAt: tab === 'past' ? 'desc' : 'asc' },
      include: {
        business: { select: { id: true, name: true, city: true } },
        service: { select: { id: true, name: true } },
        staff: { select: { id: true, displayName: true } },
      },
    }),
    prisma.appointment.count({ where }),
  ]);

  return { appointments, meta: paginationMeta(total, page, limit) };
}

// ─────────────────────────────────────────────────────────────────
// LIST BUSINESS APPOINTMENTS
// ─────────────────────────────────────────────────────────────────
export async function listBusinessAppointments(businessId: string, req: Request) {
  const { page, limit, skip } = getPagination(req);
  const date = req.query.date as string | undefined;
  const status = req.query.status as string | undefined;
  const staffId = req.query.staffId as string | undefined;

  const where: Parameters<typeof prisma.appointment.findMany>[0]['where'] = {
    businessId,
    ...(status ? { status: status as 'pending' } : {}),
    ...(staffId ? { staffId } : {}),
    ...(date ? {
      startAt: {
        gte: new Date(`${date}T00:00:00Z`),
        lt: new Date(`${date}T23:59:59Z`),
      },
    } : {}),
  };

  const [appointments, total] = await Promise.all([
    prisma.appointment.findMany({
      where,
      skip,
      take: limit,
      orderBy: { startAt: 'asc' },
      include: {
        user: { select: { id: true, name: true, phone: true } },
        service: { select: { id: true, name: true, durationMinutes: true } },
        staff: { select: { id: true, displayName: true } },
      },
    }),
    prisma.appointment.count({ where }),
  ]);

  return { appointments, meta: paginationMeta(total, page, limit) };
}

// ─────────────────────────────────────────────────────────────────
// STATUS TRANSITIONS
// Valid transitions:
// pending → confirmed | cancelled
// confirmed → completed | cancelled | rescheduled | no_show
// ─────────────────────────────────────────────────────────────────
const VALID_TRANSITIONS: Record<string, string[]> = {
  pending:   ['confirmed', 'cancelled'],
  confirmed: ['completed', 'cancelled', 'rescheduled', 'no_show'],
  rescheduled: ['confirmed', 'cancelled'],
};

export async function confirmAppointment(appointmentId: string, businessId: string) {
  return updateAppointmentStatus(appointmentId, 'confirmed', { businessId }, TOPICS.BOOKINGS_CONFIRMED);
}

export async function cancelAppointment(appointmentId: string, cancelledBy: string, role: string, reason?: string) {
  const appointment = await prisma.appointment.findFirst({ where: { id: appointmentId } });
  if (!appointment) throw AppError.notFound('Appointment not found', ErrorCode.APPOINTMENT_NOT_FOUND);

  const allowed = VALID_TRANSITIONS[appointment.status];
  if (!allowed?.includes('cancelled')) {
    throw AppError.badRequest(`Cannot cancel appointment in status: ${appointment.status}`, ErrorCode.INVALID_STATUS_TRANSITION);
  }

  const updated = await prisma.appointment.update({
    where: { id: appointmentId },
    data: {
      status: 'cancelled',
      cancelledAt: new Date(),
      cancelReason: reason ?? null,
      cancelBy: role === 'user' ? 'user' : 'business',
      version: { increment: 1 },
    },
  });

  await invalidateSlotCache(appointment.businessId, appointment.staffId ?? undefined, appointment.startAt);

  produceEvent(TOPICS.BOOKINGS_CANCELLED, appointmentId, {
    appointmentId, businessId: appointment.businessId, userId: appointment.userId,
    reason, cancelledBy: role,
  }).catch(() => {});

  return updated;
}

export async function completeAppointment(appointmentId: string, businessId: string) {
  const updated = await updateAppointmentStatus(appointmentId, 'completed', { businessId }, TOPICS.BOOKINGS_COMPLETED);
  // Log analytics event
  produceEvent(TOPICS.ANALYTICS_EVENTS, appointmentId, {
    event_type: 'booking_completed', business_id: businessId, appointment_id: appointmentId,
  }).catch(() => {});
  return updated;
}

export async function markNoShow(appointmentId: string, businessId: string) {
  return updateAppointmentStatus(appointmentId, 'no_show', { businessId }, TOPICS.BOOKINGS_NO_SHOW);
}

async function updateAppointmentStatus(
  appointmentId: string,
  newStatus: string,
  where: Record<string, string>,
  kafkaTopic: string,
) {
  const appointment = await prisma.appointment.findFirst({
    where: { id: appointmentId, ...where },
  });
  if (!appointment) throw AppError.notFound('Appointment not found', ErrorCode.APPOINTMENT_NOT_FOUND);

  const allowed = VALID_TRANSITIONS[appointment.status];
  if (!allowed?.includes(newStatus)) {
    throw AppError.badRequest(
      `Cannot transition from ${appointment.status} to ${newStatus}`,
      ErrorCode.INVALID_STATUS_TRANSITION,
    );
  }

  const updated = await prisma.appointment.update({
    where: { id: appointmentId },
    data: { status: newStatus as 'confirmed', version: { increment: 1 } },
  });

  produceEvent(kafkaTopic as typeof TOPICS.BOOKINGS_CONFIRMED, appointmentId, {
    appointmentId, businessId: appointment.businessId, userId: appointment.userId,
    status: newStatus, startAt: appointment.startAt.toISOString(),
  }).catch(() => {});

  return updated;
}

// ─────────────────────────────────────────────────────────────────
// RESCHEDULE
// ─────────────────────────────────────────────────────────────────
export async function rescheduleAppointment(
  appointmentId: string,
  userId: string,
  userRole: string,
  newStartAt: string,
) {
  const appointment = await prisma.appointment.findFirst({ where: { id: appointmentId } });
  if (!appointment) throw AppError.notFound('Appointment not found', ErrorCode.APPOINTMENT_NOT_FOUND);

  if (userRole === 'user' && appointment.userId !== userId) throw AppError.forbidden();

  const allowed = VALID_TRANSITIONS[appointment.status];
  if (!allowed?.includes('rescheduled')) {
    throw AppError.badRequest(`Cannot reschedule appointment in status: ${appointment.status}`, ErrorCode.INVALID_STATUS_TRANSITION);
  }

  const newStart = new Date(newStartAt);
  const service = await prisma.service.findFirst({ where: { id: appointment.serviceId } });
  if (!service) throw AppError.notFound('Service not found', ErrorCode.SERVICE_NOT_FOUND);

  const newEnd = new Date(newStart.getTime() + (service.durationMinutes + service.bufferMinutes) * 60 * 1000);

  // Acquire slot lock for NEW slot
  const { acquired, lockId, lockKey } = await acquireSlotLock(appointment.businessId, appointment.staffId ?? undefined, newStart);
  if (!acquired) throw AppError.conflict('New time slot is not available', ErrorCode.SLOT_UNAVAILABLE);

  try {
    const overlapping = await hasOverlappingAppointment(
      appointment.businessId, appointment.staffId, appointment.resourceId,
      newStart, newEnd, appointmentId,
    );
    if (overlapping) throw AppError.conflict('New time slot is not available', ErrorCode.SLOT_UNAVAILABLE);

    const updated = await prisma.appointment.update({
      where: { id: appointmentId },
      data: {
        startAt: newStart, endAt: newEnd, status: 'rescheduled',
        rescheduledFromId: appointmentId,
        version: { increment: 1 },
      },
    });

    await Promise.all([
      invalidateSlotCache(appointment.businessId, appointment.staffId ?? undefined, appointment.startAt),
      invalidateSlotCache(appointment.businessId, appointment.staffId ?? undefined, newStart),
    ]);

    produceEvent(TOPICS.BOOKINGS_RESCHEDULED, appointmentId, {
      appointmentId, businessId: appointment.businessId, userId: appointment.userId,
      oldStartAt: appointment.startAt.toISOString(), newStartAt: newStart.toISOString(),
    }).catch(() => {});

    return updated;
  } finally {
    await releaseSlotLock(lockKey, lockId);
  }
}

// ─────────────────────────────────────────────────────────────────
// AVAILABILITY CALCULATION
// ─────────────────────────────────────────────────────────────────
export async function getAvailability(
  businessId: string,
  serviceId: string,
  date: string,
  staffId?: string,
) {
  // Check cache first
  const redis = getRedis();
  const cacheKey = `slots:${businessId}:${staffId ?? 'any'}:${date}`;
  const cached = await redis.get(cacheKey);
  if (cached) return JSON.parse(cached);

  const business = await prisma.business.findFirst({ where: { id: businessId, status: 'verified' } });
  if (!business) throw AppError.notFound('Business not found', ErrorCode.BUSINESS_NOT_FOUND);

  const service = await prisma.service.findFirst({ where: { id: serviceId, businessId, isActive: true } });
  if (!service) throw AppError.notFound('Service not found', ErrorCode.SERVICE_NOT_FOUND);

  const settings = (business.settings as Record<string, unknown>) ?? {};
  const timezone = String(settings.timezone ?? 'UTC');

  const requestedDate = new Date(date);
  const dayOfWeek = requestedDate.getUTCDay();

  // Load availability rules for this day
  const rules = await prisma.availabilityRule.findMany({
    where: {
      businessId,
      dayOfWeek,
      isActive: true,
      ...(staffId ? { OR: [{ staffId }, { staffId: null }] } : { staffId: null }),
    },
  });

  if (rules.length === 0 || rules[0]?.startTime === undefined) {
    return { date, slots: [], isAvailable: false, reason: 'Business closed this day' };
  }

  // Check for exceptions (holidays, modified hours)
  const exception = await prisma.availabilityException.findFirst({
    where: { businessId, exceptionDate: requestedDate, ...(staffId ? { staffId } : {}) },
  });

  if (exception?.type === 'holiday') {
    return { date, slots: [], isAvailable: false, reason: 'Holiday' };
  }

  const rule = exception?.type === 'modified' ? exception : rules[0]!;
  const openTime = rule.startTime ?? rule.openTime as string;
  const closeTime = rule.endTime ?? rule.closeTime as string;

  if (!openTime || !closeTime) {
    return { date, slots: [], isAvailable: false, reason: 'No hours defined' };
  }

  const [openH, openM] = openTime.split(':').map(Number);
  const [closeH, closeM] = closeTime.split(':').map(Number);

  const dateStr = date;
  const dayStart = new Date(`${dateStr}T${String(openH).padStart(2, '0')}:${String(openM).padStart(2, '0')}:00Z`);
  const dayEnd = new Date(`${dateStr}T${String(closeH).padStart(2, '0')}:${String(closeM).padStart(2, '0')}:00Z`);
  const slotDuration = (service.durationMinutes + service.bufferMinutes) * 60 * 1000;

  // Load existing appointments
  const existingAppointments = await prisma.appointment.findMany({
    where: {
      businessId,
      status: { in: ['pending', 'confirmed'] },
      startAt: { gte: dayStart, lt: dayEnd },
      ...(staffId ? { staffId } : {}),
    },
    select: { startAt: true, endAt: true },
  });

  // Generate slots
  const slots = [];
  const now = new Date();
  let slotStart = new Date(dayStart);

  while (slotStart.getTime() + slotDuration <= dayEnd.getTime()) {
    const slotEnd = new Date(slotStart.getTime() + slotDuration);
    const isPast = slotStart <= now;

    const hasConflict = existingAppointments.some(
      appt => slotStart < appt.endAt && slotEnd > appt.startAt,
    );

    slots.push({
      startAt: slotStart.toISOString(),
      endAt: slotEnd.toISOString(),
      isAvailable: !isPast && !hasConflict,
      reason: isPast ? 'past' : hasConflict ? 'booked' : null,
      durationMinutes: service.durationMinutes,
    });

    slotStart = new Date(slotStart.getTime() + slotDuration);
  }

  const result = { date, slots, isAvailable: slots.some(s => s.isAvailable), businessId, serviceId };

  // Cache for 30 seconds
  await redis.setex(cacheKey, SLOT_CACHE_TTL, JSON.stringify(result));

  return result;
}
