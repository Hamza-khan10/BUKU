import { createConsumer, TOPICS, KafkaEvent } from '@buku/kafka';
import { logger } from '@buku/common';
import { prisma } from '@buku/database';

export async function startConsumers() {
  await createConsumer('booking-completed-review', [
    {
      topic: TOPICS.BOOKINGS_COMPLETED,
      handler: async (event: KafkaEvent) => {
        const data = event.data as { appointmentId: string };
        logger.info({ message: 'Booking completed — triggering review request', appointmentId: data.appointmentId });
        // Review request is handled by notification-service
        // Just log here for now
      },
    },
  ]);
  logger.info({ message: 'Booking Kafka consumers started' });
}

startConsumers().catch(err => logger.error({ message: 'Booking consumer start failed', error: String(err) }));
