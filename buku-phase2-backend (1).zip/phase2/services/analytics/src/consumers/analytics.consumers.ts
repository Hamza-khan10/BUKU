import { createConsumer, TOPICS, KafkaEvent } from '@buku/kafka';
import { logger } from '@buku/common';
import { createClient } from '@clickhouse/client';

const getClickHouse = () => createClient({
  url: process.env.CLICKHOUSE_URL ?? 'http://clickhouse:8123',
  username: process.env.CLICKHOUSE_USER ?? 'buku_analytics',
  password: process.env.CLICKHOUSE_PASSWORD ?? 'buku_analytics_dev',
  database: process.env.CLICKHOUSE_DB ?? 'buku_analytics',
});

// ── Batch event buffer ────────────────────────
const eventBuffer: object[] = [];
const bookingBuffer: object[] = [];
const FLUSH_INTERVAL_MS = 5000;
const MAX_BATCH_SIZE = 500;

async function flushEventBuffer() {
  if (eventBuffer.length === 0) return;
  const batch = eventBuffer.splice(0, MAX_BATCH_SIZE);
  try {
    const ch = getClickHouse();
    await ch.insert({ table: 'events', values: batch, format: 'JSONEachRow' });
    await ch.close();
    logger.info({ message: 'ClickHouse event batch flushed', count: batch.length });
  } catch (err) {
    logger.error({ message: 'ClickHouse event flush failed', error: String(err), count: batch.length });
  }
}

async function flushBookingBuffer() {
  if (bookingBuffer.length === 0) return;
  const batch = bookingBuffer.splice(0, MAX_BATCH_SIZE);
  try {
    const ch = getClickHouse();
    await ch.insert({ table: 'booking_analytics', values: batch, format: 'JSONEachRow' });
    await ch.close();
    logger.info({ message: 'ClickHouse booking batch flushed', count: batch.length });
  } catch (err) {
    logger.error({ message: 'ClickHouse booking flush failed', error: String(err) });
  }
}

// Flush every 5 seconds
setInterval(flushEventBuffer, FLUSH_INTERVAL_MS);
setInterval(flushBookingBuffer, FLUSH_INTERVAL_MS);
// Also flush if buffer hits max size
function maybeFlush(buffer: object[], flushFn: () => Promise<void>) {
  if (buffer.length >= MAX_BATCH_SIZE) flushFn().catch(() => {});
}

export async function startConsumers() {
  // analytics.events → events table
  await createConsumer('analytics-events', [{
    topic: TOPICS.ANALYTICS_EVENTS,
    handler: async (event: KafkaEvent) => {
      const d = event.data as Record<string, unknown>;
      eventBuffer.push({
        event_id: event.eventId,
        event_type: d.event_type ?? event.eventType,
        business_id: d.business_id ?? '',
        user_id: d.user_id ?? '',
        properties: JSON.stringify(d),
        timestamp: new Date(event.timestamp).toISOString().replace('T', ' ').replace('Z', ''),
        date: new Date(event.timestamp).toISOString().split('T')[0],
      });
      maybeFlush(eventBuffer, flushEventBuffer);
    },
  }]);

  // bookings.created → booking_analytics
  await createConsumer('analytics-bookings-created', [{
    topic: TOPICS.BOOKINGS_CREATED,
    handler: async (event: KafkaEvent) => {
      const d = event.data as {
        appointmentId: string; businessId: string; userId: string;
        serviceId: string; staffId?: string; startAt: string; price: number;
      };
      const { prisma } = await import('@buku/database');
      const startDate = new Date(d.startAt);
      const existing = await prisma.appointment.findFirst({
        where: { userId: d.userId, businessId: d.businessId, id: { not: d.appointmentId }, status: 'completed' },
        select: { id: true },
      });

      bookingBuffer.push({
        booking_id: d.appointmentId,
        business_id: d.businessId,
        service_id: d.serviceId,
        staff_id: d.staffId ?? '',
        user_id: d.userId,
        status: 'created',
        amount: d.price,
        duration_minutes: 0,
        day_of_week: startDate.getDay(),
        hour_of_day: startDate.getHours(),
        is_new_customer: existing ? 0 : 1,
        created_at: new Date().toISOString().replace('T', ' ').replace('Z', ''),
        date: new Date().toISOString().split('T')[0],
      });
      maybeFlush(bookingBuffer, flushBookingBuffer);
    },
  }]);

  // queue.session.closed → queue_analytics
  await createConsumer('analytics-queue-sessions', [{
    topic: TOPICS.QUEUE_SESSION_CLOSED,
    handler: async (event: KafkaEvent) => {
      const d = event.data as { sessionId: string; businessId: string };
      const { prisma } = await import('@buku/database');
      const session = await prisma.queueSession.findFirst({
        where: { id: d.sessionId },
        include: { entries: true },
      });
      if (!session) return;

      const served = session.entries.filter(e => e.status === 'completed').length;
      const noShows = session.entries.filter(e => e.status === 'no_show').length;
      const waitSeconds = session.entries
        .filter(e => e.servedAt && e.joinedAt)
        .map(e => Math.floor((e.servedAt!.getTime() - e.joinedAt.getTime()) / 1000));
      const avgWait = waitSeconds.length > 0 ? Math.floor(waitSeconds.reduce((a, b) => a + b, 0) / waitSeconds.length) : 0;
      const serviceSeconds = session.entries
        .filter(e => e.actualServiceSeconds && e.actualServiceSeconds > 0)
        .map(e => e.actualServiceSeconds!);
      const avgService = serviceSeconds.length > 0 ? Math.floor(serviceSeconds.reduce((a, b) => a + b, 0) / serviceSeconds.length) : 0;

      try {
        const ch = getClickHouse();
        await ch.insert({
          table: 'queue_analytics',
          values: [{
            session_id: d.sessionId,
            business_id: d.businessId,
            entry_count: session.entries.length,
            served_count: served,
            no_show_count: noShows,
            avg_wait_seconds: avgWait,
            avg_service_seconds: avgService,
            session_date: session.sessionDate.toISOString().split('T')[0],
          }],
          format: 'JSONEachRow',
        });
        await ch.close();
      } catch (err) {
        logger.error({ message: 'Queue analytics insert failed', error: String(err) });
      }
    },
  }]);

  // analytics.search → search_analytics
  await createConsumer('analytics-search', [{
    topic: TOPICS.ANALYTICS_SEARCH,
    handler: async (event: KafkaEvent) => {
      const d = event.data as { query: string; filters: object; resultCount: number; userId?: string; city?: string; category?: string };
      try {
        const ch = getClickHouse();
        await ch.insert({
          table: 'search_analytics',
          values: [{
            query: d.query ?? '',
            filters: JSON.stringify(d.filters ?? {}),
            result_count: d.resultCount ?? 0,
            user_id: d.userId ?? '',
            city: d.city ?? '',
            category: d.category ?? '',
            timestamp: new Date(event.timestamp).toISOString().replace('T', ' ').replace('Z', ''),
          }],
          format: 'JSONEachRow',
        });
        await ch.close();
      } catch (err) {
        logger.error({ message: 'Search analytics insert failed', error: String(err) });
      }
    },
  }]);

  logger.info({ message: 'Analytics Kafka consumers started' });
}

startConsumers().catch(err => logger.error({ message: 'Analytics consumer start failed', error: String(err) }));
