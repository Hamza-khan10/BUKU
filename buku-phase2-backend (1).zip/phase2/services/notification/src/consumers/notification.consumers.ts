import { createConsumer, TOPICS, KafkaEvent } from '@buku/kafka';
import { logger } from '@buku/common';
import { prisma } from '@buku/database';

// ─── Channel senders ──────────────────────────
async function sendPush(userId: string, title: string, body: string, data?: Record<string, unknown>, priority = 'normal') {
  try {
    const tokens = await prisma.pushToken.findMany({
      where: { userId, isActive: true },
      select: { token: true, platform: true },
    });
    if (tokens.length === 0) return;

    const { initializeApp, cert, getApps } = await import('firebase-admin/app');
    const { getMessaging } = await import('firebase-admin/messaging');

    if (getApps().length === 0) {
      const projectId = process.env.FIREBASE_PROJECT_ID;
      if (!projectId || projectId === 'buku-dev') {
        logger.info({ message: '[DEV] Push notification', userId, title, body });
        return;
      }
      initializeApp({ credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT ?? '{}')) });
    }

    const messaging = getMessaging();
    for (const { token } of tokens) {
      await messaging.send({
        token,
        notification: { title, body },
        data: data ? Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])) : undefined,
        android: { priority: priority === 'high' ? 'high' : 'normal' },
        apns: { payload: { aps: { contentAvailable: true, sound: priority === 'high' ? 'default' : undefined } } },
      });
    }
  } catch (err) {
    logger.warn({ message: 'Push notification failed', userId, error: String(err) });
  }
}

async function sendSms(phone: string, message: string) {
  try {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_FROM_NUMBER;
    if (!accountSid || accountSid.includes('mock')) {
      logger.info({ message: '[DEV] SMS notification', phone, message });
      return;
    }
    const twilio = (await import('twilio')).default;
    await twilio(accountSid, authToken!).messages.create({ body: message, from: from!, to: phone });
  } catch (err) {
    logger.warn({ message: 'SMS send failed', phone, error: String(err) });
  }
}

async function sendEmail(to: string, subject: string, html: string) {
  try {
    const { SESClient, SendEmailCommand } = await import('@aws-sdk/client-ses');
    const ses = new SESClient({
      region: process.env.AWS_REGION ?? 'us-east-1',
      endpoint: process.env.AWS_ENDPOINT_URL,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID ?? '',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ?? '',
      },
    });
    await ses.send(new SendEmailCommand({
      Source: process.env.AWS_SES_FROM_EMAIL ?? 'noreply@buku.app',
      Destination: { ToAddresses: [to] },
      Message: { Subject: { Data: subject }, Body: { Html: { Data: html } } },
    }));
  } catch (err) {
    logger.warn({ message: 'Email send failed', to, error: String(err) });
  }
}

async function saveNotification(userId: string, type: string, channel: string, title: string, body: string, data?: Record<string, unknown>) {
  await prisma.notification.create({
    data: {
      userId,
      type,
      channel: channel as 'push' | 'sms' | 'email',
      title,
      body,
      data: data ?? {},
      status: 'sent',
      sentAt: new Date(),
    },
  });
}

// ─── Load user preferences ────────────────────
async function getPrefs(userId: string) {
  const prefs = await prisma.notificationPreference.findFirst({ where: { userId } });
  return prefs ?? {
    pushBookingConfirmation: true,
    pushReminders: true,
    pushQueueUpdates: true,
    smsReminders: true,
    smsQueueCalled: true,
    emailBookingConfirmation: true,
    marketingEmails: false,
  };
}

// ─── Consumer handlers ────────────────────────
export async function startConsumers() {
  await createConsumer('notification-booking-created', [{
    topic: TOPICS.BOOKINGS_CREATED,
    handler: async (event: KafkaEvent) => {
      const d = event.data as {
        appointmentId: string; businessId: string; userId: string;
        confirmationCode: string; startAt: string; status: string;
      };
      const user = await prisma.user.findFirst({ where: { id: d.userId } });
      const business = await prisma.business.findFirst({ where: { id: d.businessId }, select: { name: true } });
      if (!user || !business) return;

      const prefs = await getPrefs(d.userId);
      const date = new Date(d.startAt).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' });
      const title = '✅ Booking Confirmed';
      const body = `Your appointment at ${business.name} is confirmed for ${date}. Code: ${d.confirmationCode}`;

      if (prefs.pushBookingConfirmation) {
        await sendPush(d.userId, title, body, { appointmentId: d.appointmentId, type: 'booking_confirmation' });
      }
      if (prefs.emailBookingConfirmation && user.email) {
        await sendEmail(user.email, `Booking confirmed at ${business.name}`,
          `<h2>Booking Confirmed!</h2><p>${body}</p><p>Confirmation code: <strong>${d.confirmationCode}</strong></p>`);
      }
      await saveNotification(d.userId, 'booking_confirmation', 'push', title, body, { appointmentId: d.appointmentId });
      logger.info({ message: 'Booking confirmation sent', userId: d.userId, appointmentId: d.appointmentId });
    },
  }]);

  await createConsumer('notification-booking-cancelled', [{
    topic: TOPICS.BOOKINGS_CANCELLED,
    handler: async (event: KafkaEvent) => {
      const d = event.data as { appointmentId: string; businessId: string; userId: string; reason?: string };
      const user = await prisma.user.findFirst({ where: { id: d.userId } });
      const business = await prisma.business.findFirst({ where: { id: d.businessId }, select: { name: true } });
      if (!user || !business) return;

      const title = '❌ Booking Cancelled';
      const body = `Your booking at ${business.name} has been cancelled.${d.reason ? ` Reason: ${d.reason}` : ''}`;
      await sendPush(d.userId, title, body, { appointmentId: d.appointmentId, type: 'booking_cancelled' });
      if (user.email) await sendEmail(user.email, `Booking cancelled - ${business.name}`, `<p>${body}</p>`);
      if (user.phone) await sendSms(user.phone, body);
      await saveNotification(d.userId, 'booking_cancelled', 'push', title, body);
    },
  }]);

  await createConsumer('notification-queue-called', [{
    topic: TOPICS.QUEUE_ENTRY_CALLED,
    handler: async (event: KafkaEvent) => {
      const d = event.data as {
        entryId: string; sessionId: string; businessId: string; userId?: string;
        ticketNumber: number; ticketPrefix: string;
      };
      if (!d.userId) return;

      const [user, business] = await Promise.all([
        prisma.user.findFirst({ where: { id: d.userId } }),
        prisma.business.findFirst({ where: { id: d.businessId }, select: { name: true } }),
      ]);
      if (!user || !business) return;

      const ticketDisplay = `${d.ticketPrefix}${String(d.ticketNumber).padStart(3, '0')}`;
      const title = '🔔 You\'re Next!';
      const body = `Please come to ${business.name} now. Ticket ${ticketDisplay} is being called.`;

      // URGENT: push + SMS always for queue calls
      await sendPush(d.userId, title, body, { entryId: d.entryId, type: 'queue_called' }, 'high');
      if (user.phone) await sendSms(user.phone, body);
      await saveNotification(d.userId, 'queue_called', 'push', title, body, { entryId: d.entryId });
      logger.info({ message: 'Queue call notification sent', userId: d.userId, ticket: ticketDisplay });
    },
  }]);

  await createConsumer('notification-queue-joined', [{
    topic: TOPICS.QUEUE_ENTRY_JOINED,
    handler: async (event: KafkaEvent) => {
      const d = event.data as {
        entryId: string; businessId: string; userId?: string;
        ticketNumber: number; ticketPrefix: string; estimatedWaitSeconds: number;
      };
      if (!d.userId) return;
      const business = await prisma.business.findFirst({ where: { id: d.businessId }, select: { name: true } });
      if (!business) return;

      const ticketDisplay = `${d.ticketPrefix}${String(d.ticketNumber).padStart(3, '0')}`;
      const waitMin = Math.ceil(d.estimatedWaitSeconds / 60);
      const title = '🎫 Queue Joined';
      const body = `You joined the queue at ${business.name}. Your ticket: ${ticketDisplay}. Est. wait: ${waitMin} min.`;
      await sendPush(d.userId, title, body, { entryId: d.entryId, type: 'queue_joined' });
      await saveNotification(d.userId, 'queue_entry', 'push', title, body, { entryId: d.entryId });
    },
  }]);

  await createConsumer('notification-user-registered', [{
    topic: TOPICS.USERS_REGISTERED,
    handler: async (event: KafkaEvent) => {
      const d = event.data as { userId: string; name: string; email?: string };
      if (!d.email) return;
      await sendEmail(d.email, 'Welcome to BUKU!',
        `<h1>Welcome to BUKU, ${d.name}!</h1><p>Your account has been created. Start booking appointments now.</p>`);
      logger.info({ message: 'Welcome email sent', userId: d.userId });
    },
  }]);

  await createConsumer('notification-booking-completed', [{
    topic: TOPICS.BOOKINGS_COMPLETED,
    handler: async (event: KafkaEvent) => {
      const d = event.data as { appointmentId: string; businessId: string; userId: string };
      const user = await prisma.user.findFirst({ where: { id: d.userId } });
      const business = await prisma.business.findFirst({ where: { id: d.businessId }, select: { name: true } });
      if (!user || !business) return;

      // Schedule review request after 30 minutes via a delayed message
      setTimeout(async () => {
        const title = '⭐ How was your visit?';
        const body = `How was your experience at ${business.name}? Leave a review.`;
        await sendPush(d.userId, title, body, { appointmentId: d.appointmentId, type: 'review_request' });
        await saveNotification(d.userId, 'review_request', 'push', title, body, { appointmentId: d.appointmentId });
      }, 30 * 60 * 1000); // 30 minutes
    },
  }]);

  logger.info({ message: 'All notification Kafka consumers started' });
}

startConsumers().catch(err => logger.error({ message: 'Notification consumer start failed', error: String(err) }));
