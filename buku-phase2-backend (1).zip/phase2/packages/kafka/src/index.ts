import { Kafka, Producer, Consumer, KafkaConfig, logLevel } from 'kafkajs';

// ─────────────────────────────────────────────
// ALL TOPIC NAMES — matches kafka-init exactly
// ─────────────────────────────────────────────
export const TOPICS = {
  // Bookings
  BOOKINGS_CREATED:       'bookings.created',
  BOOKINGS_CONFIRMED:     'bookings.confirmed',
  BOOKINGS_CANCELLED:     'bookings.cancelled',
  BOOKINGS_RESCHEDULED:   'bookings.rescheduled',
  BOOKINGS_COMPLETED:     'bookings.completed',
  BOOKINGS_REMINDER:      'bookings.reminder',
  BOOKINGS_NO_SHOW:       'bookings.no_show',
  // Queue
  QUEUE_SESSION_OPENED:   'queue.session.opened',
  QUEUE_SESSION_CLOSED:   'queue.session.closed',
  QUEUE_ENTRY_JOINED:     'queue.entry.joined',
  QUEUE_ENTRY_CALLED:     'queue.entry.called',
  QUEUE_ENTRY_SERVED:     'queue.entry.served',
  QUEUE_ENTRY_COMPLETED:  'queue.entry.completed',
  QUEUE_ENTRY_LEFT:       'queue.entry.left',
  QUEUE_ENTRY_NO_SHOW:    'queue.entry.no_show',
  QUEUE_POSITION_UPDATED: 'queue.position.updated',
  // Notifications
  NOTIFICATIONS_SEND:     'notifications.send',
  NOTIFICATIONS_DELIVERED:'notifications.delivered',
  // Users
  USERS_REGISTERED:       'users.registered',
  USERS_VERIFIED:         'users.verified',
  USERS_DELETED:          'users.deleted',
  // Businesses
  BUSINESSES_CREATED:     'businesses.created',
  BUSINESSES_VERIFIED:    'businesses.verified',
  BUSINESSES_UPDATED:     'businesses.updated',
  BUSINESSES_SUSPENDED:   'businesses.suspended',
  // Payments
  PAYMENTS_INITIATED:     'payments.initiated',
  PAYMENTS_COMPLETED:     'payments.completed',
  PAYMENTS_FAILED:        'payments.failed',
  PAYMENTS_REFUNDED:      'payments.refunded',
  // Analytics
  ANALYTICS_EVENTS:       'analytics.events',
  ANALYTICS_SEARCH:       'analytics.search',
  ANALYTICS_AD_IMPRESSIONS:'analytics.ad.impressions',
  // AI
  AI_CALL_STARTED:        'ai.call.started',
  AI_CALL_COMPLETED:      'ai.call.completed',
  AI_CALL_FAILED:         'ai.call.failed',
  // Webhooks
  WEBHOOKS_DISPATCH:      'webhooks.dispatch',
  WEBHOOKS_DELIVERED:     'webhooks.delivered',
  WEBHOOKS_FAILED:        'webhooks.failed',
  // DLQ
  DLQ_FAILED_EVENTS:      'dlq.failed-events',
  DLQ_NOTIFICATIONS:      'dlq.notifications',
  DLQ_WEBHOOKS:           'dlq.webhooks',
} as const;

export type TopicName = typeof TOPICS[keyof typeof TOPICS];

// ─────────────────────────────────────────────
// KAFKA EVENT TYPES
// ─────────────────────────────────────────────
export interface KafkaEvent<T = unknown> {
  eventId: string;
  eventType: string;
  timestamp: string;
  version: '1.0';
  data: T;
}

export interface BookingEventData {
  appointmentId: string;
  businessId: string;
  userId: string;
  serviceId: string;
  staffId?: string;
  startAt: string;
  endAt: string;
  status: string;
  confirmationCode: string;
  price: number;
  currency: string;
}

export interface QueueEventData {
  sessionId: string;
  businessId: string;
  entryId?: string;
  userId?: string;
  ticketNumber?: number;
  ticketPrefix?: string;
  status?: string;
  position?: number;
  estimatedWaitSeconds?: number;
}

export interface UserEventData {
  userId: string;
  email?: string;
  phone?: string;
  name: string;
  role: string;
}

export interface NotificationSendData {
  userId: string;
  type: string;
  title: string;
  body: string;
  channels: Array<'push' | 'sms' | 'email'>;
  data?: Record<string, unknown>;
  appointmentId?: string;
  queueEntryId?: string;
  priority?: 'high' | 'normal';
}

// ─────────────────────────────────────────────
// KAFKA CLIENT SINGLETON
// ─────────────────────────────────────────────
let kafkaInstance: Kafka | null = null;

function getKafka(): Kafka {
  if (!kafkaInstance) {
    const brokers = (process.env.KAFKA_BROKERS ?? 'kafka:29092').split(',').map(b => b.trim());
    const config: KafkaConfig = {
      clientId: process.env.KAFKA_CLIENT_ID ?? 'buku-service',
      brokers,
      logLevel: logLevel.WARN,
      retry: {
        initialRetryTime: 300,
        retries: 10,
        maxRetryTime: 30000,
        factor: 2,
      },
    };
    kafkaInstance = new Kafka(config);
  }
  return kafkaInstance;
}

// ─────────────────────────────────────────────
// PRODUCER FACTORY
// ─────────────────────────────────────────────
let producerInstance: Producer | null = null;
let producerConnecting = false;

export async function getProducer(): Promise<Producer> {
  if (producerInstance) return producerInstance;
  if (producerConnecting) {
    // Wait for existing connection
    await new Promise(r => setTimeout(r, 500));
    return getProducer();
  }
  producerConnecting = true;
  const producer = getKafka().producer({
    idempotent: true,
    maxInFlightRequests: 5,
    transactionTimeout: 30000,
  });
  await producer.connect();
  producerInstance = producer;
  producerConnecting = false;
  return producer;
}

export async function produceEvent<T>(
  topic: TopicName,
  key: string,
  data: T,
  headers?: Record<string, string>,
): Promise<void> {
  const event: KafkaEvent<T> = {
    eventId: crypto.randomUUID(),
    eventType: topic,
    timestamp: new Date().toISOString(),
    version: '1.0',
    data,
  };

  try {
    const producer = await getProducer();
    await producer.send({
      topic,
      messages: [{
        key,
        value: JSON.stringify(event),
        headers: {
          'content-type': 'application/json',
          'event-type': topic,
          ...headers,
        },
      }],
      acks: -1, // all replicas
    });
  } catch (err) {
    // Log and send to DLQ — never throw from Kafka publish so the HTTP response is not blocked
    console.error(`[Kafka] Failed to produce to ${topic}:`, err);
    try {
      const producer = await getProducer();
      await producer.send({
        topic: TOPICS.DLQ_FAILED_EVENTS,
        messages: [{
          key,
          value: JSON.stringify({ originalTopic: topic, key, event, error: String(err) }),
        }],
        acks: 1,
      });
    } catch {
      // DLQ also failed — log only
      console.error('[Kafka] DLQ publish also failed');
    }
  }
}

// ─────────────────────────────────────────────
// CONSUMER FACTORY
// ─────────────────────────────────────────────
export interface ConsumerHandler<T = unknown> {
  topic: TopicName;
  handler: (event: KafkaEvent<T>, rawKey: string) => Promise<void>;
}

export async function createConsumer(
  groupId: string,
  handlers: ConsumerHandler[],
  options?: { fromBeginning?: boolean },
): Promise<Consumer> {
  const consumer = getKafka().consumer({
    groupId: `${process.env.KAFKA_GROUP_ID_PREFIX ?? 'buku-dev'}-${groupId}`,
    sessionTimeout: 30000,
    heartbeatInterval: 3000,
    maxBytesPerPartition: 1048576, // 1MB
  });

  await consumer.connect();

  for (const { topic } of handlers) {
    await consumer.subscribe({ topic, fromBeginning: options?.fromBeginning ?? false });
  }

  const handlerMap = new Map(handlers.map(h => [h.topic, h.handler]));

  await consumer.run({
    autoCommit: false,
    eachMessage: async ({ topic, partition, message, heartbeat }) => {
      const handler = handlerMap.get(topic as TopicName);
      if (!handler) return;

      const raw = message.value?.toString();
      if (!raw) return;

      let event: KafkaEvent;
      try {
        event = JSON.parse(raw) as KafkaEvent;
      } catch {
        console.error(`[Kafka Consumer ${groupId}] Failed to parse message on ${topic}`);
        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(message.offset) + 1n).toString() }]);
        return;
      }

      try {
        await handler(event, message.key?.toString() ?? '');
        await heartbeat();
        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(message.offset) + 1n).toString() }]);
      } catch (err) {
        console.error(`[Kafka Consumer ${groupId}] Error handling ${topic}:`, err);
        // Send to DLQ and commit so we don't get stuck
        try {
          const producer = await getProducer();
          await producer.send({
            topic: TOPICS.DLQ_FAILED_EVENTS,
            messages: [{
              key: message.key?.toString() ?? 'unknown',
              value: JSON.stringify({ topic, error: String(err), message: raw }),
            }],
            acks: 1,
          });
        } catch { /* ignore DLQ failure */ }
        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(message.offset) + 1n).toString() }]);
      }
    },
  });

  return consumer;
}

// ─────────────────────────────────────────────
// GRACEFUL SHUTDOWN
// ─────────────────────────────────────────────
export async function disconnectKafka(): Promise<void> {
  if (producerInstance) {
    await producerInstance.disconnect();
    producerInstance = null;
  }
}
