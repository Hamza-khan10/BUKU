import crypto from 'crypto';
import { Request, Response, NextFunction, RequestHandler } from 'express';
import { ZodSchema, ZodError } from 'zod';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import winston from 'winston';
import morgan from 'morgan';

// ─────────────────────────────────────────────
// HTTP STATUS CODES
// ─────────────────────────────────────────────
export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE: 422,
  TOO_MANY_REQUESTS: 429,
  INTERNAL_ERROR: 500,
  SERVICE_UNAVAILABLE: 503,
} as const;

// ─────────────────────────────────────────────
// ERROR CODES
// ─────────────────────────────────────────────
export enum ErrorCode {
  // Auth
  USER_NOT_FOUND      = 'USER_NOT_FOUND',
  USER_EXISTS         = 'USER_EXISTS',
  INVALID_CREDENTIALS = 'INVALID_CREDENTIALS',
  OTP_EXPIRED         = 'OTP_EXPIRED',
  OTP_INVALID         = 'OTP_INVALID',
  OTP_MAX_ATTEMPTS    = 'OTP_MAX_ATTEMPTS',
  OTP_RATE_LIMIT      = 'OTP_RATE_LIMIT',
  TOKEN_INVALID       = 'TOKEN_INVALID',
  TOKEN_EXPIRED       = 'TOKEN_EXPIRED',
  TOKEN_REVOKED       = 'TOKEN_REVOKED',
  REFRESH_TOKEN_INVALID = 'REFRESH_TOKEN_INVALID',
  PASSWORD_TOO_WEAK   = 'PASSWORD_TOO_WEAK',
  UNAUTHORIZED        = 'UNAUTHORIZED',
  FORBIDDEN           = 'FORBIDDEN',
  // Booking
  SLOT_UNAVAILABLE    = 'SLOT_UNAVAILABLE',
  SLOT_LOCK_FAILED    = 'SLOT_LOCK_FAILED',
  APPOINTMENT_NOT_FOUND = 'APPOINTMENT_NOT_FOUND',
  INVALID_STATUS_TRANSITION = 'INVALID_STATUS_TRANSITION',
  BUSINESS_CLOSED     = 'BUSINESS_CLOSED',
  BOOKING_TOO_EARLY   = 'BOOKING_TOO_EARLY',
  BOOKING_TOO_LATE    = 'BOOKING_TOO_LATE',
  SERVICE_NOT_FOUND   = 'SERVICE_NOT_FOUND',
  STAFF_NOT_FOUND     = 'STAFF_NOT_FOUND',
  // Queue
  QUEUE_NOT_OPEN      = 'QUEUE_NOT_OPEN',
  QUEUE_FULL          = 'QUEUE_FULL',
  QUEUE_ALREADY_OPEN  = 'QUEUE_ALREADY_OPEN',
  QUEUE_ENTRY_NOT_FOUND = 'QUEUE_ENTRY_NOT_FOUND',
  ALREADY_IN_QUEUE    = 'ALREADY_IN_QUEUE',
  // Business
  BUSINESS_NOT_FOUND  = 'BUSINESS_NOT_FOUND',
  BUSINESS_NOT_VERIFIED = 'BUSINESS_NOT_VERIFIED',
  NOT_BUSINESS_OWNER  = 'NOT_BUSINESS_OWNER',
  // Search
  SEARCH_FAILED       = 'SEARCH_FAILED',
  // Ads
  AD_NOT_FOUND        = 'AD_NOT_FOUND',
  AD_BUDGET_EXCEEDED  = 'AD_BUDGET_EXCEEDED',
  AD_NOT_ACTIVE       = 'AD_NOT_ACTIVE',
  // Payments
  PAYMENT_FAILED      = 'PAYMENT_FAILED',
  WEBHOOK_INVALID     = 'WEBHOOK_INVALID',
  // General
  VALIDATION_ERROR    = 'VALIDATION_ERROR',
  NOT_FOUND           = 'NOT_FOUND',
  INTERNAL_ERROR      = 'INTERNAL_ERROR',
  RATE_LIMITED        = 'RATE_LIMITED',
  FILE_TOO_LARGE      = 'FILE_TOO_LARGE',
  INVALID_FILE_TYPE   = 'INVALID_FILE_TYPE',
  SUBSCRIPTION_REQUIRED = 'SUBSCRIPTION_REQUIRED',
}

// ─────────────────────────────────────────────
// APP ERROR CLASS
// ─────────────────────────────────────────────
export class AppError extends Error {
  public readonly code: ErrorCode;
  public readonly httpStatus: number;
  public readonly details?: unknown;
  public readonly isOperational: boolean;

  constructor(
    message: string,
    code: ErrorCode,
    httpStatus: number,
    details?: unknown,
  ) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.httpStatus = httpStatus;
    this.details = details;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }

  static badRequest(message: string, code: ErrorCode = ErrorCode.VALIDATION_ERROR, details?: unknown) {
    return new AppError(message, code, HTTP_STATUS.BAD_REQUEST, details);
  }
  static unauthorized(message = 'Unauthorized', code: ErrorCode = ErrorCode.UNAUTHORIZED) {
    return new AppError(message, code, HTTP_STATUS.UNAUTHORIZED);
  }
  static forbidden(message = 'Forbidden', code: ErrorCode = ErrorCode.FORBIDDEN) {
    return new AppError(message, code, HTTP_STATUS.FORBIDDEN);
  }
  static notFound(message: string, code: ErrorCode = ErrorCode.NOT_FOUND) {
    return new AppError(message, code, HTTP_STATUS.NOT_FOUND);
  }
  static conflict(message: string, code: ErrorCode) {
    return new AppError(message, code, HTTP_STATUS.CONFLICT);
  }
  static tooManyRequests(message = 'Too many requests') {
    return new AppError(message, ErrorCode.RATE_LIMITED, HTTP_STATUS.TOO_MANY_REQUESTS);
  }
  static internal(message = 'Internal server error') {
    return new AppError(message, ErrorCode.INTERNAL_ERROR, HTTP_STATUS.INTERNAL_ERROR);
  }
}

// ─────────────────────────────────────────────
// RESPONSE HELPERS
// ─────────────────────────────────────────────
export interface ApiMeta {
  page?: number;
  limit?: number;
  total?: number;
  totalPages?: number;
  hasMore?: boolean;
  [key: string]: unknown;
}

export function successResponse<T>(data: T, meta?: ApiMeta) {
  return { success: true, data, ...(meta ? { meta } : {}) };
}

export function errorResponse(error: AppError | Error) {
  if (error instanceof AppError) {
    return {
      success: false,
      error: {
        code: error.code,
        message: error.message,
        ...(error.details ? { details: error.details } : {}),
      },
    };
  }
  return {
    success: false,
    error: {
      code: ErrorCode.INTERNAL_ERROR,
      message: 'An unexpected error occurred',
    },
  };
}

// ─────────────────────────────────────────────
// LOGGER
// ─────────────────────────────────────────────
export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL ?? 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json(),
  ),
  defaultMeta: { service: process.env.SERVICE_NAME ?? 'buku-service' },
  transports: [new winston.transports.Console()],
});

export function requestLogger(): RequestHandler {
  const stream = { write: (msg: string) => logger.http(msg.trim()) };
  return morgan(':method :url :status :response-time ms - :res[content-length]', { stream }) as RequestHandler;
}

// ─────────────────────────────────────────────
// REQUEST VALIDATION (ZOD)
// ─────────────────────────────────────────────
export function validateRequest<T>(schema: ZodSchema<T>, source: 'body' | 'query' | 'params' = 'body'): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    const result = schema.safeParse(req[source]);
    if (!result.success) {
      const details = result.error.errors.map(e => ({
        field: e.path.join('.'),
        message: e.message,
      }));
      return next(AppError.badRequest('Validation failed', ErrorCode.VALIDATION_ERROR, details));
    }
    (req as Request & { validated: Record<string, unknown> }).validated = {
      ...((req as Request & { validated: Record<string, unknown> }).validated ?? {}),
      [source]: result.data,
    };
    req[source] = result.data as typeof req[typeof source];
    return next();
  };
}

// ─────────────────────────────────────────────
// JWT AUTHENTICATION
// ─────────────────────────────────────────────
export interface JwtPayload {
  sub: string;
  role: string;
  jti: string;
  iat: number;
  exp: number;
}

declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
      requestId?: string;
    }
  }
}

function getPublicKey(): string {
  const key = process.env.JWT_PUBLIC_KEY;
  if (!key) throw new Error('JWT_PUBLIC_KEY not set');
  return key.includes('BEGIN') ? key : Buffer.from(key, 'base64').toString('utf8');
}

export function authenticateToken(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return next(AppError.unauthorized('No token provided', ErrorCode.UNAUTHORIZED));
    }
    const token = authHeader.slice(7);
    try {
      const payload = jwt.verify(token, getPublicKey(), { algorithms: ['RS256'] }) as JwtPayload;
      req.user = payload;
      return next();
    } catch (err) {
      if (err instanceof jwt.TokenExpiredError) {
        return next(AppError.unauthorized('Token expired', ErrorCode.TOKEN_EXPIRED));
      }
      return next(AppError.unauthorized('Invalid token', ErrorCode.TOKEN_INVALID));
    }
  };
}

export function optionalAuth(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) return next();
    const token = authHeader.slice(7);
    try {
      req.user = jwt.verify(token, getPublicKey(), { algorithms: ['RS256'] }) as JwtPayload;
    } catch {
      // ignore — optional auth
    }
    return next();
  };
}

// ─────────────────────────────────────────────
// ROLE-BASED ACCESS CONTROL
// ─────────────────────────────────────────────
export function requireRole(...roles: string[]): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) return next(AppError.unauthorized());
    if (!roles.includes(req.user.role)) {
      return next(AppError.forbidden(`Requires role: ${roles.join(' or ')}`));
    }
    return next();
  };
}

export function requireBusinessOwner(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) return next(AppError.unauthorized());
    if (!['business_owner', 'super_admin'].includes(req.user.role)) {
      return next(AppError.forbidden('Business owner access required'));
    }
    return next();
  };
}

export function requireSuperAdmin(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) return next(AppError.unauthorized());
    if (req.user.role !== 'super_admin') {
      return next(AppError.forbidden('Super admin access required'));
    }
    return next();
  };
}

// ─────────────────────────────────────────────
// PAGINATION
// ─────────────────────────────────────────────
export interface PaginationParams {
  page: number;
  limit: number;
  skip: number;
}

export function getPagination(req: Request, defaultLimit = 20, maxLimit = 100): PaginationParams {
  const page = Math.max(1, parseInt(String(req.query.page ?? '1'), 10) || 1);
  const limit = Math.min(maxLimit, Math.max(1, parseInt(String(req.query.limit ?? String(defaultLimit)), 10) || defaultLimit));
  return { page, limit, skip: (page - 1) * limit };
}

export function paginationMeta(total: number, page: number, limit: number): ApiMeta {
  const totalPages = Math.ceil(total / limit);
  return { page, limit, total, totalPages, hasMore: page < totalPages };
}

// ─────────────────────────────────────────────
// CRYPTO HELPERS
// ─────────────────────────────────────────────
export async function hashToken(token: string, rounds = 10): Promise<string> {
  return bcrypt.hash(token, rounds);
}

export async function verifyToken(token: string, hash: string): Promise<boolean> {
  return bcrypt.compare(token, hash);
}

const ENCRYPTION_ALGO = 'aes-256-gcm';
const IV_LENGTH = 16;
const TAG_LENGTH = 16;

function getEncryptionKey(): Buffer {
  const key = process.env.PII_ENCRYPTION_KEY;
  if (!key) throw new Error('PII_ENCRYPTION_KEY not set');
  const buf = Buffer.from(key, 'hex');
  if (buf.length !== 32) throw new Error('PII_ENCRYPTION_KEY must be 32 bytes hex (64 chars)');
  return buf;
}

export function encrypt(text: string): string {
  const key = getEncryptionKey();
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ENCRYPTION_ALGO, key, iv);
  const encrypted = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, encrypted]).toString('base64');
}

export function decrypt(ciphertext: string): string {
  const key = getEncryptionKey();
  const buf = Buffer.from(ciphertext, 'base64');
  const iv = buf.subarray(0, IV_LENGTH);
  const tag = buf.subarray(IV_LENGTH, IV_LENGTH + TAG_LENGTH);
  const encrypted = buf.subarray(IV_LENGTH + TAG_LENGTH);
  const decipher = crypto.createDecipheriv(ENCRYPTION_ALGO, key, iv);
  decipher.setAuthTag(tag);
  return decipher.update(encrypted) + decipher.final('utf8');
}

export function generateHmacSignature(payload: string, secret: string): string {
  return 'sha256=' + crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

export function verifyHmacSignature(payload: string, secret: string, signature: string): boolean {
  const expected = generateHmacSignature(payload, secret);
  try {
    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  } catch {
    return false;
  }
}

// ─────────────────────────────────────────────
// CONFIRMATION CODE
// ─────────────────────────────────────────────
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export function generateConfirmationCode(): string {
  let code = 'BK-';
  for (let i = 0; i < 6; i++) {
    code += CODE_CHARS[crypto.randomInt(CODE_CHARS.length)];
  }
  return code;
}

export function generateOtp(): string {
  return String(crypto.randomInt(100000, 999999));
}

export function generateSecureToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// ─────────────────────────────────────────────
// GLOBAL ERROR HANDLER
// ─────────────────────────────────────────────
export function errorHandler() {
  return (err: Error, req: Request, res: Response, _next: NextFunction) => {
    const requestId = req.requestId ?? 'unknown';

    if (err instanceof AppError && err.isOperational) {
      logger.warn({ message: err.message, code: err.code, requestId, path: req.path });
      return res.status(err.httpStatus).json(errorResponse(err));
    }

    if (err instanceof ZodError) {
      const appErr = AppError.badRequest('Validation failed', ErrorCode.VALIDATION_ERROR,
        err.errors.map(e => ({ field: e.path.join('.'), message: e.message })));
      return res.status(HTTP_STATUS.BAD_REQUEST).json(errorResponse(appErr));
    }

    logger.error({ message: err.message, stack: err.stack, requestId, path: req.path });
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json(errorResponse(AppError.internal()));
  };
}

export function notFoundHandler(): RequestHandler {
  return (req: Request, res: Response) => {
    res.status(HTTP_STATUS.NOT_FOUND).json(errorResponse(
      AppError.notFound(`Route ${req.method} ${req.path} not found`),
    ));
  };
}

// ─────────────────────────────────────────────
// REQUEST ID MIDDLEWARE
// ─────────────────────────────────────────────
export function requestId(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    const id = (req.headers['x-request-id'] as string) ?? crypto.randomUUID();
    req.requestId = id;
    res.setHeader('X-Request-ID', id);
    next();
  };
}

// ─────────────────────────────────────────────
// ASYNC HANDLER WRAPPER
// ─────────────────────────────────────────────
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>,
): RequestHandler {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
