import { PrismaClient } from '@prisma/client';

// ─────────────────────────────────────────────
// PRISMA SINGLETON — one connection pool per process
// ─────────────────────────────────────────────
declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

function createPrismaClient(): PrismaClient {
  return new PrismaClient({
    log: process.env.NODE_ENV === 'development'
      ? [{ emit: 'event', level: 'query' }, 'warn', 'error']
      : ['warn', 'error'],
    datasources: {
      db: { url: process.env.DATABASE_URL },
    },
  });
}

// Reuse across hot-reloads in development
export const prisma: PrismaClient = globalThis.__prisma ?? createPrismaClient();

if (process.env.NODE_ENV !== 'production') {
  globalThis.__prisma = prisma;
}

// Soft-delete middleware — filters out deleted users from all queries
prisma.$use(async (params, next) => {
  // Apply to User model queries
  if (params.model === 'User') {
    if (params.action === 'findFirst' || params.action === 'findMany') {
      params.args = params.args ?? {};
      params.args.where = { ...params.args.where, deletedAt: null };
    }
    if (params.action === 'findUnique' || params.action === 'findUniqueOrThrow') {
      // Convert to findFirst with soft-delete filter
      params.action = 'findFirst';
      params.args = params.args ?? {};
      params.args.where = { ...params.args.where, deletedAt: null };
    }
  }
  return next(params);
});

// ─────────────────────────────────────────────
// QUERY HELPERS
// ─────────────────────────────────────────────
export async function findByIdOrThrow<T>(
  model: { findFirst: (args: { where: { id: string } }) => Promise<T | null> },
  id: string,
  errorMessage = 'Resource not found',
): Promise<T> {
  const result = await model.findFirst({ where: { id } });
  if (!result) {
    const { AppError } = await import('./errors');
    throw AppError.notFound(errorMessage);
  }
  return result;
}

export function softDelete<T extends { update: (args: { where: { id: string }; data: { deletedAt: Date } }) => Promise<T> }>(
  model: T,
  id: string,
): ReturnType<T['update']> {
  return model.update({
    where: { id },
    data: { deletedAt: new Date() },
  }) as ReturnType<T['update']>;
}

export interface PaginatedResult<T> {
  data: T[];
  meta: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasMore: boolean;
  };
}

export async function paginate<T>(
  findMany: (args: { skip: number; take: number }) => Promise<T[]>,
  count: () => Promise<number>,
  page: number,
  limit: number,
): Promise<PaginatedResult<T>> {
  const skip = (page - 1) * limit;
  const [data, total] = await Promise.all([
    findMany({ skip, take: limit }),
    count(),
  ]);
  const totalPages = Math.ceil(total / limit);
  return {
    data,
    meta: { page, limit, total, totalPages, hasMore: page < totalPages },
  };
}

// ─────────────────────────────────────────────
// GRACEFUL DISCONNECT
// ─────────────────────────────────────────────
export async function disconnectDatabase(): Promise<void> {
  await prisma.$disconnect();
}

// Re-export Prisma types for convenience
export * from '@prisma/client';
